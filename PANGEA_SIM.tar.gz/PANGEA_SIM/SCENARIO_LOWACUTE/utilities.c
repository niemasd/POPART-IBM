/*  This file is part of the PopART IBM.

    The PopART IBM is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The PopART IBM is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the PopART IBM.  If not, see <http://www.gnu.org/licenses/>.
 */


/* Useful functions for model
 *
 */


/************************************************************************/
/******************************* Includes  ******************************/
/************************************************************************/

#include "utilities.h"
#include "constants.h"
#include "init.h"

/************************************************************************/
/******************************** functions *****************************/
/************************************************************************/

void check_age_group_index(age_list_struct *age_list, long person_id,int indextocheck){
	int i,j,aitrue;
	aitrue=-1; /* Assign dummy value. */
	for (i=0;i<(MAX_AGE-AGE_ADULT);i++){
		for (j=0;j<age_list->number_per_age_group[i];j++){
			if (age_list->age_group[i][j]->id==person_id)
				aitrue = i;
		}
	}
	if (aitrue==-1){
		printf("Person not found in check_age_group_index()\n");
		exit(1);
	}
	if (indextocheck!=aitrue){
		printf("Index for person %li does not match %i %i\n",person_id,indextocheck,aitrue);
		exit(1);
	}
		
}
		

void normalise_four_quantities(double *p1, double *p2, double *p3, double *p4){
	double normalization = *p1 + *p2 + *p3 + *p4;
	*p1 = *p1/normalization;
	*p2 = *p2/normalization;
	*p3 = *p3/normalization;
	*p4 = *p4/normalization;
}

/* Gives cumulative sums. Note we do not output a fourth var c4 as this is assumed ot be 1. */
void cumulative_four_quantities(double p1, double p2, double p3, double p4, double *c1, double *c2, double *c3, double *c4){
	*c1 = p1;
	*c2 = *c1+p2;
	*c3 = *c2+p3;
	*c4 = *c3+p4;
	if (fabs(*c4-1.0)>1e-12){
		printf("ERROR: Cumulative total in cumulative_four_quantities() does not sum to 1. Exiting. \n");
		exit(1);
	}
}
	
double hill_up(double x, double max_val, double exponent, double midpoint){
	/* This returns the value of the upHill function (with parameters max_val, exponent, midpoint) at point x. */
	double result = max_val * (pow(x,exponent))/((pow(x,exponent)+pow(midpoint,exponent)));
	return result;
}


double hill_down(double x, double max_val, double exponent, double midpoint){
	/* This returns the value of the downwards Hill function (with parameters max_val, exponent, midpoint) at point x. */
	double result = max_val * (pow(midpoint,exponent))/((pow(x,exponent)+pow(midpoint,exponent)));
	return result;
}

void calcul_population(population_size *pop, stratified_population_size *pop_strat){
	/* This function fills in pop_strat based on pop */

	int g, ag, r;

	/* summing populations */

	for(g=0 ; g<N_GENDER ; g++)
	{
		pop_strat->total_pop_size_per_gender[g] = 0;
		for(r=0 ; r<N_RISK ; r++)
		{
			pop_strat->pop_size_per_gender_risk[g][r] = 0;
		}
	}

	for(ag=0 ; ag<N_AGE ; ag++)
	{
		for(g=0 ; g<N_GENDER ; g++)
		{
			pop_strat->pop_size_per_gender_age[g][ag] = 0;
		}
		for(r=0 ; r<N_RISK ; r++)
		{
			//pop_strat->pop_size_per_age_risk[ag][r] = pop->pop_size_per_gender_age_risk[FEMALE][ag][r] + pop->pop_size_per_gender_age_risk[MALE][ag][r];
			for(g=0 ; g<N_GENDER ; g++)
			{
				pop_strat->pop_size_per_gender_age[g][ag] += pop->pop_size_per_gender_age_risk[g][ag][r];
				pop_strat->pop_size_per_gender_risk[g][r] += pop->pop_size_per_gender_age_risk[g][ag][r];
			}
		}
		//pop_strat->pop_size_per_age[ag] = pop_strat->pop_size_per_age_per_gender[FEMALE][ag] + pop_strat->pop_size_per_age_per_gender[MALE][ag];
		for(g=0 ; g<N_GENDER ; g++)
		{
			pop_strat->total_pop_size_per_gender[g] += pop_strat->pop_size_per_gender_age[g][ag];
		}
	}

	pop_strat->total_pop_size = pop_strat->total_pop_size_per_gender[FEMALE] + pop_strat->total_pop_size_per_gender[MALE];


	for(r=0 ; r<N_RISK ; r++)
	{
		//pop_strat->pop_size_per_risk[r] = pop_strat->pop_size_per_risk_per_gender[FEMALE][r] + pop_strat->pop_size_per_risk_per_gender[MALE][r];
		for(g=0 ; g<N_GENDER ; g++)
		{
			pop_strat->prop_pop_per_gender_risk[g][r] = (double)pop_strat->pop_size_per_gender_risk[g][r]/(double)pop_strat->total_pop_size_per_gender[g];
		}
	}

}

void calcul_pop_wider_age_groups(population_size *pop, population_size_one_year_age *pop_one_year){
	/* This function fills in pop based on pop_one_year */

	set_population_count_zero(pop);
	int total_pop = 0;
	int g, aa, ai, ag, r;
	for(ag=0 ; ag<N_AGE ; ag++)
	{
		for(aa=AGE_GROUPS_WITH_OLD[ag]- AGE_ADULT ; aa<AGE_GROUPS_WITH_OLD[ag+1]- AGE_ADULT ; aa++)
		{
			ai = pop_one_year->youngest_age_group_index + aa ; // ai is the index of the array age_list->number_per_age_group of the age group of people you want to be dead
			if (ai>(MAX_AGE-AGE_ADULT-1))
				ai = ai - (MAX_AGE-AGE_ADULT);
			for(r=0 ; r<N_RISK ; r++)
			{
				for(g=0 ; g<N_GENDER ; g++)
				{
					pop->pop_size_per_gender_age_risk[g][ag][r] += pop_one_year->pop_size_per_gender_age1_risk[g][ai][r];
					total_pop+=pop_one_year->pop_size_per_gender_age1_risk[g][ai][r];
				}
			}

		}
	}
	
	for(r=0 ; r<N_RISK ; r++){
		for(g=0 ; g<N_GENDER ; g++){
			pop->pop_size_per_gender_age_risk[g][N_AGE-1][r] += pop_one_year->pop_size_oldest_age_group_gender_risk[g][r];
			total_pop+=pop_one_year->pop_size_oldest_age_group_gender_risk[g][r];
		}
	}
	//printf("total pop counted in calcul_pop_wider_age_groups() is %i\n",total_pop);
}

void calcul_prevalence(proportion_population_size *prevalence, population_size *pop, population_size *n_infected_wide_age_group, population_size_one_year_age *n_infected){
	/* This function fills in prevalence based on pop and n_infected (through calculation of n_infected_wide_age_group)*/

	calcul_pop_wider_age_groups(n_infected_wide_age_group, n_infected);

	int g, ag, r;
	for(g=0 ; g<N_GENDER ; g++)
	{
		for (ag=0; ag<N_AGE; ag++)
		{
			for(r=0 ; r<N_RISK ; r++)
			{
				prevalence->prop_size_per_gender_age_risk[g][ag][r] = n_infected_wide_age_group->pop_size_per_gender_age_risk[g][ag][r] / pop->pop_size_per_gender_age_risk[g][ag][r];
			}
		}
	}
}

/* This is part of one way (which may not be the final version) to calculate births. 
 * Here we assume that we just want the number of women in each age group and their prevalence. */ 
//void calcul_prevalence_f_byage(prevalence_f_byage *prevalence_f, population_size *n_population, population_size *n_infected){
//	/* This function fills in prevalence based on pop and n_infected*/
//
//	int g, ag, r;
//	for(ag=0 ; ag<N_AGE ; ag++){
//		prevalence_f_byage->num[ag] = 0;
//		prevalence_f_byage->denom[ag] = 0;
//	}
//	for(g=0 ; g<N_GENDER ; g++){
//		for(ag=0 ; ag<N_AGE ; ag++){
//			for(r=0 ; r<N_RISK ; r++){
//				prevalence_f_byage->num[ag] += n_infected->pop_size_per_gender_age_risk[g][ag][r];
//				prevalence_f_byage->denom[ag] += n_population->pop_size_per_gender_age_risk[g][ag][r]
//			}
//		}
//	}
//
//	for(ag=0 ; ag<N_AGE ; ag++)
//		prevalence_f_byage->prevalence[ag] = prevalence_f_byage->num[ag]/(1.0*prevalence_f_byage->denom[ag]);
//}


void print_prevalence(population_size *pop, population_size *n_infected_wide_age_group, population_size_one_year_age *n_infected){
	/* This prints prevalence based on pop and n_infected*/

	calcul_pop_wider_age_groups(n_infected_wide_age_group, n_infected);

	int g, ag, r;
	for(g=0 ; g<N_GENDER ; g++)
	{
		if(g==0) printf("MALES\n"); else printf("FEMALES\n");
		for (ag=0; ag<N_AGE; ag++)
		{
			printf("age group %d\n",ag);
			for(r=0 ; r<N_RISK ; r++)
			{
				printf("risk group %d: prevalence = %lg\t", r, ((double) n_infected_wide_age_group->pop_size_per_gender_age_risk[g][ag][r]) / ( (double) pop->pop_size_per_gender_age_risk[g][ag][r]));
			}
			printf("\n");
		}
	}

	fflush(stdout);
}


void calcul_p_risk(int g, double p_risk[N_RISK][N_RISK], stratified_population_size *pop_strat, parameters *param){
	/* This fills in p_risk, so that p_risk[r,.] is the distribution over risk groups of sexual partners
	 * of someone of gender g in risk group r.*/
	int i,j;
	//// I think it might be (slightly?) quicker to loop from j=0..N_RISK-1 and then add the extra param->assortativity outside the loop.
	for(i=0 ; i<N_RISK ; i++)
	{
		p_risk[i][i] = param->assortativity + (1-param->assortativity)*pop_strat->prop_pop_per_gender_risk[1-g][i];
		for(j=0 ; j<i ; j++)
		{
			p_risk[i][j] = (1-param->assortativity)*pop_strat->prop_pop_per_gender_risk[1-g][j];
		}
		for(j=i+1 ; j<N_RISK ; j++)
		{
			p_risk[i][j] = (1-param->assortativity)*pop_strat->prop_pop_per_gender_risk[1-g][j];
		}
	}
}

void standardize_relative_number_partnerships_per_risk(int g, double *standardized_relative_number_partnerships_per_risk, stratified_population_size *pop_strat, parameters *param){
	/* This fills in standardized_relative_number_partnerships_per_risk, based on
	 * relative_number_partnerships_per_risk, so that
	 * sum_risk_groups(standardized_relative_number_partnerships_per_risk*pop->prop_pop_per_risk) = 1 */

	int r;
	double scalar = 0;

	for(r=0 ; r<N_RISK ; r++)
	{
		scalar += param->relative_number_partnerships_per_risk[r]*pop_strat->prop_pop_per_gender_risk[g][r];
	}

	for(r=0 ; r<N_RISK ; r++)
	{
		standardized_relative_number_partnerships_per_risk[r] = param->relative_number_partnerships_per_risk[r]/scalar;
	}
}


void calcul_n_new_partners_f_to_m(population_size *pop, stratified_population_size *pop_strat, parameters *param){
	int ag_f, ag_m ; /* indexes of ages for females and males */
	int r_f, r_m ; /* indexes of risk groups for females and males */

	/* Fills in p_risk_f */
	calcul_p_risk(FEMALE, param->p_risk_per_gender[FEMALE], pop_strat, param);

	/* Standardizes the relative number of new partners per risk group */
	standardize_relative_number_partnerships_per_risk(FEMALE, param->xi_per_gender[FEMALE], pop_strat, param);

	/* Calculates the "desired" number of new partners for females per age and risk group */
	for(ag_f=0 ; ag_f<N_AGE ; ag_f++)
	{
		for(r_f=0 ; r_f<N_RISK ; r_f++)
		{
			for(ag_m=0 ; ag_m<N_AGE ; ag_m++)
			{
				for(r_m=0 ; r_m<N_RISK ; r_m++)
				{
					param->unbalanced_nb_f_to_m[ag_f][r_f][ag_m][r_m] = TIME_STEP*pop->pop_size_per_gender_age_risk[FEMALE][ag_f][r_f]*param->c_per_gender[FEMALE][ag_f]*param->xi_per_gender[FEMALE][r_f]*param->p_age_per_gender[FEMALE][ag_f][ag_m]*param->p_risk_per_gender[FEMALE][r_f][r_m];
					/* In English this means that the number of new partnerships within a time step between female ages ag_f risk r_f and males aged ag_m risk r_m,
					 * as desired by the females
					 * is the following product:
					 * TIME STEP x Number females in that group x rate of new partners for females in that age group x relative rate for females in that risk group
					 * 			 x proportion of new male partners within a certain age category ag_m
					 * 			 x proportion of new male partners within a certain risk category r_m */
				}
			}

		}
	}

}


void calcul_n_new_partners_m_to_f(population_size *pop, stratified_population_size *pop_strat, parameters *param){
	int ag_f, ag_m ; /* indexes of ages for females and males */
	int r_f, r_m ; /* indexes of risk groups for females and males */

	/* Fills in p_risk_m */
	calcul_p_risk(MALE, param->p_risk_per_gender[MALE], pop_strat, param);

	/* Standardizes the relative number of new partners per risk group */
	standardize_relative_number_partnerships_per_risk(MALE, param->xi_per_gender[MALE], pop_strat, param);


	/* Calculates the "desired" number of new partners for males per age and risk group */
	for(ag_f=0 ; ag_f<N_AGE ; ag_f++)
	{
		for(r_f=0 ; r_f<N_RISK ; r_f++)
		{
			for(ag_m=0 ; ag_m<N_AGE ; ag_m++)
			{
				for(r_m=0 ; r_m<N_RISK ; r_m++)
				{
					param->unbalanced_nb_m_to_f[ag_m][r_m][ag_f][r_f] = TIME_STEP*pop->pop_size_per_gender_age_risk[MALE][ag_m][r_m]*param->c_per_gender[MALE][ag_m]*param->xi_per_gender[MALE][r_m]*param->p_age_per_gender[MALE][ag_m][ag_f]*param->p_risk_per_gender[MALE][r_m][r_f];
				}
			}

		}
	}
}

/* this fills in balanced_nb_f_to_m with the balanced number of
 * new partnerships between a female of age ag_f, risk r_f and a male of age ag_m, risk r_m over a time unit */
void balance_contacts_arithmetic(parameters *param)
{
	int ag_f, ag_m,r_f, r_m;
	double tmp;
	for(ag_f=0 ; ag_f<N_AGE ; ag_f++)
	{
		for(r_f=0 ; r_f<N_RISK ; r_f++)
		{
			for(ag_m=0 ; ag_m<N_AGE ; ag_m++)
			{
				for(r_m=0 ; r_m<N_RISK ; r_m++)
				{
					tmp = (1-param->prop_compromise_from_males) * param->unbalanced_nb_f_to_m[ag_f][r_f][ag_m][r_m] + param->prop_compromise_from_males * param->unbalanced_nb_m_to_f[ag_m][r_m][ag_f][r_f];
					param->balanced_nb_f_to_m[ag_f][r_f][ag_m][r_m] = floor (tmp);
					param->balanced_nb_f_to_m[ag_f][r_f][ag_m][r_m] += gsl_ran_bernoulli (rng, tmp - floor(tmp)); /* Bernoulli trial with probability tmp - floor(tmp) */
				}
			}
		}
	}
}

int are_in_partnership(individual *indiv1, individual *indiv2)
{
	int res = 0;
	int i;

	for(i=0 ; i<indiv1->n_partners ; i++)
	{
		if(indiv1->partner_pairs[i]->ptr[1-indiv1->gender]->id==indiv2->id)
		{
			res = 1;
			break;
		}
	}

	return(res);
}

int has_free_partnership(individual *indiv)
{
	return(indiv->n_partners < indiv->max_n_partners);
}

/* is idx_new_partners_m[current_idx] equal to any of the other idx_new_partners_m[k]? */
int is_already_selected(long *idx_new_partners_m, long current_idx, long n_partners_m)
{
	long k;

	//printf("Does %d \n",idx_new_partners_m[current_idx]);
	//printf("belong to the following list:\n");

	//for(k=current_idx+1 ; k<n_partners_m ; k++)
	//{
	//	printf("\t %d \t",idx_new_partners_m[k]);
	//}
	//printf("\n");
	//for(k=0 ; k<current_idx ; k++)
	//{
	//	printf("\t %d \t",idx_new_partners_m[k]);
	//}
	//printf("?\n");

	k = current_idx;
	if(k < n_partners_m - 1)
	{
		do
		{
			k++;
		}while((k < n_partners_m - 1) && (idx_new_partners_m[current_idx] != idx_new_partners_m[k]));
	}else
	{
		k = 0;
	}

	if(idx_new_partners_m[current_idx] != idx_new_partners_m[k])
	{
		if(current_idx >0)
		{
			k = current_idx - 1;
			while( (idx_new_partners_m[current_idx] != idx_new_partners_m[k]) && (k > 0))
			{
				k--;
			}
		}
	}

	if(idx_new_partners_m[current_idx] != idx_new_partners_m[k])
	{
		//printf("Answer = %d\n",0);
		//fflush(stdout);
		return(0);
	}else
	{
		//printf("Answer = %d\n",1);
		//fflush(stdout);
		return(1);
	}

}

void copy_array_long(long *dest, long *orig, long size)
{
	int k;

	for(k=0 ; k<size ; k++)
	{
		dest[k] = orig[k];
	}
}

int is_serodiscordant(partnership *pair)
{
	return(((pair->ptr[0]->HIV_status * pair->ptr[1]->HIV_status) == 0) && ((pair->ptr[0]->HIV_status + pair->ptr[1]->HIV_status) > 0));
}

int compare_longs (const void *a, const void *b)
{
	const long *da = (const long *) a;
	const long *db = (const long *) b;

	return (*da > *db) - (*da < *db);
}


/* Function does: takes a string which is the setting name and converts it to an integer value for easy comparison.
 * Integers are defined in constants.h. Note - this function is case-sensitive, so I've included basic 
 * cases. We can make this more robust if needed but it is not a 1-liner to convert to a given case).
 * Function returns: integer of setting (currently envisaged to be country, but could be cluster id). */
int get_setting(parameters *param){
	int setting;
	/* First 12 clusters are Zambia: */
	if (param->cluster_number<=12){
	//if ((strncmp(setting_name,"Zambia",6)==0) || (strncmp(setting_name,"zambia",6)==0) || (strncmp(setting_name,"ZAMBIA",6)==0)){
	  //printf("Setting: Zambia\n");
		setting = ZAMBIA;
	}
	else{
	  //printf("Setting: South Africa\n");
		setting = SOUTH_AFRICA;
	}
	return setting;
}


/* Given the cluster number, assign the trial arm 
 * (this is currently a global variable, but could stick in param). 
 * Using numbering from M&E Reports_All Sites thru 30th April 2014-3.xlsx. 
 * Sites 1,2,5,6,8,9,10,11 are arms A+B Zambia. Of these sites 2,5,8,10 arm A.
 * Sites 13,14,16,18,19,20 are arms A_B South Africa. Of these sites 14,16,19 arm A. */
void get_trial_arm(int cluster_number){
	if (cluster_number==2 ||cluster_number==5 ||cluster_number==8 ||cluster_number==10 ||cluster_number==14 ||cluster_number==16 ||cluster_number==19)		
		TRIAL_ARM = ARM_A; 
	else if (cluster_number==1 || cluster_number==6 || cluster_number==9 || cluster_number==11 || cluster_number==13 || cluster_number==18 || cluster_number==20)
		TRIAL_ARM = ARM_B;
	else
		TRIAL_ARM = ARM_C;
	printf("TRIAL_ARM = %i\n",TRIAL_ARM);
}


/* Function gets the version number of the model from git. 
 * This is so we can add the version number to the output files.
 * version is the variable which will store the version number. stringlength is the length of memory in version - ie the maximum allowed number of characters in the version number. */
void get_IBM_code_version(char *version, int stringlength){
    FILE *fp;
    int status;
    strncpy(version,"LOWACUTE",stringlength); /* This sets version to be "V0". */
    return;
    
    /* This calls git (as a system commant) and gets the tags (which is how we have stored version numbers). The last tag is the most recent.
     * "tail -1" pulls this from the output. Finally the sed command replaces the '.'s by '-'s. */ 
    fp = popen("git tag|tail -1|sed 's/\\./\\-/g'", "r");
    if (fp == NULL){     /* System cannot run this command, so set version to be blank. */
    	strncpy(version,"V0",stringlength); /* This sets version to be "V0". */
    }
    else{
      fgets(version, stringlength, fp); /* Copy the version into the array "version". Note that the version label is not allowed to be >stringlength characters. */
      /* This bit is a really ugly hack to remove the trailing carriage return we get from the git command. */
      char *src, *dst;
      /* Note that this uses pointer arithmetic! */
      for (src = dst = version; *src != '\0'; src++) {
         *dst = *src;
         if ((*dst != '\n') && (*dst != '\r')) dst++;
      }
      *dst = '\0';
    }
    
    status = pclose(fp);
    if (status == -1){ /* Error reported by pclose() */
      printf("ERROR reported by pclose()\n");
      exit(1);
    }
    
       
}


/* Function generates a label for all output files which will be appended onto the filename so that they are of the form: 
 * filename_CL01_Za_A_V1-0_Rand0
For Cluster 01 in Zambia, arm A, git version 1.0 and random seed 0. */
void make_output_filename_labels(char *label, int stringlength, parameters *param, int country_setting, int rng_seed, int i_run){
	char version[21];  /* 20 is arbitrary but note we have to change the 20 in the call to get_IBM_code_version() below if we change this. */
	char temp[60];     /* Again 40 is arbitrary - assume we never have stupidly long filenames! */
	//sprintf(label,"_CL");  /* First part of the label is _CL. */
	
	memset(temp, '\0', sizeof(temp));
	
	if (i_run==0)
	  sprintf(label,"FULLINTERVENTION");
	else if (i_run==1)
	  sprintf(label,"LOWINTERVENTION");
	else if (i_run==2)
	  sprintf(label,"COUNTERFACTUAL");
	else
	  printf("Unknown run\n");
	get_IBM_code_version(version,20);
	strcat(label,version);
	
	sprintf(temp,"_Rand%i_Run%i.csv",rng_seed,i_run+1);
	strcat(label,temp);

}





void print_param_struct(parameters *param){
	int g,ag,bg,icd4,spvl,r;
	
	printf("------------------------------------------------------------------------------------\n");
	printf("---------------------------- Printing param structure ------------------------------\n");
	printf("------------------------------------------------------------------------------------\n");
	
	printf("param->total_fertility_rate=%lg\n",param->total_fertility_rate);
	printf("param->shape_fertility_param=%lg\n",param->shape_fertility_param);
	printf("param->scale_fertility_param=%lg\n",param->scale_fertility_param);
	printf("param->sex_ratio=%lg\n",param->sex_ratio);
	printf("param->p_child_circ=%lg\n",param->p_child_circ);
	printf("param->eff_circ=%lg\n",param->eff_circ);
	printf("param->rr_circ_unhealed=%lg\n",param->rr_circ_unhealed);
	printf("param->t0_pmtct=%lg\n",param->t0_pmtct);
	printf("param->t50_pmtct=%lg\n",param->t50_pmtct);
	printf("param->average_log_viral_load=%lg\n",param->average_log_viral_load);
	printf("param->average_annual_hazard=%lg\n",param->average_annual_hazard);
	printf("param->RRacute_trans=%lg\n",param->RRacute_trans);
	printf("param->RRmale_to_female_trans=%lg\n",param->RRmale_to_female_trans);
	printf("param->RRCD4[0],param->RRCD4[1],param->RRCD4[2],param->RRCD4[3]=%lg %lg %lg %lg\n",param->RRCD4[0],param->RRCD4[1],param->RRCD4[2],param->RRCD4[3]);
	printf("param->RRSPVL[0],param->RRSPVL[1],param->RRSPVL[2],param->RRSPVL[3]=%lg %lg %lg %lg\n",param->RRSPVL[0],param->RRSPVL[1],param->RRSPVL[2],param->RRSPVL[3]);
	printf("param->RR_ART_INITIAL=%lg\n",param->RR_ART_INITIAL);
	printf("param->RR_ART_VS=%lg\n",param->RR_ART_VS);
	printf("param->RR_ART_VU=%lg\n",param->RR_ART_VU);
	printf("param->min_dur_acute,param->max_dur_acute=%lg %lg\n",param->min_dur_acute,param->max_dur_acute);
	for (spvl=0; spvl<NSPVL; spvl++)
		printf("param->p_initial_cd4_gt500[spvl]=%lg\n",param->p_initial_cd4_gt500[spvl]);
	for (spvl=0; spvl<NSPVL; spvl++)
		printf("param->p_initial_cd4_350_500[spvl]=%lg\n",param->p_initial_cd4_350_500[spvl]);
	for (spvl=0; spvl<NSPVL; spvl++)
		printf("param->p_initial_cd4_200_350[spvl]=%lg\n",param->p_initial_cd4_200_350[spvl]);
	for (spvl=0; spvl<NSPVL; spvl++)
		printf("param->p_initial_cd4_lt200[spvl]=%lg\n",param->p_initial_cd4_lt200[spvl]);
	for (spvl=0; spvl<NSPVL; spvl++)
		printf("param->p_initial_spvl_cat[spvl]=%lg\n",param->p_initial_spvl_cat[spvl]);
	printf("param->cumulative_p_initial_spvl_cat[0],param->cumulative_p_initial_spvl_cat[1],param->cumulative_p_initial_spvl_cat[2],param->cumulative_p_initial_spvl_cat[3]=%lg %lg %lg %lg\n",param->cumulative_p_initial_spvl_cat[0],param->cumulative_p_initial_spvl_cat[1],param->cumulative_p_initial_spvl_cat[2],param->cumulative_p_initial_spvl_cat[3]);
	for (icd4=0; icd4<NCD4; icd4++)
		for (spvl=0; spvl<NSPVL; spvl++)
			printf("param->time_hiv_event[icd4][spvl][0],param->time_hiv_event[icd4][spvl][1]=%lg %lg\n",param->time_hiv_event[icd4][spvl][0],param->time_hiv_event[icd4][spvl][1]);
	printf("param->factor_for_slower_progression_ART_VU=%lg\n",param->factor_for_slower_progression_ART_VU);
	printf("param->assortativity=%lg\n",param->assortativity);
	printf("param->prop_compromise_from_males=%lg\n",param->prop_compromise_from_males);
	for (ag=0; ag<N_AGE; ag++)
		printf("param->c_per_gender[FEMALE][ag]=%lg\n",param->c_per_gender[FEMALE][ag]);
	for (ag=0; ag<N_AGE; ag++)
		printf("param->c_per_gender[MALE][ag]=%lg\n",param->c_per_gender[MALE][ag]);
	for (r=0; r<N_RISK; r++)
		printf("param->relative_number_partnerships_per_risk[r]=%lg\n",param->relative_number_partnerships_per_risk[r]);
	for (g=0; g<N_GENDER; g++)
		for (ag=0; ag<N_AGE; ag++)
		for (bg=0; bg<N_AGE; bg++)
				printf("param->p_age_per_gender[g][ag][bg]=%lg\n",param->p_age_per_gender[g][ag][bg]);
	
	for(r=0 ; r<N_RISK ; r++)
		printf("param->max_n_part_noage[r]=%d\n",param->max_n_part_noage[r]);
	printf("param->breakup_scale_lambda=%lg\n",param->breakup_scale_lambda);
	printf("param->breakup_shape_k=%lg\n",param->breakup_shape_k);
	
	printf("param->start_time_hiv=%lg\n",param->start_time_hiv);
	printf("param->start_time_simul=%i\n",param->start_time_simul);
	printf("param->end_time_simul=%i\n",param->end_time_simul);
	printf("param->COUNTRY_HIV_TEST_START=%lg\n",param->COUNTRY_HIV_TEST_START);
	printf("param->COUNTRY_ART_START=%lg\n",param->COUNTRY_ART_START);
	printf("param->COUNTRY_VMMC_START=%lg\n",param->COUNTRY_VMMC_START);
	printf("param->POPART_START=%lg\n",param->POPART_START);
	printf("param->POPART_END=%lg\n",param->POPART_END);
	printf("param->p_collect_hiv_test_results_cd4_over200=%lg\n",param->p_collect_hiv_test_results_cd4_over200);
	printf("param->p_collect_hiv_test_results_cd4_under200=%lg\n",param->p_collect_hiv_test_results_cd4_under200);
	printf("param->p_collect_cd4_test_results_cd4_over200=%lg\n",param->p_collect_cd4_test_results_cd4_over200);
	printf("param->p_collect_cd4_test_results_cd4_under200=%lg\n",param->p_collect_cd4_test_results_cd4_under200);
	for (icd4=0; icd4<NCD4; icd4++)
		printf("param->p_dies_earlyart_cd4[icd4]=%lg\n",param->p_dies_earlyart_cd4[icd4]);
	printf("param->p_leaves_earlyart_cd4_over200=%lg\n",param->p_leaves_earlyart_cd4_over200);
	printf("param->p_leaves_earlyart_cd4_under200=%lg\n",param->p_leaves_earlyart_cd4_under200);
	printf("param->p_becomes_vs_after_earlyart=%lg\n",param->p_becomes_vs_after_earlyart);
	printf("param->p_stays_virally_suppressed=%lg\n",param->p_stays_virally_suppressed);
	printf("param->p_stops_virally_suppressed=%lg\n",param->p_stops_virally_suppressed);
	printf("param->p_vu_becomes_virally_suppressed=%lg\n",param->p_vu_becomes_virally_suppressed);
	printf("param->t_earlyart_dropout_min[NOTPOPART]=%lg\n",param->t_earlyart_dropout_min[NOTPOPART]);
	printf("param->t_earlyart_dropout_min[POPART]=%lg\n",param->t_earlyart_dropout_min[POPART]);
	printf("param->t_earlyart_dropout_range[NOTPOPART]=%lg\n",param->t_earlyart_dropout_range[NOTPOPART]);
	printf("param->t_earlyart_dropout_range[POPART]=%lg\n",param->t_earlyart_dropout_range[POPART]);
	printf("param->t_dies_earlyart_min[NOTPOPART]=%lg\n",param->t_dies_earlyart_min[NOTPOPART]);
	printf("param->t_dies_earlyart_min[POPART]=%lg\n",param->t_dies_earlyart_min[POPART]);
	printf("param->t_dies_earlyart_range[NOTPOPART]=%lg\n",param->t_dies_earlyart_range[NOTPOPART]);
	printf("param->t_dies_earlyart_range[POPART]=%lg\n",param->t_dies_earlyart_range[POPART]);
	printf("param->t_end_early_art=%lg\n",param->t_end_early_art);
	printf("param->t_cd4_retest_min[NOTPOPART]=%lg\n",param->t_cd4_retest_min[NOTPOPART]);
	printf("param->t_cd4_retest_min[POPART]=%lg\n",param->t_cd4_retest_min[POPART]);
	printf("param->t_cd4_retest_range[NOTPOPART]=%lg\n",param->t_cd4_retest_range[NOTPOPART]);
	printf("param->t_cd4_retest_range[POPART]=%lg\n",param->t_cd4_retest_range[POPART]);
	printf("param->t_cd4_whenartfirstavail_min=%lg\n",param->t_cd4_whenartfirstavail_min);
	printf("param->t_cd4_whenartfirstavail_range=%lg\n",param->t_cd4_whenartfirstavail_range);
	printf("param->t_delay_hivtest_to_cd4test_min[NOTPOPART]=%lg\n",param->t_delay_hivtest_to_cd4test_min[NOTPOPART]);
	printf("param->t_delay_hivtest_to_cd4test_min[POPART]=%lg\n",param->t_delay_hivtest_to_cd4test_min[POPART]);
	printf("param->t_delay_hivtest_to_cd4test_range[NOTPOPART]=%lg\n",param->t_delay_hivtest_to_cd4test_range[NOTPOPART]);
	printf("param->t_delay_hivtest_to_cd4test_range[POPART]=%lg\n",param->t_delay_hivtest_to_cd4test_range[POPART]);
	printf("param->t_start_art_min[NOTPOPART]=%lg\n",param->t_start_art_min[NOTPOPART]);
	printf("param->t_start_art_min[POPART]=%lg\n",param->t_start_art_min[POPART]);
	printf("param->t_start_art_range[NOTPOPART]=%lg\n",param->t_start_art_range[NOTPOPART]);
	printf("param->t_start_art_range[POPART]=%lg\n",param->t_start_art_range[POPART]);
	printf("param->t_end_vs_becomevu_min[NOTPOPART]=%lg\n",param->t_end_vs_becomevu_min[NOTPOPART]);
	printf("param->t_end_vs_becomevu_min[POPART]=%lg\n",param->t_end_vs_becomevu_min[POPART]);
	printf("param->t_end_vs_becomevu_range[NOTPOPART]=%lg\n",param->t_end_vs_becomevu_range[NOTPOPART]);
	printf("param->t_end_vs_becomevu_range[POPART]=%lg\n",param->t_end_vs_becomevu_range[POPART]);
	printf("param->t_end_vs_dropout_min[NOTPOPART]=%lg\n",param->t_end_vs_dropout_min[NOTPOPART]);
	printf("param->t_end_vs_dropout_min[POPART]=%lg\n",param->t_end_vs_dropout_min[POPART]);
	printf("param->t_end_vs_dropout_range[NOTPOPART]=%lg\n",param->t_end_vs_dropout_range[NOTPOPART]);
	printf("param->t_end_vs_dropout_range[POPART]=%lg\n",param->t_end_vs_dropout_range[POPART]);
	printf("param->t_end_vu_becomevs_min[NOTPOPART]=%lg\n",param->t_end_vu_becomevs_min[NOTPOPART]);
	printf("param->t_end_vu_becomevs_min[POPART]=%lg\n",param->t_end_vu_becomevs_min[POPART]);
	printf("param->t_end_vu_becomevs_range[NOTPOPART]=%lg\n",param->t_end_vu_becomevs_range[NOTPOPART]);
	printf("param->t_end_vu_becomevs_range[POPART]=%lg\n",param->t_end_vu_becomevs_range[POPART]);
	printf("param->t_end_vu_dropout_min[NOTPOPART]=%lg\n",param->t_end_vu_dropout_min[NOTPOPART]);
	printf("param->t_end_vu_dropout_min[POPART]=%lg\n",param->t_end_vu_dropout_min[POPART]);
	printf("param->t_end_vu_dropout_range[NOTPOPART]=%lg\n",param->t_end_vu_dropout_range[NOTPOPART]);
	printf("param->t_end_vu_dropout_range[POPART]=%lg\n",param->t_end_vu_dropout_range[POPART]);
	printf("param->p_popart_to_cascade=%lg\n",param->p_popart_to_cascade);
	printf("param->p_circ[NOTPOPART]=%lg\n",param->p_circ[NOTPOPART]);
	printf("param->p_circ[POPART]=%lg\n",param->p_circ[POPART]);
	printf("param->t_get_vmmc_min[NOTPOPART]=%lg\n",param->t_get_vmmc_min[NOTPOPART]);
	printf("param->t_get_vmmc_min[POPART]=%lg\n",param->t_get_vmmc_min[POPART]);
	printf("param->t_get_vmmc_range[NOTPOPART]=%lg\n",param->t_get_vmmc_range[NOTPOPART]);
	printf("param->t_get_vmmc_range[POPART]=%lg\n",param->t_get_vmmc_range[POPART]);
	printf("param->t_vmmc_healing=%lg\n",param->t_vmmc_healing);
	printf("param->prop_visited_by_chips[MALE]=%lg\n",param->prop_visited_by_chips[MALE]);
	printf("param->prop_visited_by_chips[FEMALE]=%lg\n",param->prop_visited_by_chips[FEMALE]);
	printf("param->initial_population_size=%lg\n",param->initial_population_size);
	for (ag=0; ag<N_AGE; ag++)
		printf("param->initial_prop_age[ag]=%lg\n",param->initial_prop_age[ag]);
	for (g=0; g<N_GENDER; g++)
		for (r=0; r<N_RISK; r++)
			printf("param->initial_prop_gender_risk[g][r]=%lg\n",param->initial_prop_gender_risk[g][r]);
	for (g=0; g<N_GENDER; g++)
		for (r=0; r<N_RISK; r++)
			printf("param->initial_prop_infected_gender_risk[g][r]=%lg\n",param->initial_prop_infected_gender_risk[g][r]);
	printf("param->cluster_number=%i\n",param->cluster_number);

printf("------------------------------------------------------------------------------------\n");
printf("------------------------------------------------------------------------------------\n");
printf("------------------------------------------------------------------------------------\n");
	
}
	

/*double** alloc_2D_double(int size1, int size2)
{
	double **res;
	int i;
	res = malloc(size1*sizeof(double*));
	for(i = 0; i < size1; i++)
	{
		res[i] = malloc(size2 * sizeof(double));
	}
	return(res);
}

void free_2D_double(double **x, int size1)
{
	int i;
	for(i = 0; i < size1; i++)
	{
		free(x[i]);
	}
	free(x);
}


double**** alloc_4D_double(int size1, int size2, int size3, int size4)
{
	double ****res;
	int i,j,k;
	res = malloc(size1*sizeof(double***));
	for(i = 0; i < size1; i++)
	{
		res[i] = malloc(size2 * sizeof(double**));
		for(j = 0; j < size2; j++)
		{
			res[i][j] = malloc(size3 * sizeof(double*));
			for(k = 0; k < size3; k++)
			{
				res[i][j][k] = malloc(size4 * sizeof(double));
			}
		}
	}
	return(res);
}

void free_4D_double(double ****x, int size1, int size2, int size3)
{
	int i,j,k;
	for(i = 0; i < size1; i++)
	{
		for(j = 0; j < size2; j++)
		{
			for(k = 0; k < size3; k++)
			{
				free(x[i][j][k]);
			}
			free(x[i][j]);
		}
		free(x[i]);
	}
	free(x);
}

int** alloc_2D_int(int size1, int size2)
{
	int **res;
	int i;
	res = malloc(size1*sizeof(int*));
	for(i = 0; i < size1; i++)
	{
		res[i] = malloc(size2 * sizeof(int));
	}
	return(res);
}

void free_2D_int(int **x, int size1)
{
	int i;
	for(i = 0; i < size1; i++)
	{
		free(x[i]);
	}
	free(x);
}


int**** alloc_4D_int(int size1, int size2, int size3, int size4)
{
	int ****res;
	int i,j,k;
	res = malloc(size1*sizeof(int***));
	for(i = 0; i < size1; i++)
	{
		res[i] = malloc(size2 * sizeof(int**));
		for(j = 0; j < size2; j++)
		{
			res[i][j] = malloc(size3 * sizeof(int*));
			for(k = 0; k < size3; k++)
			{
				res[i][j][k] = malloc(size4 * sizeof(int));
			}
		}
	}
	return(res);
}

void free_4D_int(int ****x, int size1, int size2, int size3)
{
	int i,j,k;
	for(i = 0; i < size1; i++)
	{
		for(j = 0; j < size2; j++)
		{
			for(k = 0; k < size3; k++)
			{
				free(x[i][j][k]);
			}
			free(x[i][j]);
		}
		free(x[i]);
	}
	free(x);
}*/


