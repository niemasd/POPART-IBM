/*  This file is part of the PopART IBM.

    The PopART IBM is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The PopART IBM is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the PopART IBM.  If not, see <http://www.gnu.org/licenses/>.
 */


/* HIV infection processes for the PopART model:
 * mtct_transmission(): Transmission from mother to child
 * hiv_transmission_probability(): For a HIV+ partner determines their per-timestep P(trans) given their CD4 stage, SPVL, ART status, gender.
 * hiv_acquisition():   For a given individual, determines if HIV acquisition occurs through sexual contact with any infected partner (ie in partner_pairs_HIVpos[]) at a given timestep - using hiv_transmission_probability() to get per-individual transmission probabilities and assuming they sum up to total transmission probability.
 * find_who_infected(): Decides which HIV+ partner was responsible for seroconversion (takes into account heterogeneities in infectivity from each partner).
 * inform_partners_of_seroconversion(): Updates the "individual" structure of each partner so that they know the seroconvertor is now HIV+ (so if the partner is HIV-, this partnership is added to the serodiscordant partnership list of that partner, etc).
 * new_infection(): Assign SPVL, CD4 values for new infection in "individual" structure.
 * draw_initial_infection(): Bernoulli trial to decide if a given individual is HIV+ at introduction of HIV into population.
 * next_hiv_event(): For HIV+ people, schedule the next HIV event to occur in hiv_pos_progression[] (function called when they seroconvert, at the time of each new event, and when effective ART is stopped).  
 * carry_out_HIV_events_per_timestep():At each timestep this function is called, and carries out the HIV-related events scheduled in hiv_pos_progression[i][] at that timestep i.
 * get_window_result(): Decides if someone who was recently infeted tests positive corresponding to the window period of the test used (function can include different tests used over time/different countries). Note there are some notes on this in HIVtestnotesNov2014.pptx 
 * joins_preart_care(): Decides if someone who just tested positive joins pre-ART care or not. At present people chose to leave care independent of CD4 (ie not caring if they are eligible or not) - ASSUMPTION!
 * remains_in_cascade():Analogue of joins_preart_care() for people who are already in pre-ART care - decides if they remain in care until next CD4 test. 
 * measured_cd4_cat(): Given the 'true' biological CD4 category, gives the measured CD4 based on ATHENA data. 
 * art_cd4_eligbility_group(): gives the current  CD4 eligibility group for starting ART given the time and country.
 * is_eligible_for_art(): Outputs whether someone is eligible for ART at time t given their CD4 and current guidelines in that country.
 * get_time_emergency_start_ART(): For someone who is symptomatic (currently CD4<200) draws a time at which they start ART. At present if this is less than the time to AIDS death then they start on emergency ART at that time.
 * start_ART_process(): This represents the first X months of ART. Function sets up an individual starting ART (ie sets indiv->ART_status, stops CD4 progression), and schedules next cascade event (HIV death, becoming virally suppressed/not suppressed, drop out of care). 
 * draw_initial_hiv_tests(): When HIV testing starts in the country (assumed it can start before ART) this function schedules an HIV test for everyone. Currently people may have a test far in the future (so far that they never have one).
 * schedule_generic_cascade_event(): given a time t and a person indiv, schedules an event in the array cascade_event[] for that person. Note that this function does not know what type of event it is, so that is set separately in the function calling schedule_generic_cascade_event().
 * schedule_new_hiv_test(): function that sets up a HIV test in the future for someone. Called by draw_initial_hiv_tests() at the start of HIV testing in that country and by hiv_test_process() for people who just tested negative.
 * hiv_test_process(): Carries out the processes of HIV testing for someone and sets up their next cascade event according to the test result. In principle this can have sensitivity, specificity, window period and other complications to the test (only window period currently included). 
 * schedule_start_of_art(): Function which calculates the time to start ART in someone who just tested their CD4 and is eligible for ART, and then schedules event in cascade_event[]. Function called by hiv_test_process() and cd4_test_process(). 
 * cd4_test_process(): Carries out the processes of repeat CD4 testing for someone and sets up their next cascade event according to the test result. This is for people who previously tested HIV and CD4 and were not eligible, but remained in care. In principle we could also include the mis-match between true CD4 and measured CD4 category using the table from the ATHENA paper.
 * virally_suppressed_process(): Carries out the processes when become virally suppressed after starting ART. 
 * virally_unsuppressed_process(): Carries out the processes when become virally unsuppressed after starting ART. This includes restarting HIV progression events (althoguh HIV progression can be slower than in untreated people).
 * dropout_process(): Carries out the processes when drop out of care (restarting HIV progression if needed).
 * carry_out_cascade_events_per_timestep(): Function is the equivalend to carry_out_HIV_events_per_timestep() but for cascade events. At each timestep this function is called, and carries out the cascade-related events scheduled in cascade_events[i][] at that timestep i.

 */

/************************************************************************/
/******************************* Includes  ******************************/
/************************************************************************/

#include "hiv.h"
#include "constants.h"
#include "output.h"
#include "utilities.h"
#include "partnership.h"
#include "interventions.h"

/************************************************************************/
/******************************** functions *****************************/
/************************************************************************/

/* MTCT function: NOT CURRENTLY USED.
 * Function determines whether a single HIV+ woman gives birth to an HIV+ kid or not. 
   Input - the details of the pregnant woman, current time.
   Output - whether transmission of HIV occurs during pregnancy.
   //////// Could add a counter of how many MTCT events occur?
 */
double mtct_transmission(individual* infected_pregnant, double t, parameters *param){ 
	double log_VL = log10(infected_pregnant -> viral_load);
	double p_trans; /* Probability of transmission for whole pregnancy. */
	double vl_component;
	int transmit_hiv;

	/* This is an approximation of how transmission varies with log VL. */
	vl_component = hill_up(log_VL,1.0,0.3,param->average_log_viral_load);

	/* We assume that there is always a probability of 0.05 of transmission
       and that at baseline P(trans) = 0.2. 
       The probability of transmission is a function of whether pmtct services exist or not. */
	if (t<param->t0_pmtct)
		p_trans = 0.2 * vl_component; //// shall we put this 0.2 and other numerical values as parameters?
	else
		p_trans = 0.05 + hill_down(log_VL,0.15,2,(param->t50_pmtct-param->t0_pmtct));


	/* Now test if transmission occurs or not (Bernoulli trial): */
	transmit_hiv = gsl_ran_bernoulli(rng,p_trans);

	return transmit_hiv;
}


/******************************************************************************************************
 * ****************************************************************************************************
 *         These are function for the Pangea Nov/Dec 2014 meeting. Not used in the main code.         *
 * ****************************************************************************************************
 ******************************************************************************************************/
double intervention_effectiveness(double max_effectiveness,double t0, double t1, double t){
	double remaining_transmission = 1.0 - max_effectiveness;
	if (t<t0)
		return 1;
	else if (t<t1)
		return (remaining_transmission + max_effectiveness*(t1-t)/(t1-t0));
	else
		return remaining_transmission;
}


/******************************************************************************************************
 * ****************************************************************************************************
 *                            End of Pangea Nov/Dec 2014 meeting code.                                *
 * ****************************************************************************************************
 ******************************************************************************************************/

/* Given a HIV+ partner determines their per-timestep probability of transmission at time t as a function of their CD4 stage, SPVL, ART status, circumcisions status. */
double hiv_transmission_probability(individual* HIVpos_partner, double t, parameters *param){
	double hazard;
	hazard = param->average_annual_hazard;
	if (HIVpos_partner->HIV_status==ACUTE){
		hazard = hazard*param->RRacute_trans;
		/* Pangea code: 
		 * if (PHYLO_SCENARIO==2)
			hazard = hazard * intervention_effectiveness(0.8, 2004, 2014, t);
		 */
	}
	else{
		// Zambia had <350 in 2010,I think this was also when WHO guidelines changed.
		// Guidelines change for SA in 2012: http://www.hst.org.za/sites/default/files/ART_Vol2_Iss4.pdf 

		/* Pangea code:
		if (PHYLO_SCENARIO==0)
		 */
		hazard = hazard*param->RRCD4[HIVpos_partner->cd4];
		/* Pangea code:
		else if (PHYLO_SCENARIO==1){
			// Only stop transmission for <350 - this scenario represents giving everyone with CD4<350 partially effective ART. 
			if (HIVpos_partner->cd4<2)
				hazard = hazard*param->RRCD4[HIVpos_partner->cd4];
			else
				hazard = hazard*param->RRCD4[HIVpos_partner->cd4] * intervention_effectiveness(0.5, 2004, 2010, t);

		}
		else if (PHYLO_SCENARIO==2)
			hazard = hazard*param->RRCD4[HIVpos_partner->cd4] * intervention_effectiveness(0.6, 2004, 2014, t);
		else if (PHYLO_SCENARIO==3){
			// Only stop transmission for <350 - this scenario represents giving everyone with CD4<350 partially effective ART. 
			if (HIVpos_partner->cd4<2)
				hazard = hazard*param->RRCD4[HIVpos_partner->cd4];
			else
				hazard = hazard*param->RRCD4[HIVpos_partner->cd4] * intervention_effectiveness(0.8, 2014, 2016, t);

		}
		 */
	}
	hazard = hazard*param->RRSPVL[HIVpos_partner->SPVL];
	/* Reduce infectivity if on ART: */
	if (HIVpos_partner->ART_status==EARLYART)
		hazard = hazard*param->RR_ART_INITIAL;
	else if (HIVpos_partner->ART_status==LTART_VS)
		hazard = hazard*param->RR_ART_VS;
	else if (HIVpos_partner->ART_status==LTART_VU)
		hazard = hazard*param->RR_ART_VU;

	if (HIVpos_partner->gender==MALE)
		hazard = hazard*param->RRmale_to_female_trans;
	//printf("Transmission hazard = %f\n",hazard);
	return hazard;
}




//hill_up(partner_log_vl,param->average_annual_hazard,1.0,param->average_log_viral_load)*(1+param->RRacute_trans*partner_acute)

/* Function determines whether a single individual in one (or more) serodiscordant partnerships gets infected in a timestep.
 * If the individual gets infected then update all relevant lists (they are removed from list of HIV- people in serodiscordant partnerships).
 * (Not currently implemented - they will be added to list of people who are HIV+ with a time to next HIV progression event scheduled. 
 * If infected addition output is generated (update incident and prevalent case counts, output phylogenetic data of interest). */
void hiv_acquisition(double time_infect, individual* susceptible, parameters *param, 
		individual** susceptible_in_serodiscordant_partnership, long *n_susceptible_in_serodiscordant_partnership, 
		population_size_one_year_age *n_infected, population_size_one_year_age *n_newly_infected, age_list_struct *age_list,
		individual ***hiv_pos_progression, long *n_hiv_pos_progression, long *size_hiv_pos_progression){
	//DEBUGA:
	//population_size_one_year_age *n_infected, population_size_one_year_age *n_newly_infected){



	/* This is the total (annual) hazard from all HIV+ partners, ignoring reduced susceptibility if the individual is a 
	 * circumcised man. */
	double total_hazard_ignore_circ = 0.0;

	/* This variable is total_hazard_ignore_circ converted to the hazard per timestep, 
	 * and adjusted for circumcision if needed. */
	double total_hazard_per_timestep;

	/* Characteristics of the seropositive partner which may influence transmission: */
	int partner_gender = 1 - susceptible -> gender;

	int i; /* Index for summing over partners. */

	int infector_index; /* The index (in partner_pairs_HIVpos[]) of the partner who infected the seroconverter. */

	/* The number of HIV+ partners of this susceptible. */
	int npos = susceptible -> n_HIVpos_partners;

	/* FOR DEBUGGING */
	/*if(npos<1)
	{
		printf("Problem: trying to infect someone who is in no serodiscordant partnership\n");
		fflush(stdout);
		exit(1);
	}*/

	/* This will create an alias for each seropositive partner to save typing. */
	individual* temp_HIVpos_partner;

	/* Now sum hazard over each HIV+ partner: */
	for (i=0;i<npos;i++){
		/* This is a pointer to the ith HIV+ partner of the susceptible: */
		temp_HIVpos_partner = susceptible -> partner_pairs_HIVpos[i] -> ptr[partner_gender];
		//partner_log_vl = log10( temp_HIVpos_partner -> viral_load);
		/* This is 0 if partner not in acute phase, 1 if they are. */
		//partner_acute = 2 - (temp_HIVpos_partner -> HIV_status);

		/* Store the hazard from each partnership so we can work out who infected whom: */
		//PER_PARTNERSHIP_HAZARD_TEMPSTORE[i] = hill_up(partner_log_vl,param->average_annual_hazard,1.0,param->average_log_viral_load)*(1+param->RRacute_trans*partner_acute);
		PER_PARTNERSHIP_HAZARD_TEMPSTORE[i] = hiv_transmission_probability(temp_HIVpos_partner,time_infect,param);
		total_hazard_ignore_circ += PER_PARTNERSHIP_HAZARD_TEMPSTORE[i];
	}

	/* Adjust according to the circumcision status of the susceptible: */
	if ((susceptible->circ)==UNCIRC || (susceptible->circ)==UNCIRC_WAITING_VMMC)
		total_hazard_per_timestep = total_hazard_ignore_circ * TIME_STEP;
	else if ((susceptible->circ)==VMMC || (susceptible -> circ)==TRADITIONAL_MC)
		total_hazard_per_timestep = total_hazard_ignore_circ * (1.0-param->eff_circ) * TIME_STEP;
	/* Increased susceptibility if in healing period: */
	else if ((susceptible->circ)==VMMC_HEALING)
		total_hazard_per_timestep = total_hazard_ignore_circ * param->rr_circ_unhealed * TIME_STEP;
	else{
		fprintf(stderr,"ERROR: unknown circumcision status!!! Exiting\n");
		exit(1);
	}
	
	//printf("Individual %ld is subject to infection hazard %lg\n",susceptible->id,total_hazard_per_timestep);

	/* Now see if transmission occurs (Bernoulli trial - could replace by gsl_ran_bernoulli(rng,total_hazard_per_timestep): */ 
	double x = gsl_rng_uniform (rng);
	if (x<=total_hazard_per_timestep){
		/* Transmit HIV to this individual. */
		new_infection(time_infect, FALSE, susceptible, n_infected, n_newly_infected, age_list, param, hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression);
		DEBUG_NHIVPOS++;
		PANGEA_N_ANNUALINFECTIONS++;
		/* Update each of their HIV- partners so that they know that they have a serodiscordant partner and update list of serodiscrodant partnerships */
		inform_partners_of_seroconversion_and_update_list_serodiscordant_partnerships(susceptible, susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership);

		/* Outputs of interest (note that PER_PARTNERSHIP_HAZARD_TEMPSTORE[] is a global array so we do not need to pass it): */

		/* Determine which of the seropositive partners was responsible for infecting.
		 * so MMC status drops out when working out who the infector is (simply because VMMC reduces susceptibility, 
		 * To do this, pass total_hazard_ignore_circ - neither this nor PER_PARTNERSHIP_HAZARD_TEMPSTORE[] are scaled by eff_circ, 
		 * not infectivity). It is a bit faster to do it this way. 
		 * The output is the index in array partner_pairs_HIVpos of the individual person who infected. */
		/* Note if there was only one partner then that was the person responsible (so we don't draw as many random numbers). */
		if (npos==1)
			infector_index = 0;
		else
			infector_index = find_who_infected(npos,total_hazard_ignore_circ); 
		
		if (susceptible -> partner_pairs_HIVpos[infector_index] -> ptr[partner_gender] -> HIV_status == ACUTE)
			PANGEA_N_ANNUALACUTEINFECTIONS++;
		
		/* Phylogenetic transmission outputs (file TRM.csv): */
		store_phylogenetic_transmission_output(time_infect, susceptible,susceptible -> partner_pairs_HIVpos[infector_index] -> ptr[partner_gender]);
		//printf("Individual %d is infected by individual %d\n",susceptible->id,susceptible -> partner_pairs_HIVpos[infector_index] -> ptr[partner_gender]->id);
	}

}

/* In the event that someone has more than 1 HIV+ partner when they are infected, determine which of those partners was responsible.
 * total_hazard is the total probability of seroconversion in that timestep, and we have stored the contributions to this
 * hazard in  the (global) array PER_PARTNERSHIP_HAZARD_TEMPSTORE[]. Thus we draw weighted by these individual hazards to determine who 
 * infected that person. 
 * Output is the partner number of the person responsible. */
int find_who_infected(int numberpos_partners, double total_hazard){

	double temp_hazard = 0.0;
	int partner_i = 0;

	/* Pick a random number uniformly in [0,total_hazard). */
	double x = gsl_rng_uniform (rng) * total_hazard;
	temp_hazard = PER_PARTNERSHIP_HAZARD_TEMPSTORE[partner_i];
	while ((temp_hazard<x) && (partner_i<numberpos_partners-1)){
		partner_i += 1;
		temp_hazard += PER_PARTNERSHIP_HAZARD_TEMPSTORE[partner_i];
	}

	return partner_i;
}


/* Function firstly sets the n_HIVpos_partners attribute of the seroconverter to zero (note: this variable is only >0 if the individual is HIV-, 
 * as well as has HIV+ partners, and it is -1 for someone who is HIV+).
 * Then the function goes through each partner of the seroconverter in turn to see which are HIV-.
 * For each HIV- partner they are informed that they now have a seropositive partner (ie the seroconverter),
 * and if this HIV- partner did not have any seropositive partners before they were not in the 
 * susceptible_in_serodiscordant_partnership list, and hence are now added to this list. */
void inform_partners_of_seroconversion_and_update_list_serodiscordant_partnerships(individual* seroconverter,
		individual** susceptible_in_serodiscordant_partnership, long *n_susceptible_in_serodiscordant_partnership){

	int i;
	int partner_gender = 1 - seroconverter -> gender; /* The gender of (all) partners of this seroconverter. */
	/* This is a pointer to each partner in turn. We use it as an alias to save on code. */
	individual* temp_partner;

	/* Firstly update the list of serodiscordant and seropositive partners.
	 * This person has just seroconverted, so set the count of HIV+ and serodiscordant partners to zero as we no longer care 
	 * about them. The list of indices does not need changing as this counter tells us everything we need to know. */
	seroconverter -> n_HIVpos_partners = 0;


	/* Note: n_partners can be zero for imported cases (i.e. those in which we seed the infection).
	 * However the for loop takes this into account. */
	for (i=0;i< seroconverter -> n_partners ; i++){
		/* This is a pointer to the ith partner of the seroconverter (it points to an already allocated person so no malloc needed): */
		temp_partner = seroconverter -> partner_pairs[i] -> ptr[partner_gender]; 
		if ((temp_partner -> HIV_status) == 0) /* if the partner is currently seronegative: */
		{
			/* Note: temp_partner->n_HIVpos_partners is the number of HIV+ partners of this partner (prior to current seroconversion). */

			/* Add the serconverter to the array of HIVpos partners of temp_partner: */
			temp_partner -> partner_pairs_HIVpos[temp_partner -> n_HIVpos_partners] = seroconverter -> partner_pairs[i];

			/* Add one to the partner's n_HIVpos_partners counter: */
			temp_partner -> n_HIVpos_partners++;

			/* This partnership has become serodiscordant so, unless the HIV- temp_partner was already in the list 
			 * of susceptible_in_serodiscordant_partnership, they have to be added there. */
			if(temp_partner->idx_serodiscordant == -1 )   /* This means before seroconversion of seroconverter, this individual was in no serodiscordant couple */
				add_susceptible_to_list_serodiscordant_partnership(temp_partner, susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership);

		}
		/* As of May 1 2014 we are doing nothing if the partner is currently seropositive: */
	}

	/* remove the seroconverter from list of susceptibles in serodiscordant partnerships if appropriate */
	remove_susceptible_from_list_serodiscordant_partnership(seroconverter, susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership);
}


/* Function sets variables related to HIV in the individual structure for a newly infected individual. 
 * Allocates what the next hiv-related event to happen is: CD4 progression or AIDS death/emergency start ART
 * Also updates the counts of incident and prevalent cases. */
void new_infection(double time_infect, int SEEDEDINFECTION, individual* seroconverter, 
		population_size_one_year_age *n_infected, population_size_one_year_age *n_newly_infected, 
		age_list_struct *age_list, parameters *param, individual ***hiv_pos_progression, 
		long *n_hiv_pos_progression, long *size_hiv_pos_progression){ 
	if(seroconverter->id==FOLLOW_INDIVIDUAL){
		printf("New HIV infection for adult %ld at time %f\n",seroconverter->id,time_infect);
		fflush(stdout);
	}

	/* SEEDEDINFECTION tells us whether this is one of the initial infections seeded at time start_time_hiv, or an infection acquired since then.
	 * For seeded infections we start them in chronic infection (to avoid a wave of initial acutes). */ 
	long ncheck; 
	int spvl,aa;
	double time_to_next_event;
	int array_index_for_next_event;

	seroconverter -> t_sc = time_infect; /* Store the time at which they got infected. */

	seroconverter -> viral_load = 200000; //// VL reference? Currently we are not using this (Sept 2014) so this is a dummy value. However VL may change over time.
	/* Now ARTNAIVE means someone who has tested positive but never been on ART. */
	////seroconverter -> ART_status = ARTNAIVE;   /* Never been on ART - note this isn't really needed as by default nobody is on ART. */

	/* Draw SPVL (use dummy variable spvl as it makes code more readable): */
	double x = gsl_rng_uniform (rng);
	if (x<param->cumulative_p_initial_spvl_cat[0])      spvl = 0;
	else if (x<param->cumulative_p_initial_spvl_cat[1]) spvl = 1;
	else if (x<param->cumulative_p_initial_spvl_cat[2]) spvl = 2;
	else spvl = 3;

	seroconverter->SPVL = spvl;

	/* Now draw CD4 category for when we reach end of acute phase (if not seeded infection), otherwise where a seeded infection starts: */
	x = gsl_rng_uniform (rng);
	if (x<param->cumulative_p_initial_cd4_gt500[spvl])        seroconverter->cd4 = 0;
	else if (x<param->cumulative_p_initial_cd4_350_500[spvl]) seroconverter->cd4 = 1;
	else if (x<param->cumulative_p_initial_cd4_200_350[spvl]) seroconverter->cd4 = 2;
	else{
		seroconverter->cd4 = 3;
	}


	if(seroconverter->id==FOLLOW_INDIVIDUAL){
		printf("Initial CD4 for adult %ld at time %f is %i\n",seroconverter->id,time_infect,seroconverter->cd4);
		fflush(stdout);
	}
	if (SEEDEDINFECTION==FALSE){
		seroconverter -> HIV_status = ACUTE;      /* Person is now in acute stage. */ 
		/* Now draw time to end of acute phase: */
		time_to_next_event = param->min_dur_acute + gsl_rng_uniform(rng) * (param->max_dur_acute-param->min_dur_acute);

		//set_up_next_HIV_event(seroconverter,time_infect,param);
		/* In the absence of PopART assume that progression is just to next CD4 stage. */
		seroconverter->next_HIV_event = HIVEVENT_ENDOFACUTE;
	}
	else{ /* This is someone who is a seeded infection - assume these are all (just starting) chronic stage. */
		seroconverter -> HIV_status = CHRONIC;      /* Person is now in chronic stage. */
		/* Now draw time to next CD4 stage: */
		time_to_next_event = param->time_hiv_event[seroconverter->cd4][seroconverter->SPVL][0] + gsl_rng_uniform(rng) * (param->time_hiv_event[seroconverter->cd4][seroconverter->SPVL][1] - param->time_hiv_event[seroconverter->cd4][seroconverter->SPVL][0]);

		/* Note these are seeded infections so there is NO ART at this point! So progression is just to next CD4 stage. */
		if (seroconverter->cd4<3)
			seroconverter->next_HIV_event = HIVEVENT_CD4_PROGRESSION;
		else
			seroconverter->next_HIV_event = HIVEVENT_AIDSDEATH;
	}

	array_index_for_next_event = (int) round(((time_infect-param->start_time_hiv) + time_to_next_event) * N_TIME_STEP_PER_YEAR);
	seroconverter->DEBUGTOTALTIMEHIVPOS +=time_to_next_event;

	seroconverter->PANGEA_t_prev_cd4stage = time_infect;
	seroconverter->PANGEA_t_next_cd4stage = time_infect + time_to_next_event;
	/*None of these are used as already initialized to -1.0 (but could implement this code block as a check if needed)
		seroconverter->PANGEA_cd4atdiagnosis = -1.0;
		seroconverter->PANGEA_cd4atfirstART = -1.0;
		seroconverter->PANGEA_date_firstARTstart = -1.0;
		seroconverter->PANGEA_date_startfirstVLsuppression = -1.0;
		seroconverter->PANGEA_date_endfirstVLsuppression = -1.0;
	 */

	seroconverter->idx_hiv_pos_progression[0] = array_index_for_next_event;
	seroconverter->idx_hiv_pos_progression[1] = n_hiv_pos_progression[array_index_for_next_event];

	/* Check if we've run out of memory: */
	if (n_hiv_pos_progression[array_index_for_next_event]>=(size_hiv_pos_progression[array_index_for_next_event])){
		size_hiv_pos_progression[array_index_for_next_event] += RESIZEMEM;
		printf("Reallocating stuff now\n");
		fflush(stdout);
		hiv_pos_progression[array_index_for_next_event] = realloc(hiv_pos_progression[array_index_for_next_event],size_hiv_pos_progression[array_index_for_next_event]*sizeof(individual*));
		if (hiv_pos_progression[array_index_for_next_event] == NULL){
			printf("Unable to re-allocate hiv_pos_progression[i]. Execution aborted.");
			fflush(stdout);
			exit(1);
		}
	}	
	hiv_pos_progression[array_index_for_next_event][n_hiv_pos_progression[array_index_for_next_event]] = seroconverter;
	n_hiv_pos_progression[array_index_for_next_event]++;

	/*if(seroconverter->id==6313)
	{
		printf("Check this seroconversion");
		fflush(stdout);
	}*/

	//// DEBUG THIS:
	/*	int aa,ai;
	for (aa=0; aa<(MAX_AGE-AGE_ADULT); aa++){
			//// FOR DEBUGGING ////
			//printf("aa = %d ; n_susceptible_in_serodiscordant_partnership = %ld\n",aa,n_susceptible_in_serodiscordant_partnership[0]);
			//fflush(stdout);
			ai = age_list->youngest_age_group_index + aa; 
			if (ai>(MAX_AGE-AGE_ADULT-1))
				ai = ai - (MAX_AGE-AGE_ADULT);
			long ncheck = 0;
			while ((ncheck<age_list->number_per_age_group[ai]) && (age_list->age_group[ai][ncheck]->id!=5007)){ 
				ncheck++;
			}
			if (ncheck<age_list->number_per_age_group[ai])
				if (age_list->age_group[ai][ncheck]->id==5007)
					printf("AI=%i\n AA=%i\n",ai,aa);

	}

	 */

	/* Now adding seroconverter to lists of infected individuals, in the right age category */

	//ai = get_age_index(seroconverter->DoB, param-> start_time_simul);
	aa = (int) floor(floor(time_infect) - seroconverter->DoB) - AGE_ADULT;
	/* DEBUGGING - CAN REMOVE ALL THE DIFFERENT AI HERE */

	if(aa<(MAX_AGE-AGE_ADULT)){

		//printf("Debug me!!!!! id=%li aa = %i DoB = %f time = %f\n",seroconverter->id,aa,seroconverter->DoB,time_infect);



		/* ai is the age index of the array n_infected->pop_size_per_gender_age1_risk[g][ai][r] for the person with DoB as above at t_infect. */


		int ai_prev = n_infected->youngest_age_group_index + aa;
		while (ai_prev>(MAX_AGE-AGE_ADULT-1))
			ai_prev = ai_prev - (MAX_AGE-AGE_ADULT);

		int ai_inc = n_newly_infected->youngest_age_group_index + aa;
		while (ai_inc>(MAX_AGE-AGE_ADULT-1))
			ai_inc = ai_inc - (MAX_AGE-AGE_ADULT);

		int ai_age = age_list->youngest_age_group_index + aa;
		while (ai_age>(MAX_AGE-AGE_ADULT-1))
			ai_age = ai_age - (MAX_AGE-AGE_ADULT);


		/* looking for the seroconverter in the age_list --> presumably only for debugging, could get rid of this? */
		ncheck = 0;
		while ((ncheck<age_list->number_per_age_group[ai_age]) && (age_list->age_group[ai_age][ncheck]->id!=seroconverter->id)){ 
			ncheck++;
		}
		if ((ncheck>=age_list->number_per_age_group[ai_age]))
			printf("PROBLEM: Person not found %li\n",seroconverter->id);

		/* adding the seroconverter to n_infected in the right age group */
		(n_infected->pop_size_per_gender_age1_risk[seroconverter->gender][ai_prev][seroconverter->sex_risk])++;

		/* adding the seroconverter to n_newly_infected in the right age group */
		(n_newly_infected->pop_size_per_gender_age1_risk[seroconverter->gender][ai_inc][seroconverter->sex_risk])++;
		//printf("+++ One new HIV+ \n");
		//fflush(stdout);
	}
	else{

		/* looking for the seroconverter in the age_list --> presumably only for debugging, could get rid of this? */
		ncheck = 0;
		while ((ncheck<age_list->number_oldest_age_group) && (age_list->oldest_age_group[ncheck]->id!=seroconverter->id)){ 
			ncheck++;
		}
		if ((ncheck>=age_list->number_oldest_age_group))
			printf("PROBLEM: Person not found %li\n",seroconverter->id);

		/* adding the seroconverter to n_infected in the right age group */
		(n_infected->pop_size_oldest_age_group_gender_risk[seroconverter->gender][seroconverter->sex_risk])++;

		/* adding the seroconverter to n_newly_infected in the right age group */
		(n_newly_infected->pop_size_oldest_age_group_gender_risk[seroconverter->gender][seroconverter->sex_risk])++;
		//printf("+++ One new HIV+ (old) \n");
		//fflush(stdout);
	}
}



/* Function is called to seed initial HIV infection.
 * It is a Bernoulli trial infecting individual indiv with probability 
 * param->initial_prop_infected_gender_risk[g][r] where g and r are the gender and risk of indiv. */
void draw_initial_infection(individual* indiv, parameters *param, 
		individual** susceptible_in_serodiscordant_partnership, 
		long *n_susceptible_in_serodiscordant_partnership, population_size_one_year_age *n_infected,
		population_size_one_year_age *n_newly_infected, age_list_struct *age_list, 
		individual ***hiv_pos_progression, long *n_hiv_pos_progression, long *size_hiv_pos_progression){

	double random = gsl_rng_uniform(rng);
	if(indiv->cd4==DEAD)
	{
		printf("Trying to make a dead person acquire HIV at HIV introduction.\n");
		fflush(stdout);
		exit(1);
	}
	if (random < param->initial_prop_infected_gender_risk[indiv->gender][indiv->sex_risk])
	{

		new_infection(param->start_time_hiv, TRUE, indiv, n_infected, n_newly_infected, age_list, param, hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression);

		inform_partners_of_seroconversion_and_update_list_serodiscordant_partnerships(indiv, susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership);
		/* Phylogenetics transmission outputs for seeded cases (these are dummy outputs signifying that they are seed infections): */
		store_phylogenetic_transmission_initial_cases(param, indiv);
		DEBUG_NHIVPOS++;
	}
}


/* Function determines what the next HIV-related event for a person is given their current state (CD4, SPVL, etc). 
 * Events are CD4 progression, AIDS death,  or starting ART because of CD4 low (bypassing testing - these are people who
 * have either never tested but turn up to clinic with AIDS symptoms, or who know they are HIV+ but previously 
 * left the care cascade. It also potentially increases the rate at which someone in the cascade can start ART when their CD4 gets low.
 */
void next_hiv_event(individual* indiv, individual ***hiv_pos_progression, long *n_hiv_pos_progression, long *size_hiv_pos_progression, parameters *param, double t, cumulative_outputs_struct *cumulative_outputs){
	double time_to_next_event;
	int array_index_for_next_event;
	if ((indiv->cd4<0) ||(indiv->cd4>3)){
		printf("ERROR: Unrecognised cd4  %i %li\n",indiv->cd4,indiv->id);
		exit(1);
	}

	double min_time = param->time_hiv_event[indiv->cd4][indiv->SPVL][0];
	double max_time = param->time_hiv_event[indiv->cd4][indiv->SPVL][1];

	time_to_next_event = min_time + gsl_rng_uniform(rng) * (max_time-min_time);

	/* If on ART but not virally suppressed, allow CD4 progression to be slower. */
	if (indiv->ART_status==LTART_VU)
		time_to_next_event = time_to_next_event * param->factor_for_slower_progression_ART_VU;

	/* Ensure we never have an event in the current timestep. */
	if ((time_to_next_event)<TIME_STEP)
		time_to_next_event=TIME_STEP;

	indiv->PANGEA_t_prev_cd4stage = indiv->PANGEA_t_next_cd4stage;
	indiv->PANGEA_t_next_cd4stage = t + time_to_next_event;



	/* Note: hiv event progression is mostly linear. The only branching possibility is that 
	 * if currently CD4<200, allow the person to start ART as an emergency rather than dying before starting ART:
	 * Note that we are assuming they are not already on ART. */
	if (indiv->cd4==3){
		if ((t>=param->COUNTRY_ART_START) && (indiv->ART_status!=LTART_VU)){
			double time_emergency_start_ART = get_time_emergency_start_ART(indiv,param,t);
			/* Decide if individual will start ART because of low CD4 (and symptoms) - at which point they may die quickly on ART - or die without starting ART: */
			if (time_emergency_start_ART<time_to_next_event){
				time_to_next_event = time_emergency_start_ART; 
				cumulative_outputs->N_total_CD4_tests_nonpopart++; // Assume always a non-popart test.
				indiv->next_HIV_event = HIVEVENT_STARTART_LOWCD4;
				if(indiv->id==FOLLOW_INDIVIDUAL){
					printf("Individual %ld time = %f is scheduled to start ART at time = %fin function next_hiv_event()\n",indiv->id,t,t+time_to_next_event);
					fflush(stdout);
				}
			}
			else{
				indiv->next_HIV_event = HIVEVENT_AIDSDEATH;
			}
		}
		/* If ART is not available yet, or if the person is on ART but virally unsuppressed, and CD4<200, then their next HIV event is AIDS death. */
		else{
			indiv->next_HIV_event = HIVEVENT_AIDSDEATH;
		}
	}

	else{
		/* Next event is CD4 progression: */		
		indiv->next_HIV_event = HIVEVENT_CD4_PROGRESSION;
	}

	indiv->DEBUGTOTALTIMEHIVPOS += time_to_next_event; 	
	/* This gets the index for hiv_pos_progression (and n_hiv_pos_progression and size_hiv_pos_progression) arrays. */
	array_index_for_next_event = (int) round(((t-param->start_time_hiv) + time_to_next_event) * N_TIME_STEP_PER_YEAR); 
	//printf("Time to next event for individual %li = %f %i\n",indiv->id,time_to_next_event,array_index_for_next_event);

	/* Only add an event if this happens before the end of the simulation: */
	if (array_index_for_next_event<=(param->end_time_simul - param->start_time_hiv)*N_TIME_STEP_PER_YEAR){
		if(indiv->id==FOLLOW_INDIVIDUAL){
			printf("Adding HIV progression event for %ld  at time = %f i=%i\n",indiv->id,t+time_to_next_event,array_index_for_next_event);
			fflush(stdout);
		}
		indiv->idx_hiv_pos_progression[0] = array_index_for_next_event;
		indiv->idx_hiv_pos_progression[1] = n_hiv_pos_progression[array_index_for_next_event];

		/* Check if we've run out of memory: */
		if (n_hiv_pos_progression[array_index_for_next_event]>=(size_hiv_pos_progression[array_index_for_next_event])){
			size_hiv_pos_progression[array_index_for_next_event] += RESIZEMEM;
			printf("Reallocating stuff for hiv_pos_progression now\n");
			fflush(stdout);
			hiv_pos_progression[array_index_for_next_event] = realloc(hiv_pos_progression[array_index_for_next_event],size_hiv_pos_progression[array_index_for_next_event]*sizeof(individual*));
			if (hiv_pos_progression[array_index_for_next_event] == NULL){
				printf("Unable to re-allocate hiv_pos_progression[i]. Execution aborted.");
				fflush(stdout);
				exit(1);
			}
		}	
		hiv_pos_progression[array_index_for_next_event][n_hiv_pos_progression[array_index_for_next_event]] = indiv;
		n_hiv_pos_progression[array_index_for_next_event]++;

	}
	else{
		/* Next event happens after end of simulation so set to no event. */
		indiv->idx_hiv_pos_progression[0] = NOEVENT;
		indiv->idx_hiv_pos_progression[1] = -1;
		
		if(indiv->id==FOLLOW_INDIVIDUAL){
			printf("Not scheduling HIV progression event for %ld as after end of simulation at t=%f\n",indiv->id,t+time_to_next_event);
			fflush(stdout);
		}
	}
	if(indiv->id==FOLLOW_INDIVIDUAL){
		printf("Next HIV progression event for %ld is scheduled to be %i at t=%f\n",indiv->id,indiv->next_HIV_event,t+time_to_next_event);
		fflush(stdout);
	}
}



/* Go through the list of scheduled HIV events for HIV+ people for this timestep (stored in hiv_pos_progression). 
 * For each person to whom some HIV event happens, draw their next HIV-based event (via next_hiv_event) 
 * unless they die from AIDS at this timestep.
 * */
void carry_out_HIV_events_per_timestep(double t,individual ***hiv_pos_progression, long *n_hiv_pos_progression, long *size_hiv_pos_progression, 
		parameters *param,age_list_struct *age_list, population_size *n_population,  population_size_one_year_age *n_infected, 
		stratified_population_size *n_population_stratified, individual **susceptible_in_serodiscordant_partnership, 
		long *n_susceptible_in_serodiscordant_partnership, population_partners *pop_available_partners, population_size *n_pop_available_partners,
		individual ***cascade_events, long *n_cascade_events, long *size_cascade_events, cumulative_outputs_struct *cumulative_outputs){

	int array_index_for_hiv_event = (int) round((t-param->start_time_hiv)*N_TIME_STEP_PER_YEAR);
	int n_events = n_hiv_pos_progression[array_index_for_hiv_event];
	individual *indiv;
	int n;

	for (n=0; n<n_events; n++){
		indiv = hiv_pos_progression[array_index_for_hiv_event][n];
		if (indiv->cd4==DEAD){
			/* Move on to the next person. Note - we can set up a similar procedure to other lists to remove this person from this list but
			   it is not necessary. As things stand, no hiv event happens to the dead person and no new event is scheduled for them. */
			continue;
		}
		
		/* Decide if we kill this person: */
		if (indiv->next_HIV_event==HIVEVENT_AIDSDEATH){
			remove_from_cascade_events(indiv, cascade_events, n_cascade_events, size_cascade_events,t, param);
			/* Function removes person from everything except the cascade event list: */
			individual_death_AIDS(age_list, indiv, n_population, n_infected, n_population_stratified, t, param, 
					susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership, pop_available_partners, n_pop_available_partners, cascade_events, n_cascade_events, size_cascade_events);
		}
		else{
			/* At this point "indiv->next_HIV_event" is what happens to them now. We then draw a new "next event" after. */
			if(indiv->next_HIV_event==HIVEVENT_ENDOFACUTE)
				indiv->HIV_status = CHRONIC; /* Note that CD4 has already been assigned upon seroconversion. */
			else if (indiv->next_HIV_event==HIVEVENT_CD4_PROGRESSION){
				if (indiv->cd4<0){
					printf("ERROR - trying to advance CD4 state=%i for id=%ld when negative (-1 = uninfected, -2=dead). Exiting!\n",indiv->cd4,indiv->id);
					fflush(stdout);
					exit(1);
				}
				indiv->cd4 ++; /* Increase CD4 category by 1. */
			}
			else if (indiv->next_HIV_event==HIVEVENT_STARTART_LOWCD4){
				if(indiv->id==FOLLOW_INDIVIDUAL){
					printf("Starting emergency ART for adult %ld\n",indiv->id);
					fflush(stdout);
				}

				/* Assume that HIV test still occurs at this point: */
				indiv->time_last_hiv_test = t;

				/* PANGEA stuff - get CD4 at time of emergency ART: */
				indiv->PANGEA_t_diag = t;
				indiv->PANGEA_cd4atdiagnosis = PANGEA_get_cd4(indiv, t);

				// Assume that HIV test happens at same time as start of ART:

				if (indiv->PANGEA_date_firstARTstart<0){
				  indiv->PANGEA_date_firstARTstart = t;
				  indiv->PANGEA_cd4atfirstART = PANGEA_get_cd4(indiv, t);
				}


				/* The last parameter in start_ART() states that this individual started ART because of AIDS symptoms. */
				start_ART_process(indiv,param, t, cascade_events, n_cascade_events, size_cascade_events, hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression,1);   /* Starts indiv on ART at low CD4. This function can be used to add in stuff like mortality. */
			}
			else{
				printf("ERROR: Unknown HIV event %i for id=%li with indices %i %i %li %li. Exiting.\n",indiv->next_HIV_event,indiv->id,array_index_for_hiv_event,n,indiv->idx_hiv_pos_progression[0],indiv->idx_hiv_pos_progression[1]);
				fflush(stdout);
				exit(1);
			}
			/* Now decide what will happen to them next. If they start ART this is dealt with in cascade_events (including AIDS death)
			 * , so do not schedule a new HIV-related event unless they stop ART. */
			if (indiv->next_HIV_event!=HIVEVENT_STARTART_LOWCD4){
				next_hiv_event(indiv, hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression, param, t, cumulative_outputs);
			}
		}
	}

	/* We don't need this any more so  the memory: */
	//free(hiv_pos_progression[array_index_for_hiv_event]);

}



/* Window function for HIV test of positive person (to allow for the fact that antibody/antigen tests do not work
 * for the first few weeks. 0 means person tests negative, 1 means tests positive. */
int get_window_result(double time_since_sc,double t, parameters *param){
	if (param->cluster_number<=IS_ZAMBIA){
		if (t<=2006){
			if (time_since_sc>=60.0/365)
				return 1;
			else
				return 0;
		}
		else{
			if (time_since_sc>=30.0/365)
				return 1;
			else
				return 0;
		}
	}
	else{
		if (t<=2010){
			if (time_since_sc>=60.0/365)
				return 1;
			else
				return 0;
		}
		else{
			if (time_since_sc>=30.0/365)
				return 1;
			else
				return 0;
		}
	}
}


/* Function determines if a person indiv will join pre-ART care or not as a function of time, their CD4, etc. 
 * Note that at present it is really "1- probability that do not stay in care or start ART". */
int joins_preart_care(individual* indiv, parameters *param, double t, cumulative_outputs_struct *cumulative_outputs){
	
	/* This tells us if the cd4 test is due to PopART (is_popart=1) or not (is_popart=0). */
	int is_popart = (indiv->next_cascade_event>=NCASCADEEVENTS_NONPOPART);
	//printf("joins_preart_care is_popart= %i\n",is_popart);
	if (is_popart==NOTPOPART){
		/* Divide into CD4>200 and CD4<=200: */
		if (indiv->cd4<3){
			/* Collects HIV test results: */
			if (gsl_ran_bernoulli(rng,param->p_collect_hiv_test_results_cd4_over200)==1){
				/* gsl_ran_bernoulli returns 0 (drops out)/1 (stays in cascade). */
				/* At this point they have their first CD4 test: */
				cumulative_outputs->N_total_CD4_tests_nonpopart++;
				return gsl_ran_bernoulli(rng,param->p_collect_cd4_test_results_cd4_over200);
			}
			/* Does not collect HIV test results: */
			else{
				return 0; /* Drops out of cascade as does not collect HIV test results. */
			}
		}
		else{
			/* Collects HIV test results: */
			if (gsl_ran_bernoulli(rng,param->p_collect_hiv_test_results_cd4_under200)==1){
				/* gsl_ran_bernoulli returns 0 (drops out)/1 (stays in cascade). */
				/* At this point they have their first CD4 test: */
				cumulative_outputs->N_total_CD4_tests_nonpopart++;
				return gsl_ran_bernoulli(rng,param->p_collect_cd4_test_results_cd4_under200);
			}
			/* Does not collect HIV test results: */
			else{
				return 0; /* Drops out of cascade as does not collect HIV test results. */
			}
		}
	}
	else{     /* PopART - assume everyone gets their HIV test so just whether they collect their CD4 results: */
		/* Divide into CD4>200 and CD4<=200: */
		if (indiv->cd4<3){
			cumulative_outputs->N_total_CD4_tests_popart++;
			/* gsl_ran_bernoulli returns 0 (drops out)/1 (stays in cascade). */
			return gsl_ran_bernoulli(rng,param->p_collect_cd4_test_results_cd4_over200);
		}
		else{
			cumulative_outputs->N_total_CD4_tests_popart++;
			/* gsl_ran_bernoulli returns 0 (drops out)/1 (stays in cascade). */
			return gsl_ran_bernoulli(rng,param->p_collect_cd4_test_results_cd4_under200);
		}
	}
}

/* Function is the probability that an HIV+ person remains in the care cascade until the next CD4 test 
 * when they've just had a CD4 test and were not eligible. 
 * Notes on code: May make a function of time (explicitly)? Currently it's a bunch of "coin flips"
 *  until you leave or become eligible. */
int remains_in_cascade(individual* indiv, parameters *param, double t){

	/* Divide into CD4>200 and CD4<=200: */
	if (indiv->cd4<3){
		/* Gets CD4 tested. gsl_ran_bernoulli returns 0 (drops out)/1 (stays in cascade). */
		return gsl_ran_bernoulli(rng,param->p_collect_cd4_test_results_cd4_over200);
	}
	else{
		/* Gets CD4 tested.  gsl_ran_bernoulli returns 0 (drops out)/1 (stays in cascade). */
		return gsl_ran_bernoulli(rng,param->p_collect_cd4_test_results_cd4_under200);
	}
}

/* Given a 'real' CD4 category, draws the measured CD4 based on ATHENA paper data on misclassification. */ 
int measured_cd4_cat(parameters *param, int real_cd4_cat){
	double x = gsl_rng_uniform(rng);	
	int i=0;

	while ((i<NCD4) && (param->cumulative_p_misclassify_cd4[real_cd4_cat][i]<x)){
		i++;    /* Note that the final value of i will be the measured CD4 cat. */
	}
	return i;
}

	
/* Function gives the highest CD4 group which is eligible for ART at time t in a given setting.
 * Function returns the index corresponding to that group. E.g. if the function returns 2, then
 * CD4=2 and CD4=3 are eligible for ART - in other words CD4<350. */	
int art_cd4_eligbility_group(parameters *param, double t){
	
	if (t<param->COUNTRY_ART_START)
		return 4; /* Nobody eligible before start of ART. */
	
	if (param->cluster_number<=IS_ZAMBIA){
		/* CD4 200 threshold before ???2010?. */
		if (t<=2010.0)
			return 3; /* CD4<200. */
		else if (t<=2014.5)
			return 2; /* CD4 350 threshold before xxx 2014. */
		else
			return 1; /* CD4 500 threshold. */
	}
	/* South Africa eligibility. <200 before 12 August 2011
	 *  changes to <350 (http://www.tac.org.za/community/node/3118 and http://www.sajhivmed.org.za/index.php/sajhivmed/article/view/805/654)
	 *  2015: changes to <500
	 */
	else{		
		if (t<=2011.0)
			return 3; /* CD4 <200 threshold  */
		else if (t<=2015.0)
			return 2; /* CD4 <350 threshold. */
		else 
			return 1; /* CD4 <500 threshold. */
	}
}
	
/* Function gives a 1 or 0 depending if an individual indiv is eligible for ART or not at time t in a given country.
 * Includes mis-measurement of CD4. */
int is_eligible_for_art(individual* indiv, parameters *param, double t){

	/* if before ART in country then end. */
	if (t<=param->COUNTRY_ART_START)
		return 0;
	
	/* If Popart and we are in arm A then always eligible: */
	if ((t>=param->POPART_START) && (t<=param->POPART_END) && (TRIAL_ARM==ARM_A))
		return 1;

	int measuredcd4 = measured_cd4_cat(param, indiv->cd4);
	if (measuredcd4>=art_cd4_eligbility_group(param,t))
		return 1;
	else
		return 0;
}


/* This is the length of time it takes to start ART once your CD4 goes below 200. 
 * At present it is drawn from an identical distribution to that of the time it takes to go from 200 to death.
 * Thus 50% of people will die before starting emergency ART. 
 * CAn revisit once we have data. 
 * ASSUMPTION!!!*/ 
double get_time_emergency_start_ART(individual* indiv, parameters *param, double t){
	/* note: indiv->cd4 should always be 3 here */
	double time_to_start_emergency_art = t+param->time_hiv_event[indiv->cd4][indiv->SPVL][0] + gsl_rng_uniform(rng) * (param->time_hiv_event[indiv->cd4][indiv->SPVL][1] - param->time_hiv_event[indiv->cd4][indiv->SPVL][0]);
	if (time_to_start_emergency_art<param->end_time_simul)
		return time_to_start_emergency_art;
	else
		return param->end_time_simul;
}




/* Sets up state when beginning ART (including emergency ART). This state represents the first few months of ART
 * when the individual is becoming virally suppressed and may be more likely to drop out or die. 
 * This function also determines what happens in the next cascade step after someone starts ART 
 * (ie viral suppression, on ART but not virally suppressed, drops out, dies due to AIDS-related illness).
 * Note: If is_emergency==1, this means they started because of AIDS symptoms at low CD4 (so can increase mortality rate): 
 */
void start_ART_process(individual* indiv, parameters *param, double t, individual ***cascade_events, long *n_cascade_events, long *size_cascade_events, individual ***hiv_pos_progression, long *n_hiv_pos_progression, long *size_hiv_pos_progression, int is_emergency){

	/* No further CD4 progression (or other hiv_pos_progression[] events happens to them when they start ART. Note that AIDS death is handled 
	 * in cascade_events in this state (representing things such as immune reconstitution inflammatory syndrome, where AIDS mortality is potentially higher) 
	 * By comparison for somoneone not on ART they can die from AIDS through events scheduled in hiv_pos_progression[]. */
	if(indiv->id==FOLLOW_INDIVIDUAL){
		printf("Removing %li from HIV pos progression as starting ART. Old (to be removed) array event = %li %li \n",indiv->id,indiv->idx_hiv_pos_progression[0],indiv->idx_hiv_pos_progression[1]);
		fflush(stdout);
	}	
	remove_from_hiv_pos_progression(indiv,  hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression,t, param);
	indiv->next_HIV_event = NOEVENT;
	indiv->idx_hiv_pos_progression[0] = -1;
	indiv->idx_hiv_pos_progression[1] = -1;
	indiv->ART_status = EARLYART;

	/* This tells us if the cd4 test is due to PopART (is_popart=1) or not (is_popart=0). */
	int is_popart = (indiv->next_cascade_event>=NCASCADEEVENTS_NONPOPART);
	
	//printf("start_ART_process is_popart= %i\n",is_popart);
	
	/* Now schedule what the next cascade event will be for them: */
	double x = gsl_rng_uniform (rng);
	double p_dropout;
	double time_to_next_event;

	/* Drops out of ART care: */
	if (indiv->cd4<3)                /* CD4>200 */
		p_dropout = param->p_leaves_earlyart_cd4_over200;
	else
		p_dropout = param->p_leaves_earlyart_cd4_under200;
	if (x<p_dropout){
		if (is_popart==NOTPOPART){
			indiv->next_cascade_event = CASCADEEVENT_DROPOUT_NONPOPART;			
			time_to_next_event = t + param->t_earlyart_dropout_min[NOTPOPART] + gsl_rng_uniform (rng)*param->t_earlyart_dropout_range[NOTPOPART]+TIME_STEP;
		}
		else{
			indiv->next_cascade_event = CASCADEEVENT_DROPOUT_POPART;
			// assumed takes 0-6 months!!!
			time_to_next_event = t + param->t_earlyart_dropout_min[POPART]    + gsl_rng_uniform (rng)*param->t_earlyart_dropout_range[POPART]+TIME_STEP;
		}
		if(indiv->id==FOLLOW_INDIVIDUAL){
			printf("Scheduling next cascade event after initiating ART for adult %ld: dropout \n",indiv->id);
			fflush(stdout);
		}
	}
	/* Dies while on ART: */
	else if (x<(p_dropout+param->p_dies_earlyart_cd4[indiv->cd4])){
		if (is_popart==NOTPOPART){
			indiv->next_cascade_event = CASCADEEVENT_ARTDEATH_NONPOPART;
			time_to_next_event = t + param->t_dies_earlyart_min[NOTPOPART] + gsl_rng_uniform (rng)*param->t_dies_earlyart_range[NOTPOPART]+TIME_STEP;
		}
		else{
			indiv->next_cascade_event = CASCADEEVENT_ARTDEATH_POPART;
			time_to_next_event = t + param->t_dies_earlyart_min[POPART] + gsl_rng_uniform (rng)*param->t_dies_earlyart_range[POPART]+TIME_STEP;
		}
		if(indiv->id==FOLLOW_INDIVIDUAL){
			printf("Scheduling next cascade event after initiating ART for adult %ld: dies on ART \n",indiv->id);
			fflush(stdout);
		}
	}
	/* Becomes virally suppressed on ART. */
	else if (x<(p_dropout+param->p_dies_earlyart_cd4[indiv->cd4] + param->p_becomes_vs_after_earlyart)){
		if (is_popart==NOTPOPART){
			indiv->next_cascade_event = CASCADEEVENT_VS_NONPOPART;
			time_to_next_event = t+gsl_rng_uniform (rng)*param->t_end_early_art+TIME_STEP;
		}
		else{
			indiv->next_cascade_event = CASCADEEVENT_VS_POPART;
			time_to_next_event = t+gsl_rng_uniform (rng)*param->t_end_early_art+TIME_STEP;
		}
		if(indiv->id==FOLLOW_INDIVIDUAL){
			printf("Scheduling next cascade event after initiating ART for adult %ld: VS \n",indiv->id);
			fflush(stdout);
		}
	}
	/* Continues on ART but not fully virally suppressed. */
	else {
		if (is_popart==NOTPOPART){
			indiv->next_cascade_event = CASCADEEVENT_VU_NONPOPART;
			time_to_next_event = t+gsl_rng_uniform (rng)*param->t_end_early_art+TIME_STEP;
		}
		else{
			indiv->next_cascade_event = CASCADEEVENT_VU_POPART;
			time_to_next_event = t+gsl_rng_uniform (rng)*param->t_end_early_art+TIME_STEP;
		}
		if(indiv->id==FOLLOW_INDIVIDUAL){
			printf("Scheduling next cascade event after initiating ART for adult %ld: VU \n",indiv->id);
			fflush(stdout);
		}		
	}
	schedule_generic_cascade_event(indiv, param, time_to_next_event, cascade_events, n_cascade_events, size_cascade_events);

	if(indiv->id==FOLLOW_INDIVIDUAL){
		printf("Scheduling next cascade event after initiating ART for adult %ld event = %i at array indices %ld %ld\n",indiv->id,indiv->next_cascade_event,indiv->idx_cascade_event[0],indiv->idx_cascade_event[1]);
		fflush(stdout);
	}
	return;
}

/* When HIV testing first begins in the country (or after PopART ends, 
 * if we switch back to clinic-based testing this function is called from simul.c.
 * Function goes through every individual currently alive (using the array age_list) 
 * and schedules an HIV test for each person in the array cascade_events[].  */
void draw_initial_hiv_tests(parameters *param, age_list_struct *age_list, double t, individual ***cascade_events, long *n_cascade_events, long *size_cascade_events){
	int aa,k;
	/* for all but the age group 80+ (which is in a separate part of the age_list struct). */
	for (aa=0; aa<MAX_AGE-AGE_ADULT; aa++){ 
		/* for each individual in that annual age group, schedule their first HIV test: */
		for (k=0; k<age_list->number_per_age_group[aa] ; k++){ 
			schedule_new_hiv_test(age_list->age_group[aa][k], param, t, cascade_events, n_cascade_events, size_cascade_events);
			if(age_list->age_group[aa][k]->id==FOLLOW_INDIVIDUAL){
				printf("Scheduling first HIV test for adult %ld (event type %i)at time index %li, array index = %li\n",age_list->age_group[aa][k]->id,age_list->age_group[aa][k]->next_cascade_event,age_list->age_group[aa][k]->idx_cascade_event[0],age_list->age_group[aa][k]->idx_cascade_event[1]);
				fflush(stdout);
			}
		}
	}

	/* For the last age group: 
	 * Note - we may decide to switch this off. */
	for (k=0; k<age_list->number_oldest_age_group ; k++){ /* for each individual in that age group */ 
		schedule_new_hiv_test(age_list->oldest_age_group[k], param, t, cascade_events, n_cascade_events, size_cascade_events);
		if(age_list->oldest_age_group[k]->id==FOLLOW_INDIVIDUAL){
			printf("Scheduling first HIV test  (at current time %f) for OLDEST adult %ld (event type %i)at time index %li, array index = %li\n",t,age_list->oldest_age_group[k]->id,age_list->oldest_age_group[k]->next_cascade_event,age_list->oldest_age_group[k]->idx_cascade_event[0],age_list->oldest_age_group[k]->idx_cascade_event[1]);
			fflush(stdout);
		}
	}
}


/* Each cascade event (HIV test, CD4 test, start/interrupt ART) has the same format for scheduling events.
 * This function schedules the event in the array cascade_events[] */
void schedule_generic_cascade_event(individual* indiv, parameters *param, double t, individual ***cascade_events, long *n_cascade_events, long *size_cascade_events){
	/* This is the index for cascade_events (and n_cascade_events and size_cascade_events) arrays. */
	int array_index_for_event = (int) (round((t - param->COUNTRY_HIV_TEST_START) * N_TIME_STEP_PER_YEAR));

	if (array_index_for_event<=(param->end_time_simul - param->COUNTRY_HIV_TEST_START)*N_TIME_STEP_PER_YEAR){

		indiv->idx_cascade_event[0] = array_index_for_event;
		indiv->idx_cascade_event[1] = n_cascade_events[array_index_for_event];
		if(indiv->id==FOLLOW_INDIVIDUAL){
			printf("New generic cascade event call for adult %ld generated with array indices  %ld %ld\n",indiv->id,indiv->idx_cascade_event[0],indiv->idx_cascade_event[1]);
			fflush(stdout);
		}

		/* Check if we've run out of memory: */
		if (n_cascade_events[array_index_for_event]>=(size_cascade_events[array_index_for_event])){
			size_cascade_events[array_index_for_event] += RESIZEMEM;
			printf("Reallocating stuff for cascade_events now\n");
			fflush(stdout);
			cascade_events[array_index_for_event] = realloc(cascade_events[array_index_for_event],size_cascade_events[array_index_for_event]*sizeof(individual*));
			if (cascade_events[array_index_for_event] == NULL){
				printf("Unable to re-allocate cascade_events[i]. Execution aborted.");
				fflush(stdout);
				exit(1);
			}
		}	
		cascade_events[array_index_for_event][n_cascade_events[array_index_for_event]] = indiv;
		n_cascade_events[array_index_for_event]++;
	}
	else{
		/* If next event scheduled for after the end of the simulation set this all to be dummy entries. */
		indiv->idx_cascade_event[0] = NOEVENT;
		indiv->idx_cascade_event[1] = -1;
		//printf("No event scheduled for %li as the next event lies after the end of the simulation.\n",indiv->id);
	}
}


/* For a given individual draws when they will next have an HIV test. 
 * Only people who have never been tested or previously received a negative test are scheduled to be tested. */
void schedule_new_hiv_test(individual* indiv, parameters *param, double t, individual ***cascade_events, long *n_cascade_events, long *size_cascade_events){

	/* This tells us if the cd4 test is due to PopART (is_popart=1) or not (is_popart=0). */
	int is_popart = (indiv->next_cascade_event>=NCASCADEEVENTS_NONPOPART);

	//printf("schedule_new_hiv_test is_popart= %i %i\n",is_popart,indiv->next_cascade_event);
	
	/* See file HIV testing function.xlsx to see what this looks like.
	note - format is hill_down(x,max_val,exponent,midpoint), where midpoint is time (since t=0) at which midpoint occurs. hill_down->0 as x->infty */
	double mean_time_to_test = 1.0 + hill_down(t - param->COUNTRY_HIV_TEST_START, 12.0, 4, 8.0);
	//double mean_time_to_test = 250; //1.0 + hill_down(t - param->COUNTRY_HIV_TEST_START, 5.0, 2.5, 20.0);
	
	double x = gsl_ran_exponential(rng, mean_time_to_test); /* probably exponential not best suited think about better parameterization */
	if (x<=TIME_STEP)
		x = TIME_STEP;
	double time_hiv_test = t + x;
	if(indiv->id==FOLLOW_INDIVIDUAL){
		printf("\nt=%f, index=%i. New HIV test for adult %ld scheduled at future time %f. Mean time to test = %f\n",t,(int) (round((t - param->COUNTRY_HIV_TEST_START) * N_TIME_STEP_PER_YEAR)),indiv->id,time_hiv_test,mean_time_to_test);
		fflush(stdout);
	}
	// Error conditional jump after here according to valgrind 12/1/15.
	/* Some people never test (as exponential distribution we truncate any tests occuring after the end of the simulation. */
	//printf("%i %i %d %f\n",is_popart,NOTPOPART,param->end_time_simul,time_hiv_test);
	
	if (time_hiv_test<(param->end_time_simul)){
		/* Now call schedule_generic_cascade_event() to actually schedule the event: */
		if (is_popart==NOTPOPART)
			indiv->next_cascade_event = CASCADEEVENT_HIV_TEST_NONPOPART;
		else
			indiv->next_cascade_event = CASCADEEVENT_HIV_TEST_POPART;
		schedule_generic_cascade_event(indiv, param, time_hiv_test, cascade_events, n_cascade_events, size_cascade_events);
	}
	else{
		/* Note that we do not need to unschedule this indiv from the cascade_event list as the event is this one
		 * and we are moving on in time. */
		indiv->next_cascade_event = NOEVENT;
		indiv->idx_cascade_event[0] = NOEVENT;
		indiv->idx_cascade_event[1] = -1;
	}
	
}

/* This carries out the processes of someone testing, and assigns them a next event based on the test result
 * (ie start ART, wait in care, drop out of care). 
 * is_popart takes the values 0 (not popart) and 1 (popart) to indicate whether testing is PopART-run (CHiPs) or not.
 * PopART testing 
 * */
void hiv_test_process(individual* indiv, parameters *param, double t, individual ***cascade_events, 
		long *n_cascade_events, long *size_cascade_events, individual ***hiv_pos_progression, 
		long *n_hiv_pos_progression, long *size_hiv_pos_progression, cumulative_outputs_struct *cumulative_outputs,
		individual ***vmmc_events, long *n_vmmc_events, long *size_vmmc_events){

	double time_new_cd4;
	
	/* This tells us if the cd4 test is due to PopART (is_popart=1) or not (is_popart=0). */
	int is_popart = (indiv->next_cascade_event>=NCASCADEEVENTS_NONPOPART);
	
	//printf("hiv_test_process is_popart= %i\n",is_popart);
	
	int WINDOWNEGATIVE = 0; /* 0 if HIV+ tests negative (because recent infection), 1 if tests positive. 
	 							Assign default value so always defined (otherwise may behave weirdly?) */

	/* Record the time of their most recent test (so we can count % of people who hve tested in last X months): */
	indiv->time_last_hiv_test = t;

	/* Add one to the cumulative total of HIV tests carried out: */
	if (is_popart==0)
		cumulative_outputs->N_total_HIV_tests_nonpopart++; // Test is not from CHiPs (ie this is a clinic-based test).
	else
		cumulative_outputs->N_total_HIV_tests_popart++;    // Home-based CHiPs test - note we distinguish as allows economists to distinguish home/facility-based testing costs

	/* HIV test window for someone who IS infected (which is coded as >UNINFECTED): 
	 * NOTE: we call this first as what we want to know is their HIV test result (not HIV status). */
	if (indiv->HIV_status > UNINFECTED){
		WINDOWNEGATIVE = get_window_result(t-(indiv->t_sc), t, param);
	}

	if(indiv->id==FOLLOW_INDIVIDUAL){
		printf("HIV test result for adult %ld at time %f is %d. True HIV status is %i\n",indiv->id,t,(indiv->HIV_status!=UNINFECTED && WINDOWNEGATIVE!=0),indiv->HIV_status);
		fflush(stdout);
	}

	/************************************************** 
	 * Now look at whether person tests HIV+ or not: 
	 ************************************************** */
	/* If test HIV-, then schedule a new HIV test (and VMMC if applicable): */
	if (indiv->HIV_status==UNINFECTED || WINDOWNEGATIVE==0){
		indiv->ART_status = ARTNEG; /* Note this should be unchanged so could remove this line in future. */
		/* If before PopART, schedule a new HIV test in the future: */
		if (is_popart==NOTPOPART){
			indiv->next_cascade_event = CASCADEEVENT_HIV_TEST_NONPOPART;
			schedule_new_hiv_test(indiv, param, t, cascade_events, n_cascade_events, size_cascade_events);
		}
		else{
			/* For POPART, do not schedule a new event at present - the next cascade event is assumed to be a new annual test at the next round, which is done through the function carry_out_chips_visits_per_timestep() rather than carry_out_cascade_events_per_timestep(). */ 
			indiv->next_cascade_event = NOEVENT;
			indiv->idx_cascade_event[0] = NOEVENT;
			indiv->idx_cascade_event[1] = -1;
		}
		
		if (indiv->gender==MALE)
			if (indiv->circ==UNCIRC)   /* Only if not already circumcised (and not waiting for VMMC): */
				draw_if_VMMC(indiv,param,vmmc_events,n_vmmc_events,size_vmmc_events,t,is_popart);
		/* Rest of the code in this function is if test HIV+, so return. */
		return;
	}

	/* if get to here the individual tested HIV+ */

	if(indiv->id==FOLLOW_INDIVIDUAL){
		printf("Adult %ld tested positive at time %f\n",indiv->id,t);
		fflush(stdout);
	}

	/* PANGEA stuff: get the CD4 at diagnosis for HIV+ person: */
	indiv->PANGEA_cd4atdiagnosis = PANGEA_get_cd4(indiv, t); 
	indiv->PANGEA_t_diag = t;

	
	indiv->ART_status = ARTNAIVE;  /* Status changes as now known positive. */
	
	/* If ART has started then there are 3 possibilities for the next cascade event
	 *  - drops out, waits until eligible, starts ART. */
	if (t>=param->COUNTRY_ART_START){		
		/* Only HIV+ diagnosed individuals remain in the function now. Three possible outcomes: */
		//printf("Need to schedule stuff for %ld\n",indiv->id);
		/* 1. Refuses to enter treatment/care. Next event will be determined by CD4 (e.g. wait until CD4<200), so add in code to update this as CD4 progression occurs. */
		if (joins_preart_care(indiv,param,t,cumulative_outputs)<1){
			/* Dropping out of the cascade is immediate once the HIV test is done. */
			dropout_process(indiv,param,t, cascade_events, n_cascade_events, size_cascade_events, hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression, cumulative_outputs);
		}
		/* 2. Eligible for ART and starts (after a delay) - next event is starting ART. 
		 * Note that delays between HIV testing and starting ART (including getting CD4, picking up results, drugs)
		 *  all built in to this function. 
		 * Eligibility for ART is determined by calendar time and trial arm. */
		else if (is_eligible_for_art(indiv,param,t)>0){
			schedule_start_of_art(indiv,param,t, cascade_events, n_cascade_events, size_cascade_events);
		}
		/* 3. Not eligible for ART, so next event is a new CD4 test. */
		else{

			/* People test t_cd4_retest_min to t_cd4_retest_min+t_cd4_retest_range months after their last CD4 test (or first HIV test). 
			 * Note we separate out the first and subsequent tests as the first CD4 test also includes 
			 * the time for HIV testing etc so is longer.*/
			/* Takes an extra time due to the delay in between getting the HIV test and the CD4 test for the first CD4 test:
			 * compared to between the nth and n+1th CD4 test. 
			 * This is reflected by the parameters::
			 * t_delay_hivtest_to_cd4test_min to t_delay_hivtest_to_cd4test_min+t_delay_hivtest_to_cd4test_range
			 */
			if (is_popart==NOTPOPART){
				/* Time to next CD4 test is the sum of the time between getting the HIV test and having the first CD4 test, 
				 * and the time between consecutive CD4 tests. */
				time_new_cd4 = t + param->t_delay_hivtest_to_cd4test_min[NOTPOPART] + param->t_delay_hivtest_to_cd4test_range[NOTPOPART] * gsl_rng_uniform (rng)  
								+ param->t_cd4_retest_min[NOTPOPART] + param->t_cd4_retest_range[NOTPOPART] * gsl_rng_uniform (rng);
				indiv->next_cascade_event = CASCADEEVENT_CD4_TEST_NONPOPART;
			}
			/* For people in arm B: */
			else{
				/* Allow CD4 retesting to be more frequent. Time to next CD4 test is again the sum of the time between 
				 * getting the HIV test and having the first CD4 test, and the time between consecutive CD4 tests.*/
				time_new_cd4 = t + param->t_delay_hivtest_to_cd4test_min[POPART] + param->t_delay_hivtest_to_cd4test_range[POPART] * gsl_rng_uniform (rng)
				                + param->t_cd4_retest_min[POPART]    + param->t_cd4_retest_range[POPART] * gsl_rng_uniform (rng);
				indiv->next_cascade_event = CASCADEEVENT_CD4_TEST_POPART;
			}
			schedule_generic_cascade_event(indiv, param, time_new_cd4, cascade_events, n_cascade_events, size_cascade_events);
		}
	}
	/* This is for what happens during the period when people were testing for HIV but ART was not widely available:
	 * If test HIV+ before ART becomes available then the next cascade event is:
	 *  either get a CD4 test in the future, or drop out: */
	else{
		/* 1. Drops out Next event will be determined by CD4 (e.g. wait until CD4<200), so add in code to update this as CD4 progression occurs. */
		if (!joins_preart_care(indiv,param,t,cumulative_outputs)){ /// SAME COMMENT AS BEFORE
			dropout_process(indiv,param,t, cascade_events, n_cascade_events, size_cascade_events, hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression, cumulative_outputs);

			/* The next 9 lines of code shouldn't be needed as the function dropout_process() should do everything. */
			/* Dropping out of the cascade is immediate once the HIV test is done. */
			/* 			indiv->ART_status = CASCADEDROPOUT; */
			/* Currently no further cascade events - wait until CD4 drops below 200. */
			/* 			indiv->next_cascade_event= NOEVENT; */
			/* Set to dummy values */
			/*             Note that we do not need to unschedule this indiv from the cascade_event[] list as the event is this one
			 * and we are moving on in time. */
			/* 			indiv->idx_cascade_event[0] = -1; */ 
			/* 			indiv->idx_cascade_event[1] = -1; */
		}
		else{
			/* 2. Has a CD4 test after ART becomes available. */
			/* Has CD4 test param->t_cd4_whenartfirstavail_min to param->t_cd4_whenartfirstavail_min+param->t_cd4_whenartfirstavail_range 
			 * yrs after ART becomes available in the country. */
			double time_cd4;
			if (is_popart==NOTPOPART){
				time_cd4 = param->COUNTRY_ART_START + param->t_cd4_whenartfirstavail_min + param->t_cd4_whenartfirstavail_range*gsl_rng_uniform (rng);
				indiv->next_cascade_event = CASCADEEVENT_CD4_TEST_NONPOPART;
			}
			else{
				/* This should probably not be called as PopART should never happen before CD4 testing is available. */ 
				printf("ERROR: Not sure why here in hiv_test_process() when CD4 testing unavailable but PopART is!!!\n");
				exit(1);
				//double time_cd4 = param->COUNTRY_ART_START + gsl_rng_uniform (rng);
				//indiv->next_cascade_event = CASCADEEVENT_CD4_TEST_POPART;
			}
			
			schedule_generic_cascade_event(indiv, param, time_cd4, cascade_events, n_cascade_events, size_cascade_events);
		}
	}
}

/* Function which gives the delay in starting ART after testing HIV+ (for someone who is immediately eligible). 
 * This represents all the delays in collecting the HIV test, gettign the CD4 test and results, and getting drugs. 
 * Note: at present this function is simple, but keep as it will be (a lot) more complicated. */
void schedule_start_of_art(individual* indiv, parameters *param, double t, individual ***cascade_events, long *n_cascade_events, long *size_cascade_events){
	
	/* This tells us if the cd4 test is due to PopART (is_popart=1) or not (is_popart=0). */
	int is_popart = (indiv->next_cascade_event>=NCASCADEEVENTS_NONPOPART);
		
	//printf("schedule_start_of_art is_popart= %i\n",is_popart);
	
	double time_start_art;
	if (is_popart==NOTPOPART){ /* Assume people start ART 0.25-0.5 yrs after eligibility outside PopART. */
		time_start_art = t + param->t_start_art_min[NOTPOPART] + gsl_rng_uniform (rng)*param->t_start_art_range[NOTPOPART];
		indiv->next_cascade_event = CASCADEEVENT_START_ART_NONPOPART;
		//printf("Add in counter for CD4 here!!!\n");
	}
	else{                      /* Assume people start ART 0.05-0.25 yrs after eligibility in PopART. */
		time_start_art = t + param->t_start_art_min[POPART] + gsl_rng_uniform (rng)*param->t_start_art_range[POPART];
		indiv->next_cascade_event = CASCADEEVENT_START_ART_POPART;
		//printf("Add in counter for CD4 here!!!\n");
	}
	
	if(indiv->id==FOLLOW_INDIVIDUAL){
		printf("Scheduling start of ART for adult %ld at time %f\n",indiv->id,time_start_art);
		fflush(stdout);
	}
	schedule_generic_cascade_event(indiv, param, time_start_art, cascade_events, n_cascade_events, size_cascade_events);
}



/* This is the process of repeated CD4 testing for someone who wasn't  eligible for ART at their last CD4 test.
 * Note that the first CD4 test is carried out implicitly as part of hiv_test_process. 
 * This function updates everything and schedules the next cascade event that will happen. */
void cd4_test_process(individual* indiv, parameters *param, double t, individual ***cascade_events, 
		long *n_cascade_events, long *size_cascade_events, individual ***hiv_pos_progression, 
		long *n_hiv_pos_progression, long *size_hiv_pos_progression, cumulative_outputs_struct *cumulative_outputs){
	
	/* This tells us if the cd4 test is due to PopART (is_popart=1) or not (is_popart=0). */
	int is_popart = (indiv->next_cascade_event>=NCASCADEEVENTS_NONPOPART);
	
	//printf("cd4_test_process is_popart= %i\n",is_popart);

	/* Testing is assumed to happen. People may then drop out after their test, so still count it. */
	if (is_popart==NOTPOPART)
		cumulative_outputs->N_total_CD4_tests_nonpopart++;
	else
		cumulative_outputs->N_total_CD4_tests_popart++;

	
	/* There are 3 possible events (as for when someone gets an HIV+ test): */
	
	/* 1. Refuses to enter treatment/care. Next event will be determined by CD4 (e.g. wait until CD4<200), 
	 * so add in code to update this as CD4 progression occurs. 
	 * Note - leaving is immediate, so don't schedule an event. */

	if(indiv->id==FOLLOW_INDIVIDUAL){
		printf("CD4 test process for adult %ld carried out at time %f\n",indiv->id,t);
		fflush(stdout);
	}

	if (remains_in_cascade(indiv,param,t) <1){ // this tests whether remains_in_cascade(indiv,param,t) ==0 (FALSE)
		/* Currently do nothing - wait until CD4 drops below 200. */
		/* Note that we do not need to unschedule this indiv from the cascade_event[] list as the event is this one
		 * and we are moving on in time. */
		dropout_process(indiv,param,t, cascade_events, n_cascade_events, size_cascade_events, hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression, cumulative_outputs);
		return;
	}
	/* 2. Eligible for ART and starts (after a delay) - next event is starting ART. 
	 * Note that delays between HIV testing and starting ART (including getting CD4, picking up results, drugs) all built in to this function. */
	else if (is_eligible_for_art(indiv,param,t) >0){ // this tests whether is_eligible_for_art(indiv,param,t) ==1 (TRUE)
		indiv->ART_status = ARTNAIVE;
		schedule_start_of_art(indiv,param,t, cascade_events, n_cascade_events, size_cascade_events);
	}
	/* 3. Not eligible for ART, so next event is a new CD4 test. */
	else{
		indiv->ART_status = ARTNAIVE;
		/* Assume people test 6-12 months after their last CD4 test (or first HIV test). 
		 * Note we separate out the first and subsequent tests as the first CD4 test also includes 
		 * the time for HIV testing etc so is longer.*/
		/* Make sure this is similar ot the function for the time to the first repeated CD4 test. */
		double time_new_cd4;
		if (is_popart==NOTPOPART){
			time_new_cd4 = t + param->t_cd4_retest_min[NOTPOPART] + param->t_cd4_retest_range[NOTPOPART] * gsl_rng_uniform (rng);
			indiv->next_cascade_event = CASCADEEVENT_CD4_TEST_NONPOPART;
		}
		else{
			time_new_cd4 = t + param->t_cd4_retest_min[POPART] + param->t_cd4_retest_range[POPART] * gsl_rng_uniform (rng);
			indiv->next_cascade_event = CASCADEEVENT_CD4_TEST_POPART;
		}
		schedule_generic_cascade_event(indiv, param, time_new_cd4, cascade_events, n_cascade_events, size_cascade_events);
		
	}
}


/* This sets up everything when someone becomes virally suppressed on ART and determines their next 
 * cascade event. */
void virally_suppressed_process(individual* indiv, parameters *param, double t, individual ***cascade_events, long *n_cascade_events, long *size_cascade_events,individual ***hiv_pos_progression, long *n_hiv_pos_progression, long *size_hiv_pos_progression){

	if (indiv->next_HIV_event!=NOEVENT){
		remove_from_hiv_pos_progression(indiv,  hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression,t, param);
		indiv->idx_hiv_pos_progression[0] = -1;
		indiv->idx_hiv_pos_progression[1] = -1;
		indiv->ART_status = EARLYART;
	}
		
	/* This tells us if the cd4 test is due to PopART (is_popart=1) or not (is_popart=0). */
	int is_popart = (indiv->next_cascade_event>=NCASCADEEVENTS_NONPOPART);
	
	//printf("virally_suppressed_process is_popart= %i\n",is_popart);
	
	indiv->ART_status = LTART_VS;
	

	if(indiv->id==FOLLOW_INDIVIDUAL){
		printf("Adult %ld has become VS at time %f\n",indiv->id,t);
		fflush(stdout);
	}
	/* Now decide what happens next. 3 possible states: continues being virally suppressed, becomes unsuppressed, or drops out of ART entirely. */
	double x = gsl_rng_uniform (rng);
	if (x<(param->p_stays_virally_suppressed)){
		/* Patient stays virally suppressed, no future cascade events for now: */
		indiv->next_cascade_event= NOEVENT;
		/* Set to dummy values */
		/* Note that we do not need to unschedule this indiv from the cascade_event[] list as the event is this one
		 * and we are moving on in time. */
		indiv->idx_cascade_event[0] = NOEVENT; 
		indiv->idx_cascade_event[1] = -1;

		if(indiv->id==FOLLOW_INDIVIDUAL){
			printf("Adult %ld will remain VS permanently with HIV status %i, ART status %i \n",indiv->id,indiv->HIV_status,indiv->ART_status);
			fflush(stdout);
		}
	}
	else if (x<((param->p_stays_virally_suppressed)+(param->p_stops_virally_suppressed))){
		/* Patient eventually ceases being virally suppressed. Schedule a transition to being virally unsuppressed. */
		
		/* Assume: randomly picked this to be 3-6 years later. */
		double time_end_vs;
		if (is_popart==NOTPOPART){
			time_end_vs = t + param->t_end_vs_becomevu_min[NOTPOPART] + param->t_end_vs_becomevu_range[NOTPOPART] * gsl_rng_uniform (rng);
			indiv->next_cascade_event = CASCADEEVENT_VU_NONPOPART;
		}
		else{
			time_end_vs = t + param->t_end_vs_becomevu_min[POPART] + param->t_end_vs_becomevu_range[POPART] * gsl_rng_uniform (rng);
			indiv->next_cascade_event = CASCADEEVENT_VU_POPART;
		}
		schedule_generic_cascade_event(indiv, param, time_end_vs, cascade_events, n_cascade_events, size_cascade_events);

		/* PANGEA stuff: record end of viral suppression. Note that this is in the future, so 
		 * could be after someone dies, so need to fix in outputs to ensure this never happens. */
		indiv->PANGEA_date_endfirstVLsuppression = time_end_vs;
		if(indiv->id==FOLLOW_INDIVIDUAL){
			printf("Adult %ld is scheduled to become VU at time %f\n",indiv->id,time_end_vs);
			fflush(stdout);
		}
	}
	else{
		/* ASSUMPTION! Randomly picked this to be 3-6 years later. */
		double time_dropout;
		if (is_popart==NOTPOPART){
			time_dropout = t + param->t_end_vs_dropout_min[NOTPOPART] + param->t_end_vs_dropout_range[NOTPOPART] * gsl_rng_uniform (rng);
			indiv->next_cascade_event = CASCADEEVENT_DROPOUT_NONPOPART;
		}
		else{
			time_dropout = t + param->t_end_vs_dropout_min[POPART] + param->t_end_vs_dropout_range[POPART] * gsl_rng_uniform (rng);
			indiv->next_cascade_event = CASCADEEVENT_DROPOUT_POPART;
		}
		if(indiv->id==FOLLOW_INDIVIDUAL){
			printf("Adult %ld is scheduled to drop out at time %f\n",indiv->id,time_dropout);
			fflush(stdout);
		}
		schedule_generic_cascade_event(indiv, param, time_dropout, cascade_events, n_cascade_events, size_cascade_events);		
	}
}

/* This sets up everything when someone becomes virally unsuppressed and determines their next cascade event. */
void virally_unsuppressed_process(individual* indiv, parameters *param, double t, individual ***cascade_events, long *n_cascade_events, long *size_cascade_events, individual ***hiv_pos_progression, long *n_hiv_pos_progression, long *size_hiv_pos_progression, cumulative_outputs_struct *cumulative_outputs){

	/* This tells us if the cd4 test is due to PopART (is_popart=1) or not (is_popart=0). */
	int is_popart = (indiv->next_cascade_event>=NCASCADEEVENTS_NONPOPART);
	
	//printf("virally_unsuppressed_process is_popart= %i\n",is_popart);
	
	
	indiv->ART_status = LTART_VU;
	if(indiv->id==FOLLOW_INDIVIDUAL){
		printf("Adult %ld has become VU at time %f\n",indiv->id,t);
		fflush(stdout);
	}

	/* Need to allow CD4 progression again. */
	next_hiv_event(indiv, hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression, param, t, cumulative_outputs);

	/* Now decide what cascade event happens next. 3 possible states: continues being virally unsuppressed,
	 * becomes suppressed, or drops out of ART entirely. */
	double x = gsl_rng_uniform (rng);
	if (x<(param->p_vu_becomes_virally_suppressed)){
		/* Next event is that patient becomes virally suppressed */
		/* Assume takes 2-3 years*/
		double time_become_vs;
		if (is_popart==NOTPOPART){
			time_become_vs = t + param->t_end_vu_becomevs_min[NOTPOPART]  + param->t_end_vu_becomevs_range[NOTPOPART]*gsl_rng_uniform (rng);
			indiv->next_cascade_event = CASCADEEVENT_VS_NONPOPART;
		}
		else{
			time_become_vs = t + param->t_end_vu_becomevs_min[POPART]     + param->t_end_vu_becomevs_range[POPART]*gsl_rng_uniform (rng);
			indiv->next_cascade_event = CASCADEEVENT_VS_POPART;
		}
		schedule_generic_cascade_event(indiv, param, time_become_vs, cascade_events, n_cascade_events, size_cascade_events);
	}
	else{
		/* Assume: Randomly picked this to be 1-2 years later. */
		double time_dropout;
		if (is_popart==NOTPOPART){
			time_dropout = t + param->t_end_vu_dropout_min[NOTPOPART] + param->t_end_vu_dropout_range[NOTPOPART] * gsl_rng_uniform (rng);
			indiv->next_cascade_event = CASCADEEVENT_DROPOUT_NONPOPART;
		}
		else{
			time_dropout = t + param->t_end_vu_dropout_min[POPART]    + param->t_end_vu_dropout_range[POPART] * gsl_rng_uniform (rng);
			indiv->next_cascade_event = CASCADEEVENT_DROPOUT_POPART;
		}
		schedule_generic_cascade_event(indiv, param, time_dropout, cascade_events, n_cascade_events, size_cascade_events);		
	}
}



/* This sets up everything when someone drops out of care (including restarting their CD4 progression if needed) and determines their next cascade event. */
void dropout_process(individual* indiv, parameters *param, double t, individual ***cascade_events, long *n_cascade_events, long *size_cascade_events, individual ***hiv_pos_progression, long *n_hiv_pos_progression, long *size_hiv_pos_progression, cumulative_outputs_struct *cumulative_outputs){
	
	/* This tells us if the person dropped out during PopART (is_popart=1) or not (is_popart=0). */
	int is_popart = (indiv->next_cascade_event>=NCASCADEEVENTS_NONPOPART);
	
	//printf("dropout_process is_popart= %i\n",is_popart);
	
	if (is_popart==NOTPOPART)
		indiv->ART_status = CASCADEEVENT_DROPOUT_NONPOPART;
	else
		indiv->ART_status = CASCADEEVENT_DROPOUT_POPART;
	
	if(indiv->id==FOLLOW_INDIVIDUAL){
		printf("Adult %ld has dropped out at time %f\n",indiv->id,t);
		fflush(stdout);
	}

	/* Need to allow CD4 progression again if they don't currently have CD4 progression event (ie
	 * if they were on ART and virally suppressed). */
	/* CHANGE 8/1/15. */
	if (indiv->next_HIV_event==NOEVENT)
		next_hiv_event(indiv, hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression, param, t, cumulative_outputs);

	/* No further cascade event happens. The two possibilities at present are that the person 
	 * dies from AIDS=-related illness or starts emergency ART once their CD4 goes below 200.
	 * Both these possibilities are scheduled through the hiv_pos_progression array. */ 

	/* Note that we do not need to unschedule this indiv from the cascade_event[] list as the event is this one
	 * and we are moving on in time. */
	indiv->next_cascade_event=NOEVENT;
	indiv->idx_cascade_event[0] = NOEVENT;
	indiv->idx_cascade_event[1] = -1;
}

/* Go through the list of scheduled cascade events for this timestep (stored in hiv_pos_progression). 
 * For each person to whom some HIV event happens, draw their next HIV-based event (via next_hiv_event) unless they die from AIDS at this timestep.
 * */
void carry_out_cascade_events_per_timestep(double t,individual ***cascade_events, long *n_cascade_events, long *size_cascade_events, 
		parameters *param,age_list_struct *age_list, population_size *n_population,  population_size_one_year_age *n_infected, 
		stratified_population_size *n_population_stratified, individual **susceptible_in_serodiscordant_partnership, 
		long *n_susceptible_in_serodiscordant_partnership, population_partners *pop_available_partners, population_size *n_pop_available_partners,
		individual ***hiv_pos_progression, long *n_hiv_pos_progression, long *size_hiv_pos_progression, cumulative_outputs_struct *cumulative_outputs,
		individual ***vmmc_events, long *n_vmmc_events, long *size_vmmc_events){

	int array_index_for_cascade_event = (int) (round((t - param->COUNTRY_HIV_TEST_START) * N_TIME_STEP_PER_YEAR));
	int n_events = n_cascade_events[array_index_for_cascade_event];
	individual *indiv;
	int n;
	//printf("Calling carry_out_cascade_events at time t=%f\n",t);
	for (n=0; n<n_events; n++){
		indiv = cascade_events[array_index_for_cascade_event][n];
		if (indiv->id==FOLLOW_INDIVIDUAL)
			printf("Events for %ld at time t=%f\n",indiv->id,t);

		if (indiv->cd4==DEAD){
			/* Move on to the next person. Note - we can set up a similar procedure to other lists to remove this person from this list but
			   it is not necessary. As things stand, no hiv event happens to the dead person and no new event is scheduled for them. */
			continue;
		}
		/* Decide if we kill this person: */

		if ((indiv->next_cascade_event==CASCADEEVENT_ARTDEATH_NONPOPART)||(indiv->next_cascade_event==CASCADEEVENT_ARTDEATH_POPART)){
			remove_from_hiv_pos_progression(indiv,  hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression,t, param);
			/* Function removes person from everything except the cascade event list: */
			individual_death_AIDS(age_list, indiv, n_population, n_infected, n_population_stratified, t, param, 
					susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership, pop_available_partners, n_pop_available_partners, cascade_events, n_cascade_events, size_cascade_events);
		}

		else{
			/* At this point "indiv->next_cascade_event" is what happens to them now. We then draw a new "next event" after. */
			if((indiv->next_cascade_event==CASCADEEVENT_HIV_TEST_NONPOPART)||(indiv->next_cascade_event==CASCADEEVENT_HIV_TEST_POPART))
				/* Get their HIV test results and schedule the next cascade event accordingly. Note
				 * that the NOTPOPART indicates that this happens outside PopART. */
				hiv_test_process(indiv, param, t, cascade_events, n_cascade_events, size_cascade_events, hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression, cumulative_outputs, vmmc_events, n_vmmc_events, size_vmmc_events);
			else if ((indiv->next_cascade_event==CASCADEEVENT_CD4_TEST_NONPOPART)||(indiv->next_cascade_event==CASCADEEVENT_CD4_TEST_POPART))
				cd4_test_process(indiv, param, t, cascade_events, n_cascade_events, size_cascade_events, hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression, cumulative_outputs);
			else if ((indiv->next_cascade_event==CASCADEEVENT_START_ART_NONPOPART)||(indiv->next_cascade_event==CASCADEEVENT_START_ART_POPART)){
			        if (indiv->PANGEA_date_firstARTstart<0){
				  indiv->PANGEA_date_firstARTstart = t;
				  indiv->PANGEA_cd4atfirstART = PANGEA_get_cd4(indiv, t);
				}
				start_ART_process(indiv, param, t, cascade_events, n_cascade_events, size_cascade_events, hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression,0);
			}
			else if ((indiv->next_cascade_event==CASCADEEVENT_VS_NONPOPART)||(indiv->next_cascade_event==CASCADEEVENT_VS_POPART)){
				/* Only record if this is the first date of viral suppression. */
				if (indiv->PANGEA_date_startfirstVLsuppression<0)
					indiv->PANGEA_date_startfirstVLsuppression = t;
				virally_suppressed_process(indiv,param,t, cascade_events, n_cascade_events, size_cascade_events, hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression);
			}
			else if ((indiv->next_cascade_event==CASCADEEVENT_VU_NONPOPART)||(indiv->next_cascade_event==CASCADEEVENT_VU_POPART))
				virally_unsuppressed_process(indiv,param,t, cascade_events, n_cascade_events, size_cascade_events, hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression, cumulative_outputs);
			//get_virally_unsuppressed(indiv,param,t, cascade_events, n_cascade_events, size_cascade_events);
			else if ((indiv->next_cascade_event==CASCADEEVENT_DROPOUT_NONPOPART)||(indiv->next_cascade_event==CASCADEEVENT_DROPOUT_POPART))
				dropout_process(indiv,param,t, cascade_events, n_cascade_events, size_cascade_events, hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression, cumulative_outputs);
			else{
				printf("ERROR: Unknown cascade event %i for id=%li. Exiting.\n",indiv->next_cascade_event,indiv->id);
				fflush(stdout);
				exit(1);
			}

		}
	}
	/* We don't need this any more so free the memory: */
	//free(cascade_events[array_index_for_cascade_event]);

}













/////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// Functions for PANGEA:
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

double PANGEA_get_cd4(individual* indiv, double t){
	if ((indiv->PANGEA_t_prev_cd4stage<0) || (indiv->PANGEA_t_next_cd4stage<0) || (indiv->HIV_status==UNINFECTED)){
		printf("ERROR: SHould not be in get_cd4 %li %f %f %i\n",indiv->id,indiv->PANGEA_t_prev_cd4stage,indiv->PANGEA_t_next_cd4stage,indiv->HIV_status==UNINFECTED);
		exit(1);
	}


	double currentcd4,cd4start,cd4end;

	/* Get cd4 range for current stage of CD4: */
	if (indiv->cd4==0){
		cd4start = 800;
		cd4end = 500;
	}
	else if (indiv->cd4==1){
		cd4start = 500;
		cd4end = 350;
	}
	else if (indiv->cd4==2){
		cd4start = 350;
		cd4end = 200;
	}
	else if (indiv->cd4==3){
		cd4start = 200;
		cd4end = 0;
	}
	else{
		printf("ERROR: Unknown CD4!\n");
		exit(1);
	}

	if (indiv->HIV_status==CHRONIC){

		double f = (t - indiv->PANGEA_t_prev_cd4stage) / (indiv->PANGEA_t_next_cd4stage - indiv->PANGEA_t_prev_cd4stage);

		currentcd4 = cd4start - (cd4start-cd4end) * f;
		//printf("cd4start=%f cd4end=%f f=%f currentcd4=%f t=%f %f %f\n",cd4start,cd4end,f,currentcd4,t,indiv->PANGEA_t_prev_cd4stage,indiv->PANGEA_t_next_cd4stage);
	}
	else{
		/* Assume if in acute that current CD4 is the upper end of the given CD4 compartment. */
		currentcd4 = cd4start;
	}

	return currentcd4;
}


