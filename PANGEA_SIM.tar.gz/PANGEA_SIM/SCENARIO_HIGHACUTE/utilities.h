/*  This file is part of the PopART IBM.

    The PopART IBM is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The PopART IBM is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the PopART IBM.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef UTILITIES_H_
#define UTILITIES_H_

#include "structures.h"
#include "constants.h"
#include "utilities.h"
#include <string.h>
void check_age_group_index(age_list_struct *, long, int);
void normalise_four_quantities(double *, double *, double *, double *);
void cumulative_four_quantities(double , double , double , double , double *, double *, double *, double *);
double hill_up(double , double , double , double);
double hill_down(double , double , double , double);
void calcul_population(population_size *, stratified_population_size *);
void calcul_p_risk(int, double [N_RISK][N_RISK], stratified_population_size *, parameters *);
void standardize_relative_number_partnerships_per_risk(int, double *, stratified_population_size *, parameters *);
void calcul_n_new_partners_f_to_m(population_size *, stratified_population_size *, parameters *);
void calcul_n_new_partners_m_to_f(population_size *, stratified_population_size *, parameters *);
void balance_contacts_arithmetic(parameters *param);
int are_in_partnership(individual *, individual *);
int has_free_partnership(individual *);
int is_already_selected(long *, long , long );
void copy_array_long(long *, long *, long );
int is_serodiscordant(partnership *);
void calcul_pop_wider_age_groups(population_size *, population_size_one_year_age *);
void calcul_prevalence(proportion_population_size *, population_size *, population_size *, population_size_one_year_age *);
void print_prevalence(population_size *, population_size *, population_size_one_year_age *);
int compare_longs (const void *, const void *);
int get_setting(parameters *); 
void get_trial_arm(int );
void get_IBM_code_version(char *, int );
void make_output_filename_labels(char *, int , parameters *, int , int , int );
void print_param_struct(parameters *);
/*double** alloc_2D_double(int , int );
void free_2D_double(double **x, int);
double**** alloc_4D_double(int , int , int , int );
void free_4D_double(double ****x, int, int , int );
int** alloc_2D_int(int , int );
void free_2D_int(int **x, int);
int**** alloc_4D_int(int , int , int , int );
void free_4D_int(int ****x, int, int , int );*/


#endif /* UTILITIES_H_ */
