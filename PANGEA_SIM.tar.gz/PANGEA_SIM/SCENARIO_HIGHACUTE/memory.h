/*  This file is part of the PopART IBM.

    The PopART IBM is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The PopART IBM is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the PopART IBM.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef MEMORY_H_
#define MEMORY_H_

#include "structures.h"

void reinitialize_arrays_to_default(long *, long *, long *, long *, long *, long *, long *, long *, long *, long *, long *,long *);


void alloc_all_memory(parameters **, int, individual **, population **, population_size **, stratified_population_size **, age_list_struct **, child_population_struct **,
		partnership **, long **, individual ***, long **,population_partners **, population_size **,
		individual ****, long **, long **, individual ****, long **, long **, individual ****, long **, long **, 
		partnership ****, long **, long **,
		long **, long **, long **, long **, long **, long **, long **,long **,
		population_size_one_year_age **,population_size_one_year_age **, population_size **, population_size **,
		chips_sample_struct **, cumulative_outputs_struct **);


void free_all_memory(parameters *, individual *, population *, population_size *, stratified_population_size *, age_list_struct *, child_population_struct *,
		partnership *, long *,individual **, long *, population_partners *, population_size *,
		individual ***, long *, long *, individual ***, long *, long *, individual ***, long *, long *, 
		partnership ***, long *, long *,
		long *, long *, long *, long *, long *, long *, long *,long *,
		population_size_one_year_age *, population_size_one_year_age *, population_size *, population_size *,
		chips_sample_struct *, cumulative_outputs_struct *);


#endif /** MEMORY_H_ **/
