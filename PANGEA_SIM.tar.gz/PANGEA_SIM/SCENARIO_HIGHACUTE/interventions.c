/*  This file is part of the PopART IBM.

    The PopART IBM is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The PopART IBM is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the PopART IBM.  If not, see <http://www.gnu.org/licenses/>.
 */


/* Interventions will include:
 * Child circumcision
 * Adult circumcision
 * ART
 * ??? Condom use ???
 */

/* Functions:
 * Functions related to PopART/CHiPs:
 * create_popart_chips_samples() - at the start of a PopART year, decide who will be visited by CHiPs and in what order.
 * schedule_chips_visits() - decide how many of these people  will be visited each timestep.
 * carry_out_chips_visits_per_timestep() - goes through the list of people being visited by CHiPs and sets up their next cascade event accordingly (HIV test, CD4 test).
 * 
 * Functions related to circumcision:
 * draw_if_VMMC(): Decides if an individual will get VMMC, and if they do, calls schedule_vmmc() to schedule circumcision for a future timestep in vmmc_events[].  
 * schedule_vmmc(): Adds an event for circumcision to vmmc_events[] to schedule an individual to get circumcised in future.
 * schedule_vmmc_healing(): Adds an event for someone to finish healing after a VMMC op to vmmc_events[].
 * finish_vmmc_healing(): Updates a person's status when they have finished healing after a VMMC op. At this point they have no further VMMC events happening to them.
 * schedule_generic_vmmc_event(): Does the actual adding of a VMMC event to vmmc_event[] - function is called by schedule_vmmc and schedule_vmmc_healing.  
 */

/************************************************************************/
/******************************* Includes  ******************************/
/************************************************************************/

#include "interventions.h"
#include "structures.h"
#include "constants.h"
#include "hiv.h"

/************************************************************************/
/******************************** functions *****************************/
/************************************************************************/





/******************* Functions which schedule people for CHiPs visits each year: *******************/


/* This takes the population of currently alive people (using age_list) and firstly sub-divides them into
 * a 'chips_sampling_frame', e.g. dividing up men and women, as CHiPs tends to visit more women than men.
 * We can also exclude certain people (e.g. <15 years old) as needed.
 * The sampling frame is then drawn from to pick chips_sample->size_n_m men and chips_sample->size_n_f women
 * who will be the people visited in the year.
 * We then shuffle each of these lists, so the shuffled list will be the order in which people are visited.
 * Finally we call schedule_chips_visits() which sets the number of people to be visited in each timestep
 * so that the total number of people visited in a year adds up to the correct total.
 * NOTE: The way we divide up the population means that we may try to visit people who died during the year.
 * However, this should not be a big factor, and I think it may even mimic CHiPs in that people may move/die
 * between enumeration/mapping and CHiPs visit. */
void create_popart_chips_samples(age_list_struct *age_list, chips_sample_struct *chips_sample, parameters *param){
	
	chips_sample_struct *chips_sampling_frame;  /* This is a temporary store of the sampling frame. Only called annually at present so should be OK as a local variable. */
	chips_sampling_frame = malloc(sizeof(chips_sample_struct));
	if(chips_sampling_frame==NULL)
	{
		printf("Unable to allocate chips_sampling_frame in create_popart_chips_samples(). Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	int aa, ai,i;

	/* Set counters to zero (we use these to index within each array). */
	chips_sampling_frame->size_n_m = 0;
	chips_sampling_frame->size_n_f = 0;

	for (aa=0; aa<(MAX_AGE-AGE_ADULT); aa++){

		ai = age_list->youngest_age_group_index + aa; /* ai is the index of the array age_list->number_per_age_group of the age group of people you want to be dead */
		if (ai>(MAX_AGE-AGE_ADULT-1))
			ai = ai - (MAX_AGE-AGE_ADULT);

		for (i=0;i<age_list->number_per_age_group[ai];i++){
			/* At the moment, just split by gender. Can also split by age, exclude younger age groups not visited by CHiPs, 
			 * or add in some undersampling of high risk groups. */
			if (age_list->age_group[ai][i]->gender==MALE){
				chips_sampling_frame->list_m[chips_sampling_frame->size_n_m] = age_list->age_group[ai][i]->id; 
				//printf("Adding mID=%li\n",age_list->age_group[ai][i]->id);
				chips_sampling_frame->size_n_m++;
			}
			else{
				chips_sampling_frame->list_f[chips_sampling_frame->size_n_f] = age_list->age_group[ai][i]->id; 
				chips_sampling_frame->size_n_f++;
				//printf("Adding fID=%li\n",age_list->age_group[ai][i]->id);
			}
		}

	}

	for (i=0;i<age_list->number_oldest_age_group;i++){
		/* Again just split by gender. */
		if (age_list->oldest_age_group[i]->gender==MALE){ 
			chips_sampling_frame->list_m[chips_sampling_frame->size_n_m] = age_list->oldest_age_group[i]->id; 
			chips_sampling_frame->size_n_m++;
		}
		else{
			chips_sampling_frame->list_f[chips_sampling_frame->size_n_f] = age_list->oldest_age_group[i]->id; 
			chips_sampling_frame->size_n_f++;
		}
	}

	/* These decide how many people are going to be visited by CHiPs. Can be implemented as a number rather than a percentage of population. */
	chips_sample->size_n_m = (int)  floor(chips_sampling_frame->size_n_m*param->prop_visited_by_chips[MALE]);
	chips_sample->size_n_f = (int)  floor(chips_sampling_frame->size_n_f*param->prop_visited_by_chips[FEMALE]);

	/* Choose chips_sample->size_n_m from array chips_sampling_frame->m. */
	if (chips_sample->size_n_m>0){
		gsl_ran_choose(rng, chips_sample->list_m, chips_sample->size_n_m, chips_sampling_frame->list_m, chips_sampling_frame->size_n_m, sizeof (long));
		/* Randomise the order (as gsl_ran_choose maintains the order of the original list). */
		gsl_ran_shuffle(rng, chips_sample->list_m, chips_sample->size_n_m, sizeof (long));
	}
		
	
	if (chips_sample->size_n_f>0){
		/* Choose chips_sample.size_n_f from array chips_sampling_frame->f. */
		gsl_ran_choose(rng, chips_sample->list_f, chips_sample->size_n_f, chips_sampling_frame->list_f, chips_sampling_frame->size_n_f, sizeof (long));
		/* Randomise the order (as gsl_ran_choose maintains the order of the original list). */
		gsl_ran_shuffle(rng, chips_sample->list_f, chips_sample->size_n_f, sizeof (long));
	}
	
	schedule_chips_visits(chips_sample);

	free(chips_sampling_frame);
}


/* Given a sample of people who are to be visited each year (currently chips_sample->m and chips_sample->f)
 * schedule their visits in the arrays chips_sample->number_to_see_per_timestep_m/f.
 * These arrays contain the number of people to see at each timestep, and we run through e.g. chips_sample->m
 * until we have seen that many people each timestep. */ 
void schedule_chips_visits(chips_sample_struct *chips_sample){
	/* Initialise these so we start at the beginning of the list. */
	chips_sample->next_person_to_see_m = 0;
	chips_sample->next_person_to_see_f = 0;
	
	long total_left_m = chips_sample->size_n_m;
	long total_left_f = chips_sample->size_n_f;
	
	int i;
	/* This is just a crude way to make sure we see everyone we're supposed to see that month: */ 
	for (i=0; i<N_TIME_STEP_PER_YEAR;i++){
		chips_sample->number_to_see_per_timestep_m[i] = total_left_m/(N_TIME_STEP_PER_YEAR-i);
		total_left_m -= chips_sample->number_to_see_per_timestep_m[i];
		
		chips_sample->number_to_see_per_timestep_f[i] = total_left_f/(N_TIME_STEP_PER_YEAR-i);
		total_left_f -= chips_sample->number_to_see_per_timestep_f[i];
	}		
	
	//For debugging:
	//printf("Check these are zero: %li %li\n",total_left_m,total_left_f);
}



/*************************** Functions which do the CHiPs visits: ************************/


/* Carry out the CHiPS visits for a given timestep at time t. */
void carry_out_chips_visits_per_timestep(chips_sample_struct *chips_sample, double t, 
		individual *individual_population, cumulative_outputs_struct *cumulative_outputs, 
		individual ***cascade_events, long *n_cascade_events, long *size_cascade_events, 
		individual ***hiv_pos_progression, long *n_hiv_pos_progression, long *size_hiv_pos_progression, 
		parameters *param, individual ***vmmc_events, long *n_vmmc_events, long *size_vmmc_events){
	long i;  
	/* This tells us the index of the timestep within chips_sample corresponding to the current time t.
	 * So for example chips_sample->number_to_see_per_timestep_m[t_i] is the number of men to visit at time t.*/
	int t_i = (int) (round((t - floor(t))*N_TIME_STEP_PER_YEAR));

	//printf("At time t_i=%i chips_sample->next_person_to_see_m = %li to see %li\n",t_i,chips_sample->next_person_to_see_m,chips_sample->number_to_see_per_timestep_m[t_i]);
	//fflush(stdout);
	/* Now CHiPs visits each sub-population (currently men/women) in turn: */
	
	/* Go through the list of id's of men to visit, and visit them: */
	for (i=chips_sample->next_person_to_see_m; i<(chips_sample->next_person_to_see_m+chips_sample->number_to_see_per_timestep_m[t_i]); i++){
		chips_visit_person(&(individual_population[chips_sample->list_m[i]]),cumulative_outputs,t,cascade_events,n_cascade_events,size_cascade_events,hiv_pos_progression,n_hiv_pos_progression,size_hiv_pos_progression,param,vmmc_events,n_vmmc_events,size_vmmc_events); /* Send the address (ie pointer) to this person. */
	}
	/* Update this index ready for the next timestep: */
	chips_sample->next_person_to_see_m += chips_sample->number_to_see_per_timestep_m[t_i];
	
	/* Now the same for women: */
	for (i=chips_sample->next_person_to_see_f; i<(chips_sample->next_person_to_see_f+chips_sample->number_to_see_per_timestep_f[t_i]); i++){
		chips_visit_person(&(individual_population[chips_sample->list_f[i]]),cumulative_outputs,t,cascade_events,n_cascade_events,size_cascade_events,hiv_pos_progression,n_hiv_pos_progression,size_hiv_pos_progression,param,vmmc_events,n_vmmc_events,size_vmmc_events); /* Send the address (ie pointer) to this person. */
	}
	/* Update this index ready for the next timestep: */
	chips_sample->next_person_to_see_f += chips_sample->number_to_see_per_timestep_f[t_i];  /* Update this index ready for the next timestep: */
}


void chips_visit_person(individual *indiv, cumulative_outputs_struct *cumulative_outputs, double t, 
		individual ***cascade_events, long *n_cascade_events, long *size_cascade_events, 
		individual ***hiv_pos_progression, long *n_hiv_pos_progression, long *size_hiv_pos_progression, 
		parameters *param, individual ***vmmc_events, long *n_vmmc_events, long *size_vmmc_events){
	/* Because of the way we draw CHiPs visits at the beginning of the year, it is possible some people
	 * die before they are visited. If this is the case then do nothing more. 
	 * They are deleted from age_list so won't be in next year's sample. */
	if (indiv->cd4==DEAD)
		return;
	/* Save what was the old scheduled cascade event type in case needed: */
	int old_cascade_event = indiv->next_cascade_event;
	
	if(indiv->id==FOLLOW_INDIVIDUAL){
		printf("CHiPs visit for adult %ld at time %lf with old_cascade_event %i\n",indiv->id,t,old_cascade_event);
		fflush(stdout);
	}
	

	/* If their previous event was an HIV test, then at this step they are HIV tested by CHiPs. */
	if ((old_cascade_event==CASCADEEVENT_HIV_TEST_NONPOPART)||(old_cascade_event==CASCADEEVENT_HIV_TEST_POPART)){
		/* Unschedule the current event from care cascade. */
		remove_from_cascade_events(indiv, cascade_events,n_cascade_events,size_cascade_events,t, param);
		indiv->next_cascade_event = CASCADEEVENT_HIV_TEST_POPART;
		hiv_test_process(indiv, param, t, cascade_events, n_cascade_events, size_cascade_events, hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression, cumulative_outputs, vmmc_events, n_vmmc_events, size_vmmc_events);
		return;
	}
	else if (old_cascade_event==CASCADEEVENT_CD4_TEST_NONPOPART||old_cascade_event==CASCADEEVENT_CD4_TEST_POPART){
		
		/* Unschedule the current event from care cascade. */
		remove_from_cascade_events(indiv, cascade_events,n_cascade_events,size_cascade_events,t, param);

		
		/* No longer true - assume that if were going to drop out would have done it already: If were waiting to start ART, can still drop out. */
		//if (joins_preart_care(indiv,param,t)<1){
		//	/* Dropping out of the cascade is immediate. */
		//	dropout_process(indiv,param,t, cascade_events, n_cascade_events, size_cascade_events, hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression);
		//}
		/* Eligibility for ART is determined by calendar time and trial arm.
		 * If in arm A and has not dropped out then schedule start of ART. */
		//else if (TRIAL_ARM==ARM_A){
		if (TRIAL_ARM==ARM_A){
			cumulative_outputs->N_total_CD4_tests_popart++;
			indiv->ART_status = ARTNAIVE;
			indiv->next_cascade_event = CASCADEEVENT_START_ART_POPART;
			schedule_start_of_art(indiv,param,t, cascade_events, n_cascade_events, size_cascade_events);
		}
		/* In arm B but eligible for ART: */
		else if (is_eligible_for_art(indiv,param,t)>0){
			indiv->ART_status = ARTNAIVE;
			cumulative_outputs->N_total_CD4_tests_popart++;
			indiv->next_cascade_event = CASCADEEVENT_START_ART_POPART;
			schedule_start_of_art(indiv,param,t, cascade_events, n_cascade_events, size_cascade_events);
		}
		/* In arm B and not yet eligible for ART: */
		else{
			
			/* Time to next CD4 test is again the sum of the time between 
		     * getting the HIV test and having the first CD4 test, and the time between consecutive CD4 
		     * tests. */
			cumulative_outputs->N_total_CD4_tests_popart++;
			indiv->ART_status = ARTNAIVE;
			double time_new_cd4 = t + param->t_delay_hivtest_to_cd4test_min[POPART] + param->t_delay_hivtest_to_cd4test_range[POPART] * gsl_rng_uniform (rng)
			                      + param->t_cd4_retest_min[POPART] + param->t_cd4_retest_range[POPART]*gsl_rng_uniform (rng);
			indiv->next_cascade_event = CASCADEEVENT_CD4_TEST_POPART;
			schedule_generic_cascade_event(indiv, param, time_new_cd4, cascade_events, n_cascade_events, size_cascade_events);
		}
	}	
	
	else if  (old_cascade_event==NOEVENT){
		if(indiv->id==FOLLOW_INDIVIDUAL){
				printf("Adult %ld at time %lf is in old_cascade_event==NOEVENT if statement\n",indiv->id,t);
				fflush(stdout);
			}
		/* Allow back into cascade at some given probability : */
		if (gsl_ran_bernoulli(rng,param->p_popart_to_cascade)==1){
			/* If has never tested positive (ie dropped out between HIV testing and getting their result 
			 * (which could have been negative) at some point - so this person needs to get an HIV test next. */
			if (indiv->ART_status==ARTNEG){
				indiv->next_cascade_event = CASCADEEVENT_HIV_TEST_POPART;
				hiv_test_process(indiv, param, t, cascade_events, n_cascade_events, size_cascade_events, hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression, cumulative_outputs, vmmc_events, n_vmmc_events, size_vmmc_events);
			}
			else{
			/* If already know HIV+ then can go to clinic and get CD4 test etc. */
				cumulative_outputs->N_total_CD4_tests_popart++;
				indiv->next_cascade_event = CASCADEEVENT_START_ART_POPART;
				indiv->ART_status = ARTNAIVE;
				schedule_start_of_art(indiv,param,t, cascade_events, n_cascade_events, size_cascade_events);
			}
		}
	}
	//if ((indiv->next_cascade_event>=NCASCADEEVENTS_NONPOPART)==NOTPOPART){
	//	fprintf(stderr,"Error: non-popart event %i scheduled for %li. Exiting\n",indiv->next_cascade_event,indiv->id);
	//	exit(1);
	//}
		
}













/******************************************************************************************
 * These are VMMC intervention events - VMMC can either be through PopART or national 
 * policy/campaigns.
 ******************************************************************************************/
/* Determines if a man gets VMMC, and if so schedules the process: 
 * ASSUMPTION!!! - time is drawn with no data!!! */
void draw_if_VMMC(individual *indiv, parameters *param, individual ***vmmc_events, long *n_vmmc_events, long *size_vmmc_events, double t, int is_popart){
	
	
	/* For DEBUGGING: */
	if (indiv->gender==FEMALE||(indiv->circ!=UNCIRC)) 
	{
		printf("ERROR: not sure why this person %li gender=%i with circ=%i is in draw_if_VMMC. Exiting\n",indiv->id,indiv->gender,indiv->circ);
		fflush(stdout);
		exit(1);
	}
	
	/* Need to see if there is an HIV retest prior to VMMC. */
	if (t <= (param->COUNTRY_VMMC_START)){
		return;                       /* No VMMC so exit function. */
	}
	else{
		/* Assume that probability of VMMC is higher with PopART (hence the index for p_circ): */
		if (gsl_ran_bernoulli(rng,param->p_circ[is_popart])==1)
			/* Schedule the person to get VMMC some time in the near future.
			 * Note: we allow VMMC to happen quicker during PopART - hence pass is_popart to schedule_vmmc(): */
			schedule_vmmc(indiv, param, vmmc_events, n_vmmc_events, size_vmmc_events, t, is_popart);
	}
}

/* Function is called when a person has just had a -ve HIV test, and decides to get VMMC at some time in the future.
 * The function determines when in the future the person will get VMMC and schedules this in vmmc_events[]. */
void schedule_vmmc(individual *indiv, parameters *param, individual ***vmmc_events, 
		long *n_vmmc_events, long *size_vmmc_events, double t, int is_popart){

	/* For DEBUGGING: */
	if (indiv->gender==FEMALE||(indiv->circ!=UNCIRC)) 
	{
		printf("ERROR: not sure why this person %li gender=%i with circ=%i is in schedule_VMMC. Exiting\n",indiv->id,indiv->gender,indiv->circ);
		fflush(stdout);
		exit(1);
	}

	
	
	//printf("Individual %li had been scheduled for VMMC at time %f, is_popart=%i\n",indiv->id,t,is_popart);
	double time_vmmc = t + param->t_get_vmmc_min[is_popart] + param->t_get_vmmc_range[is_popart]*gsl_rng_uniform (rng);
	
	/* Set status to waiting for VMMC: */
	indiv->circ = UNCIRC_WAITING_VMMC;
	schedule_generic_vmmc_event(indiv,param,vmmc_events,n_vmmc_events,size_vmmc_events,time_vmmc);
	/* Do we need to model people deciding more than once if they get VMMC? */
	return;
}

/* Function is called when the VMMC op is done. It determines time for between VMMC op and healing 
 * and schedules a healing event for the person in vmmc_events[]. It also sets their circ status to "healing". */
void schedule_vmmc_healing(individual *indiv, parameters *param, individual ***vmmc_events, long *n_vmmc_events, long *size_vmmc_events, double t){
	
	/* For DEBUGGING: */
	if (indiv->gender==FEMALE||(indiv->circ!=UNCIRC_WAITING_VMMC)) 
	{
		printf("ERROR: not sure why this person %li gender=%i with circ=%i is in schedule_vmmc_healing. Exiting\n",indiv->id,indiv->gender,indiv->circ);
		fflush(stdout);
		exit(1);
	}
	
	double time_heal = t + param->t_vmmc_healing;
	indiv->circ = VMMC_HEALING;
	schedule_generic_vmmc_event(indiv,param,vmmc_events,n_vmmc_events,size_vmmc_events,time_heal);
	/* Do we need to model people deciding more than once if they get VMMC? */
	return;
}

/* Once someone has reached the end of the VMMC healing period, this function is called.
 * Function sets the individual so they no longer have any VMMC event, and their circ status is "VMMC". */
void finish_vmmc_healing(individual *indiv){
	
	/* For DEBUGGING: */
		if (indiv->gender==FEMALE||(indiv->circ!=VMMC_HEALING)) 
		{
			printf("ERROR: not sure why this person %li gender=%i with circ=%i is in finish_vmmc_healing. Exiting\n",indiv->id,indiv->gender,indiv->circ);
			fflush(stdout);
			exit(1);
		}
		
	indiv->circ = VMMC;
	/* Do not need to remove from vmmc_events[] array as this event is now in the past. */
	indiv->idx_vmmc_event[0] = NOEVENT;
	indiv->idx_vmmc_event[1] = -1;
	return;
}




void schedule_generic_vmmc_event(individual *indiv, parameters *param, individual ***vmmc_events, long *n_vmmc_events, long *size_vmmc_events, double t){
	
	/* Only schedule VMMC events happening before the end of the simulation: */
	if (t<=param->end_time_simul){
		/* vmmc_events is an array of events occurring in the next 12 months only. So the index at time t is calculated as follows:
		 * Suppose VMMC starts in 2008.0. Then for the rest of 2008 we schedule as (int) trunc((t-2008)*N_TIME_STEP_PER_YEAR).
		 * However, after 2008 we want to reuse the same array. So in e.g. 2010.25 we take the decimal part (0.25) and then 
		 * (int) trunc(0.25*N_TIMESTEPS_PER_YEAR) gives the new array index. */  
		double time_since_start_VMMC = t - param->COUNTRY_VMMC_START;
		double decimalpartof_time_since_start_VMMC = time_since_start_VMMC - (int)time_since_start_VMMC;
	
		int array_index_for_vmmc_event = (int) (trunc(decimalpartof_time_since_start_VMMC * N_TIME_STEP_PER_YEAR));
		
		if (indiv->id==FOLLOW_INDIVIDUAL){
			printf("Individual %li is in schedule_generic_vmmc_event\n",indiv->id);
		}
		
		indiv->idx_vmmc_event[0] = array_index_for_vmmc_event;
		indiv->idx_vmmc_event[1] = n_vmmc_events[array_index_for_vmmc_event];
		if(indiv->id==FOLLOW_INDIVIDUAL){
			printf("New generic VMMC event call for adult %ld generated with array indices  %ld %ld\n",indiv->id,indiv->idx_vmmc_event[0],indiv->idx_vmmc_event[1]);
			fflush(stdout);
		}

		/* Check if we've run out of memory: */
		if (n_vmmc_events[array_index_for_vmmc_event]>=(size_vmmc_events[array_index_for_vmmc_event])){
			size_vmmc_events[array_index_for_vmmc_event] += RESIZEMEM;
			printf("Reallocating stuff for VMMC_events now\n");
			fflush(stdout);
			vmmc_events[array_index_for_vmmc_event] = realloc(vmmc_events[array_index_for_vmmc_event],size_vmmc_events[array_index_for_vmmc_event]*sizeof(individual*));
			if (vmmc_events[array_index_for_vmmc_event] == NULL){
				printf("Unable to re-allocate vmmc_events[i]. Execution aborted.");
				fflush(stdout);
				exit(1);
			}
		}	
		vmmc_events[array_index_for_vmmc_event][n_vmmc_events[array_index_for_vmmc_event]] = indiv;
		n_vmmc_events[array_index_for_vmmc_event]++;
	}
	else{
		/* If next event scheduled for after the end of the simulation set this all to be dummy entries. */
		indiv->idx_vmmc_event[0] = NOEVENT;
		indiv->idx_vmmc_event[1] = -1;
		if (indiv->id==FOLLOW_INDIVIDUAL) 
			printf("No VMMC event scheduled for %li as the next event lies after the end of the simulation.\n",indiv->id);
	}
}


void carry_out_VMMC_events_per_timestep(parameters *param, individual ***vmmc_events, 
		long *n_vmmc_events, long *size_vmmc_events, double t){

	double time_since_start_VMMC = t - param->COUNTRY_VMMC_START;
	double decimalpartof_time_since_start_VMMC = time_since_start_VMMC - (int)time_since_start_VMMC;

	int array_index_for_vmmc_event = (int) (trunc(decimalpartof_time_since_start_VMMC * N_TIME_STEP_PER_YEAR));
	
	
	/* For debugging: */
	if (array_index_for_vmmc_event<0 || array_index_for_vmmc_event>=N_TIME_STEP_PER_YEAR){
		printf("ERROR: array index %i for vmmc event out of bounds",array_index_for_vmmc_event);
		fflush(stdout);
		exit(1);
	}
		
	
	int n_events = n_vmmc_events[array_index_for_vmmc_event];
	individual *indiv;
	int n;
	for (n=0; n<n_events; n++){
		indiv = vmmc_events[array_index_for_vmmc_event][n];
		
		/* For debugging: */
		if (indiv->gender==FEMALE){
			printf("ERROR: not sure why there is a woman %li in vmmc_events. Exiting\n",indiv->id);
			fflush(stdout);
			exit(1);
		}
		
		if (indiv->cd4==DEAD){
			/* Move on to the next person. Note - we can set up a similar procedure to other lists to remove this person from this list but
			   it is not necessary. As things stand, no VMMC event happens to the dead person and no new event is scheduled for them. */
			continue;
		}
		/* If uncircumcised but waiting for VMMC then at this timestep they get circumcised. */
		if (indiv->circ==UNCIRC_WAITING_VMMC)
			schedule_vmmc_healing(indiv, param, vmmc_events, n_vmmc_events, size_vmmc_events, t);
		/* If current status is healing, then finish healing. Note that this is the last event in the VMMC process for this individual. */
		else if (indiv->circ==VMMC_HEALING)
			finish_vmmc_healing(indiv);
		else{
			printf("ERROR: not sure why this person %li with circ=%i is in vmmc_events. Exiting\n",indiv->id,indiv->circ);
			fflush(stdout);
			exit(1);
		}
	}
	
	/* At this point we have carried out all the events stored in vmmc_events[array_index_for_vmmc_event].
	 * We reuse the same array next year, so need to set n_vmmc_events[] to be zero.
	 * Note that we do not need to set the elements in vmmc_events[array_index_for_vmmc_event] to be blank
	 * as we overwrite any elements we use, and n_vmmc_events[] prevents us from accessing elements from previous
	 * years which have not been overwritten already. */
	n_vmmc_events[array_index_for_vmmc_event] = 0;
}
	
