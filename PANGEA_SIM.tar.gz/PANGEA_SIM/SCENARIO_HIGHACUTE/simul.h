/*  This file is part of the PopART IBM.

    The PopART IBM is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The PopART IBM is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the PopART IBM.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef SIMUL_H_
#define SIMUL_H_

#include "structures.h"

void carry_out_processes(age_list_struct *, individual *, population_size *, 
		stratified_population_size *, child_population_struct *, int, 
		parameters *, long *, long *, partnership* , long * ,
		population_partners* , population_size *, 
		long *, long *, long *, long *, 
		long *, long *, partnership*** , 
		long*, long*, individual** , 
		long *, population_size_one_year_age *, 
		population_size_one_year_age *, population_size *, 
		population_size *, int, 
		individual ***, long *, long *,
		individual ***, long *, long *,
		individual ***, long *, long *,
		chips_sample_struct *, cumulative_outputs_struct *);

#endif /* SIMUL_H_ */
