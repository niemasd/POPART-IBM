/*  This file is part of the PopART IBM.

    The PopART IBM is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The PopART IBM is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the PopART IBM.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef STRUCTURE_H_
#define STRUCTURE_H_


/************************************************************************/
/******************************* Includes  ******************************/
/************************************************************************/

#include "constants.h"

/************************************************************************/
/*************************Define data structures*************************/
/************************************************************************/

/* Envisage desired number of partnerships for an individual to be a function of age, gender,
 * partnership risk (a variable describing some kind of preference for more or less partnerships
 * independent of age - including if in key population), possibly socio-economic, racial,  etc.
 * In addition, the partner picked will depend on geographical location.
 * We then use these to calculate the probability of each person i being picked */

/* This is a forward declaration of these structures - we need this because the two structures are mutually self-referencing. */
typedef struct individual individual;
typedef struct partnership partnership;

struct partnership{
	/* Structure partnership contains one pointer to a list of 2 persons, and the time after which break-up occurs (in the absence of death): */
	individual* ptr[2];
	double duration_in_time_steps;
};

//////// DO WE WANT TO ADD A NUMBERING TO THE INDIVIDUAL STRUCTURE? ////////

struct individual{
	long id; /* Unique identifier for each individual. */
	int gender; /* 0 = M, 1 = F. */
	double DoB;  /* Date of birth (stored as double). */
	double DoD;  /* Date of death (stored as double). */
	//////// think about comparative efficiency of DoB versus age ////////

	int time_to_delivery; /* -1 = not pregnant ; any positive int = number of time steps to delivery */
	//////// BE CAREFUL THIS IS TIME_STEP DEPENDENT, CHANGE IF TIME_STEP CHANGES ////////

	int HIV_status; /* 0 if uninfected, 1 if infected in acute infection, 2 if infected not in acute infection */
	int ART_status; /* -1 if never tested positive, 0 if positive but not yet on ART (or dropped out), 1 if on ART for <6 months, 2 if on ART for >=6 months and virally suppressed, 3 if on ART for >=6 months and not virally suppressed. */
	double t_sc;    /* time at which person seroconverts. Note this is used to check if the person is currently outside the window period of the given HIV test. */
	int cd4; /* Currently use -2: dead ; -1: uninfected ; 0: CD4>500, 1: CD4 350-500, 2: CD4 200-350, 3: CD4<200. */
	int viral_load; ////////// /* ??? */ ///////////
	int SPVL; /* set point viral load category (0="<4"; 1="4-4.5"; 2="4.5-5"; 3=">5"). Note this could be changed to be a continuous variable.  */
	double DEBUGTOTALTIMEHIVPOS; /* For each person measure how long they are HIV+ for so can see population-level distribution of those who die by end of simulation. */
	double time_last_hiv_test;   /* Allows us to count proportion of population tested in last year, last 3 months, ever. */
	
	int next_HIV_event; /* -1 if not HIV+. Otherwise this stores the next HIV-biology related event to occur to this person (progression, AIDS death, starting ART because CD4<200). */
	long idx_hiv_pos_progression[2]; /* The indices which locate this individual in the hiv_pos_progression array. The first index is a function of the time to their next event (ie puts them in the group of people having an HIV event at some timestep dt) and the second is their location in this group. */
	/* for the above the origin of time is start_time_hiv */
	
	int next_cascade_event; /* Stores the next testing/treatment cascade event to occur to this person (HIV test, CD4 test if in care but not on ART, start ART, stop ART, restart ART). First event is necessarily an HIV test. */ 
	long idx_cascade_event[2]; /* The indices which locate this individual in the cascade_event array. The first index is a function of the time to their next event (ie puts them in the group of people having a cascade event at some timestep dt) and the second is their location in this group. */	
	/* for the above the origin of time is COUNTRY_HIV_TEST_START */
	
	int circ; /* 0 if uncircumcised, 1 if VMMC circumcised (and healed), 2 if VMMC during healing period, 3 if traditional circumcised (assumed at birth/youth). */
	 
	long idx_vmmc_event[2];   /* The indices which locate this individual in the vmmc_event array. The first index is a function of the time to their next event (ie puts them in the group of people having a VMMC event at some timestep dt) and the second is their location in this group. */
	
	// Pangea outputs for Olli                                                                                                     
	double PANGEA_t_prev_cd4stage; /* Time at which an individual last moved CD4 stage. Allows us to linearly estimate CD4 at ART initiation. */
	double PANGEA_t_next_cd4stage; /* Time at which individual will move to the next CD4 stage. Used with PANGEA_t_prev_cd4stage. */  
	double PANGEA_cd4atdiagnosis;  /* Based on t_next_cd4stage, estimate CD4 at diagnosis. */
	double PANGEA_cd4atfirstART;   /* Based on t_next_cd4stage, estimate CD4 at start of ART. */
	double PANGEA_t_diag;
	double PANGEA_date_firstARTstart;
	double PANGEA_date_startfirstVLsuppression;
	double PANGEA_date_endfirstVLsuppression;
	

		
	int n_partners; /* current number of partners of this individual (who are in the community) */
	partnership* partner_pairs[MAX_PARTNERSHIPS_PER_INDIVIDUAL]; /* This is a list of the partnership pairs (with someone in the community) that this individual is in at a certain time. */

	/* The two following are only updated for HIV- individuals (who are in the community) */
	int n_HIVpos_partners; /* current number of HIV+ partners of this individual */
	partnership * partner_pairs_HIVpos[MAX_PARTNERSHIPS_PER_INDIVIDUAL]; /* This is a list of the partnership pairs (with someone in the community) with an HIV+ partner that this individual is in at a certain time. */

	int sex_risk; /* 0, 1, 2 for LOW, MEDIUM, HIGH risk */
	int max_n_partners; /* maximum number of partners this individual can have at a certain time point */
	int n_partners_outside; /* number of partners living outside the community at a certain time point */

	long idx_serodiscordant; // this is -1 if the individual is in no serodiscordant partnership, otherwise it is the index of this individual in the list susceptible_in_serodiscordant_partnership

	long idx_available_partner[MAX_PARTNERSHIPS_PER_INDIVIDUAL]; // this is filled in with -1 if the individual is not available for partnership (i.e. n_partners==max_n_partners), otherwise it is filled in from 0 to max_n+partners-n_partners with the index this individual is at in the list pop_available_partners (within its gender/age/risk group)

	long n_lifetime_partners;             /* Counts the number of partners that someone has had in their lifetime. */
	long n_lifetimeminusoneyear_partners; /* Counts the number of partners that someone has had up to the start of the current year. Thus n_lifetime_partners-n_lifetimeminusoneyear_partners gives the number of partners in the most recent year. */ 
	
	////individual *age_list_ptr; /* This is a pointer to the place in the age list where the pointer to this person is (ie if you go to this address you will find a pointer to this structure). */
	////////////////////////////////////////////////
	/* Do we include the following here:
       - member of household? (particularly pmtct)
       - socioeconomic_status, education/literacy (as a proxy of risk?);
       - clusternumber (includes which arm in, which country).
       - country; // 1 = Zambia, 2 = South Africa. (can ignore if have cluster number)
       - HSV;  1 = HSV2 +ve, 0 = HSV2 -ve.
       - healthcareutilization; // Includes VMMC, PMTCT, non-CHiPs HIV testing;
       - treatment
       - adherence; // Expected level of adherence to ART, loss-to-follow-up, etc.
	   - double spatial_coords[2]; // Think of a simple measure (e.g. distance to travel to healthcare centre, time to travel to health-care centre) which we can get in practice.
	 */
};

/* structure 'parameters': */
typedef struct {

	/********** demographics **********/
	double total_fertility_rate;
	double shape_fertility_param;
	double scale_fertility_param;
	double sex_ratio;     /* Proportion of new sexually active population who are male. */
	
	/********* cluster/country/arm information *********/
	int cluster_number; /* Cluster number - allows us to calculate the arm and the country. */
	
	/********** times **********/
	double start_time_hiv;
	int start_time_simul;
	int end_time_simul;
	double COUNTRY_HIV_TEST_START;
	double COUNTRY_ART_START;
	double COUNTRY_VMMC_START;
	double POPART_START;
	double POPART_END;

	/********** hiv **********/
	double p_child_circ; /* probability of being traditionnally circumcised as a child */

	
	double eff_circ;         /* Effectiveness of circumcision (currently assumed both VMMC and traditional circ).   */
	double rr_circ_unhealed; /* Increased susceptibilty to HIV during VMMC healing period (ie just after operation).   */

	/* Time at which PMTCT programmes started */
	double t0_pmtct;
	double t50_pmtct;

	/* Average log viral load - this is used in hiv transmission and MTCT */
	double average_log_viral_load;

	/* Assuming average annual hazard of transmission with average viral load is 0.2. */
	double average_annual_hazard;

	/* Relative increase in transmission from acute infection, reference group is not acute untreated CD4>500 low SPVL */
	double RRacute_trans;
	double RRCD4[NCD4]; /* RRCD4[0] is 1 */
	double RRSPVL[NSPVL];  /* RRSPVL[0] is 1 */
	/* Relative reduction in infectivity on ART when virally suppressed and not virally suppressed (RR in infectivity =  1-effectiveness. Note in input file we use effectiveness cf HPTN052 96%) */
	double RR_ART_INITIAL;
	double RR_ART_VS;
	double RR_ART_VU;
	/* Relative increase for male to female transmission (relative to female-to-male). */
	double RRmale_to_female_trans;
	/* Range of duration (in years) of acute phase. Assume that we draw uniformly from this range for each person. */
	double min_dur_acute, max_dur_acute; /* measured in years */
	/* Currently these are simple (CD4 progression and AIDS death by VL). 
	 * Will make more complex next... */
	double time_hiv_event[NCD4][NSPVL][2]; /* this contains the ATHENA derived CD4 duration times by SPVL category, [2] is for min and max values from the bootstrap */
	
	/* Note this is the increase in TIME (not rate) spent in each CD4 category when taking ART but virally unsuppressed. */
	double factor_for_slower_progression_ART_VU;
	/* Proportion of individuals having CD4 >500, 350-500, 200-350, <200 after end of acute phase. 
	 * Note - this will depend on SPVL eventually.
	 * We also calculate the cumulative totals (to make things computationally a bit quicker) ie p1, p1+p2, p1+p2+p3. Note that the sum of the 4 must be 1, so we don't store that.
	 */
	double p_initial_cd4_gt500[NSPVL],p_initial_cd4_350_500[NSPVL],p_initial_cd4_200_350[NSPVL],p_initial_cd4_lt200[NSPVL];
	
	double cumulative_p_initial_cd4_gt500[NSPVL], cumulative_p_initial_cd4_350_500[NSPVL], cumulative_p_initial_cd4_200_350[NSPVL], cumulative_p_initial_cd4_lt200[NSPVL]; 

	double p_initial_spvl_cat[NSPVL]; /* proportion of individuals in each SPVL category. Maybe rename p_initial to p? */
	double cumulative_p_initial_spvl_cat[NSPVL];
	
	double cumulative_p_misclassify_cd4[NCD4][NCD4]; /* the order ij is the same as in the ATHENA analysis */
	/********** partnerships **********/

	/* assortativity = proportion of contacts made within the same risk group ; 1-assortativity is the proportion of contacts made at random */
	double assortativity;

	/* parameter theta between 0 and 1 corresponding to the proportion of unbalanced partnership that will be balanced because of male compromise (theta=1 <-> males decide of everything) */
	double prop_compromise_from_males;

	/* Average number of new partners per year  */
	double c_per_gender[N_GENDER][N_AGE]; //// in fact in the values for Zambia read in param.txt, this is the average number of partners per year, think about how to convert this in number of NEW partners

	double relative_number_partnerships_per_risk[N_RISK]; /* relative number of partnerships formed each year by individuals in a certain risk group, relative to an average person of the same sex and age group */

	/* Distribution of sexual partners over age  */
	double p_age_per_gender[N_GENDER][N_AGE][N_AGE];

	/* Maximum number of partners by risk group: */
	int max_n_part_noage[N_RISK];
	
	/* These are parameters used in time_to_partnership_dissolution() to determine when a partnership will break up.
	 * At present I am assuming a Weibull distribution. */
	double breakup_scale_lambda;
	double breakup_shape_k;
	
	/********************************************************************/
	/* the following ones are not read in a file as their values change
	 * as the population size and structure change ; they will be updated
	 * at each time step */
	/********************************************************************/

	/* Distribution of sexual partners over risk  */
	/* They will be updated as a function of current population */
	double p_risk_per_gender[N_GENDER][N_RISK][N_RISK];

	/* Those will contain the relative number of new partners made by a female (resp male) in each risk group compared to an "average" female (resp male) */
	/* They will be updated as a function of current population */
	double xi_per_gender[N_GENDER][N_RISK];

	double unbalanced_nb_f_to_m[N_AGE][N_RISK][N_AGE][N_RISK];
	double unbalanced_nb_m_to_f[N_AGE][N_RISK][N_AGE][N_RISK];

	long balanced_nb_f_to_m[N_AGE][N_RISK][N_AGE][N_RISK];
	
	/* Initial condition parameters: */
	double initial_population_size; /* Size of the 13+ population at the start of the simulation. */
	double initial_prop_age[N_AGE];    /* Proportion of sexually active population by age group at start of simulation. */
	double initial_prop_gender_risk[N_GENDER][N_RISK];  /* Proportion of individuals in each risk group (allow to be different for different genders?) */
	
	double initial_prop_infected_gender_risk[N_GENDER][N_RISK]; /* At time of HIV introduction, proportion of initially infected population in each gender/risk group */
	//// DO WE ALSO WANT A STRATIFICATION BY AGE?

	/* Cascade parameters: */
	
	/* Cascade probabilities: */
	double p_collect_hiv_test_results_cd4_over200; /* given you've had an HIV test, probability that you get your results if you have CD4>200 */
	double p_collect_hiv_test_results_cd4_under200;
	double p_collect_cd4_test_results_cd4_over200;
	double p_collect_cd4_test_results_cd4_under200;

	/* Given you've just started ART several events can happen with the following probabilities: */
	double p_dies_earlyart_cd4[NCD4]; /* you die early */
	double p_leaves_earlyart_cd4_over200; /* drop out (high CD4)*/
	double p_leaves_earlyart_cd4_under200; /* drop out (low CD4)*/
	double p_becomes_vs_after_earlyart; /* become virally suppressed */
			/* or you remain virally unsuppressed */

	/* Given you've become virally suppressed, 3 possible events can happen with following probabilities */
	double p_stays_virally_suppressed; /* remain virally suppressed until you die */
	double p_stops_virally_suppressed; /* at some point you will become unsuppressed */
			/* or you will drop out */

	/* Given you've become virally unsuppressed, 2 possible events can happen with following probabilities */
	double p_vu_becomes_virally_suppressed; /* you become suppressed */
			/* or you drop out */
	
	/* Cascade times: */
	/* For each of these give the min and range, as we look to generate a RV of the form min+Uniform(0,1)*range. 
	 * note that the max value is then t_dropout_min+t_dropout_range. 
	 * The indices [2] reflect NOTPOPART (=0) and POPART(=1) */
	
	/* Time to drop out for someone who initiated ART but will drop out before making it to the VS/VU compartments. */ 
	double t_earlyart_dropout_min[2];
	double t_earlyart_dropout_range[2];  
	/* Time to drop out for someone who initiated ART but who dies before making it to the VS/VU compartments. */
	double t_dies_earlyart_min[2];
	double t_dies_earlyart_range[2];

	double t_end_early_art; /* Time to become virally suppressed when initiating ART. */
	
	double t_cd4_retest_min[2];
	double t_cd4_retest_range[2];
	
	double t_cd4_whenartfirstavail_min;
	double t_cd4_whenartfirstavail_range;
	
	/* Time between getting HIV test and getting CD4 test. */
	double t_delay_hivtest_to_cd4test_min[2];
	double t_delay_hivtest_to_cd4test_range[2];
	
	/* Delay in starting ART once eligible (ie once had CD4 test). */
	double t_start_art_min[2]; 
	double t_start_art_range[2];
	
	/* Time to go from viral suppression to non-suppression (if decided that will become VU). */
	double t_end_vs_becomevu_min[2];
	double t_end_vs_becomevu_range[2];
	
	/* Time to go from viral suppression to dropping out (if decided that will drop out). */
	double t_end_vs_dropout_min[2];
	double t_end_vs_dropout_range[2];
		
	/* Time to go from VU to VS (if decided that will become VS). */
	double t_end_vu_becomevs_min[2];
	double t_end_vu_becomevs_range[2];
	
	/* Time to go from VU to dropping out (if decided that will drop out). */
	double t_end_vu_dropout_min[2];
	double t_end_vu_dropout_range[2];
	
	/* Probability that someone who had dropped out of cascade is found by CHiPS team in a given year. */
	double p_popart_to_cascade;
	
	/* Put as cascade parameters at present - probability of getting VMMC if there is/is not popart 
	 * (assuming VMMC is part of govt policy, ie after COUNTRY_VMMC_START). 
	 * The [2] is again for non-popart/popart.*/
	double p_circ[2]; /* probability of deciding to get circumcised (VMMC) following negative HIV test */
	double t_get_vmmc_min[2];
	double t_get_vmmc_range[2];
	double t_vmmc_healing; /* Time for VMMC wound to heal after op, during which time susceptibility may be higher. */
	
	double prop_visited_by_chips[N_GENDER]; /* Proportion of population (by gender) visited by CHiPS each year. */
	
}parameters;


typedef struct {
	/* Population per gender, age and risk group */
	individual *pop_per_gender_age_risk[N_GENDER][N_AGE][N_RISK][MAX_N_PER_AGE_GROUP]; /* pop_per_gender_age_risk[g][a][r][k] points to the k^th individual of gender g, age g and risk r */
}population;

typedef struct {
	/* Population per gender, age and risk group */
	individual *pop_per_gender_age_risk[N_GENDER][N_AGE][N_RISK][MAX_N_PER_AGE_GROUP*MAX_PARTNERSHIPS_PER_INDIVIDUAL]; /* pop_per_gender_age_risk[g][a][r][k] points to the k^th individual of gender g, age g and risk r */
}population_partners;


typedef struct {
	/* Population size per gender, age and risk group */
	long pop_size_per_gender_age_risk[N_GENDER][N_AGE][N_RISK];
}population_size;


typedef struct {
	/* Population size per gender, age (one year) and risk group */

	long pop_size_per_gender_age1_risk[N_GENDER][MAX_AGE-AGE_ADULT][N_RISK];
	int youngest_age_group_index;
	/* We keep the oldest age group separate (this is anyone age MAX_AGE or over). */
	long pop_size_oldest_age_group_gender_risk[N_GENDER][N_RISK];

}population_size_one_year_age;

typedef struct {
	/* These can be deduced from population_size */

	//long pop_size_per_age_risk[N_AGE][N_RISK];

	long pop_size_per_gender_age[N_GENDER][N_AGE];
	//long pop_size_per_age[N_AGE];

	long pop_size_per_gender_risk[N_GENDER][N_RISK];
	//long pop_size_per_risk[N_RISK];

	double prop_pop_per_gender_risk[N_GENDER][N_RISK];

	long total_pop_size_per_gender[N_GENDER];
	long total_pop_size;

}stratified_population_size;

typedef struct {
	/* Population size per gender, age and risk group */

	double prop_size_per_gender_age_risk[N_GENDER][N_AGE][N_RISK];
	int youngest_age_group_index;

}proportion_population_size;


typedef struct {
	/* Population size per gender, age (one year) and risk group */

	double prop_size_per_gender_age1_risk[N_GENDER][MAX_AGE-AGE_ADULT+1][N_RISK];

}proportion_population_size_one_year_age;


/* An array of pointers, where the ath pointer is an array of pointers to all adults in age group a (where a=0,1,2...MAX_AGE-AGE_ADULT) - note that these are not their actual ages.
   In order to make ageing easy we use a pointer which points to the youngest age group, and move this by 1 (mod n) each year (so that each group "moves" by 1). 
   One final complication is the oldest age group - we can kill them off at the end of each year or put them separate group which ages separately. */
typedef struct {
	/* This is a set of pointers to individuals stored in a matrix by age (for everybody aged AGE_ADULT to MAX_AGE), with pointers to all individuals in a given age group stored as a vector of pointers. */
	individual *age_group[MAX_AGE-AGE_ADULT][MAX_N_PER_AGE_GROUP];
	
	/* Index for the position of the vector of the youngest age group in age_group[][]. */ 
	////1:individual **youngest_age_group; /* because of the way we coded ageing, the youngest age group is not always the 1st, it is the youngest_age_group^th */
	int youngest_age_group_index;
	
	/* We keep the oldest age group separate (this is anyone age MAX_AGE or over) and we kill them at a fast rate. */
	/* This is an array of pointers. */
	individual *oldest_age_group[MAX_N_PER_AGE_GROUP];
	/* This could equally well be a pointer to the last person in the oldest_age_group[] array. */
	int number_oldest_age_group;
	/////// DEBUGGING: Just reduced this from MAX_AGE-AGE_ADULT+1
	long number_per_age_group[MAX_AGE-AGE_ADULT]; //// SHOULD THIS BE A LONG? NOT SURE
	/* Points to the youngest element in number_per_age_group[]. */ 
	////1:int *youngest_number_per_age_group_ptr;
	/* Index for the youngest element in number_per_age_group[]. This is used by update_age_list_death(). */
	////1:int youngest_number_per_age_group_index;
}age_list_struct;


/* This is a list of the number of children to be born at each timestep. n_child is an array containing the number of children for each timestep, and transition_to_adult_index_n_child is a pointer to the place in the list where the current adults are stored (rather than having to move everybody by one slot each timestep, it is easier to have a pointer to the "end" of the list - ie kids about to turn AGE_ADULT. */ 
/* At each time step, if n_t people are born, then n_t is added to the "start" of the array and the pointer is incremented by 1 (so that it points to the "old" kids about to turn 13 at that timestep). */
typedef struct {
/* Number of children (ie <AGE_ADULT) - this is an array where each element is the number of children who were born in a given timestep (so that in each timestep of the simulation we add more new people) */
	int n_child[AGE_ADULT*N_TIME_STEP_PER_YEAR]; 
	int *transition_to_adult_index_n_child;	
}child_population_struct;


typedef struct{
	/* We divide the population into subgroups for the CHiPS teams to sample from each year. 
	 * The same structure is then used to store the people who will get visited by CHiPs teams that year. */ 
	//long n_young_m[MAX_POP_SIZE];
	//long n_young_f[MAX_POP_SIZE];
	//long n_old_m[MAX_POP_SIZE];
	//long n_old_f[MAX_POP_SIZE];
	//long m[100000]; /* contains the ID of men who may be visited by CHiPs */
	//long f[100000]; /* contains the ID of women who may be visited by CHiPs */
	long list_m[MAX_POP_SIZE]; /* contains the ID of men who may be visited by CHiPs */
	long list_f[MAX_POP_SIZE]; /* contains the ID of women who may be visited by CHiPs */
	long size_n_m;
	long size_n_f;
	
	/* This will be the number of people (m/f) we see each timestep in a given year
	 * I use this form so it is easy to use the CHiPs reports to allow us to put in variation in
	 * the number of people seen each week. 
	 * Note that these arrays are only used in the variable which is the list of people to be seen.
	 * It is not used in the sampling frame variable. */
	long number_to_see_per_timestep_m[N_TIME_STEP_PER_YEAR];
	long number_to_see_per_timestep_f[N_TIME_STEP_PER_YEAR];
	
	long next_person_to_see_m;
	long next_person_to_see_f;
}chips_sample_struct;


typedef struct{
	long N_total_CD4_tests_nonpopart; /* Cumulative number of CD4 and HIV tests ever done (excluding those from PopART). */
	long N_total_HIV_tests_nonpopart;
	long N_total_CD4_tests_popart; /* Cumulative number of CD4 and HIV tests done by PopART. */
	long N_total_HIV_tests_popart;
	/* Number of people who ever started ART (including those dead) for non-popart & popart: */
	long N_total_ever_started_ART_nonpopart;
	long N_total_ever_started_ART_popart;
}cumulative_outputs_struct;

#endif
