/*  This file is part of the PopART IBM.

    The PopART IBM is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The PopART IBM is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the PopART IBM.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 *
 */


/************************************************************************/
/******************************* Includes  ******************************/
/************************************************************************/

#include "simul.h"
#include "demographics.h"
#include "partnership.h"
#include "utilities.h"
#include "hiv.h"
#include "init.h"
#include "interventions.h"

/************************************************************************/
/******************************** functions *****************************/
/************************************************************************/


/* This runs all processes carried out at the weekly level, i.e. births (in future including MTCT), 
 * deaths by natural causes, partnership formation/dissolution, infection, HIV progression.
 * Note: ageing is run separately as it is done on an annual basis. */
void carry_out_processes(age_list_struct *age_list, individual *individual_population, population_size *n_population, 
		stratified_population_size *n_population_stratified, child_population_struct *child_population, int t0, 
		parameters *param, long *new_deaths, long *death_dummylist, partnership* partner_pairs, long *n_partnerships, 
		population_partners* pop_available_partners, population_size *n_pop_available_partners, 
		long *new_partners_f_sorted, long *shuffled_idx, long *new_partners_f_non_matchable, long *new_partners_m, 
		long *new_partners_m_sorted, long *partner_dummylist, partnership*** planned_breakups, 
		long* n_planned_breakups, long* size_planned_breakups, individual** susceptible_in_serodiscordant_partnership, 
		long *n_susceptible_in_serodiscordant_partnership, population_size_one_year_age *n_infected, 
		population_size_one_year_age *n_newly_infected, population_size *n_infected_wide_age_group, 
		population_size *n_newly_infected_wide_age_group, int country_setting,
		individual ***hiv_pos_progression, long *n_hiv_pos_progression, long *size_hiv_pos_progression, 
		individual ***cascade_events, long *n_cascade_events, long *size_cascade_events,
		individual ***vmmc_events, long *n_vmmc_events, long *size_vmmc_events,
		chips_sample_struct *chips_sample, cumulative_outputs_struct *cumulative_outputs){
	
	int t_step;
	long k;
	double t;
	int aa;
	//static int has_HIV_started = 0;
	//static int has_testing_started = 0;

	/* n_newly_infected counts incidence per timestep. This function resets the number of newly infected to zero at the start of the year. */
	set_population_count_one_year_zero(n_newly_infected); 
	
	/* Every year from start of popart to (end-1) run the CHiPs sampling process: */
	if ((t0>=param->POPART_START) && (t0<param->POPART_END) && (TRIAL_ARM==ARM_A||TRIAL_ARM==ARM_B)){
		//int i;
		printf("PopART at time t=%i\n",t0);
		fflush(stdout);
		
		create_popart_chips_samples(age_list, chips_sample, param);
		
		//for (i=0;i<chips_sample->size_n_f;i++)
		//	printf("CHiPS sample %li id = %ld gender = %i DoB = %lf cd4=%i\n",chips_sample->f[i],individual_population[chips_sample->f[i]].id,individual_population[chips_sample->f[i]].gender,individual_population[chips_sample->f[i]].DoB,individual_population[chips_sample->f[i]].cd4);
		//for (i=0;i<chips_sample->size_n_m;i++)
		//	printf("CHiPS sample %li id = %ld gender = %i DoB = %lf cd4=%i\n",chips_sample->m[i],individual_population[chips_sample->m[i]].id,individual_population[chips_sample->m[i]].gender,individual_population[chips_sample->m[i]].DoB,individual_population[chips_sample->m[i]].cd4);
		
	}

	for (t_step=0; t_step<N_TIME_STEP_PER_YEAR; t_step++){

		t = t0 + t_step * TIME_STEP;   /* Current time in yrs. */

		
		/* This has to be called before deaths_natural_causes() or individual_AIDS_death() in the given timestep. */
		if(t>=param->COUNTRY_HIV_TEST_START && t<(param->COUNTRY_HIV_TEST_START+TIME_STEP))
		{
		  //printf("Setting up initial HIV cascade events\n");
			//has_testing_started = 1;
			/* This function will go through all people currently alive and schedule HIV tests for them at some point in the future. */
			draw_initial_hiv_tests(param, age_list, t, cascade_events, n_cascade_events, size_cascade_events);
		}

		
		// For debugging:
		//print_population(n_population);
		//printf("t0 = %d ; t_step = %d\n",t0,t_step);
		/*if(t0==1963 && t_step==14)
		{
			printf("Potential problem here\n");
		}*/
		//if(n_pop_available_partners->pop_size_per_gender_age_risk[1][1][0]>596)
		//{
		//	printf("pop_available_partners->pop_per_gender_age_risk[1][1][0][596]->id = %ld\n",pop_available_partners->pop_per_gender_age_risk[1][1][0][596]->id);
		//}
		
		//printf("Individual %ld's DoB is: %f CD4= %i\n",individual_population[396].id,individual_population[396].DoB,individual_population[396].cd4);

		
		//fflush(stdout);
		if (PRINT_DEBUG_DEMOGRAPHICS){
			printf("Number in age 13 age group is %li\n",age_list->number_per_age_group[age_list->youngest_age_group_index]);
			fflush(stdout);
		}

		
		if (PRINT_DEBUG_DEMOGRAPHICS)
			printf("******************Time = %f %i\n",t,age_list->number_oldest_age_group);

		/************************************************************************/
		/* Birth (including MTCT) and deaths (natural causes) */
		/************************************************************************/
		// MTCT TO BE ADDED + ACCOUNT FOR BIRTH AND DEATHS IN LIST OF AVAILABLE PARTNERS + PARTNERSHIPS
		// When someone becomes 13 they enter
		//			the age list
		// 			the list of available partners
		//			the list of HIV+ people if HIV+ (list not existing yet)
		// When someone dies, they are removed from
		//			the age list
		//			the list of available partners
		//			the list of HIV+ people if they are HIV+
		//			the list of serodiscordant partnerships if applicable
		//			the list of pregnant women if applicable
		//			their partnerships are dissolved

		//for (i=0; i<age_list->number_oldest_age_group; i++)
		//	printf("Age 80 people: %i %i %f\n",(age_list->oldest_age_group[i])->id,age_list->oldest_age_group[i]->gender,age_list->oldest_age_group[i]->DoB);
		/* drawing people who are going to die in this time step and removing them from where needed (but leaves them in individual_population) */

		/* This function draws people to die from each year-age group. For each individual chosen to die it calls functions 
		 *  to update all lists which featured this person (age list, partnerships, serodiscordant people, planned breakups, available partners). 
		 * Finally for each dead person we set CD4=-2 (note -2 is defined as DEAD in constants.h) so we know they're dead. */

		deaths_natural_causes(age_list, individual_population, n_population, n_infected, n_population_stratified, t, param, new_deaths, death_dummylist, susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership, pop_available_partners, n_pop_available_partners, hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression, cascade_events, n_cascade_events, size_cascade_events, vmmc_events, n_vmmc_events, size_vmmc_events);
		
		if (PRINT_DEBUG_DEMOGRAPHICS)
			printf("Making new adults at time t=%f\n",t);
		/* Making new adults (from the child_population) and adding them to the individual_population, n_population, and other lists (available partners, etc.). */
		make_new_adults(child_population, individual_population, n_population, n_population_stratified, age_list, t, param, pop_available_partners, n_pop_available_partners, n_infected, cascade_events, n_cascade_events, size_cascade_events);

		/* Add children who have just been born to the child population - the number of kids is randomly drawn based on 
		 * fertility rate, current adult population size, etc. */
		add_new_kids(child_population, n_population, n_population_stratified, param, t, country_setting);


		/// Validation of age groups:
		//validate_ages_based_on_age_group(age_list, 13, t);

		//for (aa = 0; aa < (MAX_AGE-AGE_ADULT); aa++)
		//	printf("!!!Number aged per year %i = %i\n",aa + AGE_ADULT,age_list->number_per_age_group[aa]);
		//printf("!!!Number aged 80+ = %i\n",age_list->number_oldest_age_group);
		//print_demographics(individual_population, n_population, t);
		//print_population(n_population);
		//print_number_by_age(age_list);

		/************************************************************************/
		/* Planned pregnancies */
		/************************************************************************/
		// TO BE ADDED
		// ONCE TIME TO DISSOLUTION IS DECIDED, DEPENDING ON AGES AND RISKS OF 2 PARTNERS, DRAW NUMBER OF KIDS AND TIMES OF CONCEPTION
		// FORGET THIS FOR NOW, KEEP FOR VERSION 1.1

		/************************************************************************/
		/* Partnership dissolution (not forced by death) */
		/************************************************************************/

		/* Loop through all planned breakups in this timestep: */
		for(k=0 ; k<n_planned_breakups[N_TIME_STEP_PER_YEAR*(t0 - param->start_time_simul) + t_step] ; k++)
		{
			/* Breaking up an individual partnership: */
			/* DONE automatically in breakup: putting each partner is put back into the list of available partners and 
			 * partnership is removed from list of serodiscordant partnerships (if applicable). */
			breakup(t, planned_breakups[N_TIME_STEP_PER_YEAR*(t0 - param->start_time_simul) + t_step][k], pop_available_partners, n_pop_available_partners, susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership);

		}

		/************************************************************************/
		/* Partnership formation */
		/************************************************************************/
		
		/* Updates the elements of n_population based on the population size of the smallest entity (gender/age/risk). 
		 * This is needed before drawing partnerships because we need an up-to-date prop_pop_per_risk_per_gender. */
		calcul_population(n_population, n_population_stratified); 
		
		/* Now draw new partnerships (ie allocate people with available partnerships to these partnerships) and
		 * update all applicable lists (available partners, partnerships, serodiscordant couples (if applicable) and schedule a future breakup. */
		draw_new_partnerships(t, individual_population,pop_available_partners, n_pop_available_partners, n_population, n_population_stratified, partner_pairs, n_partnerships, param, shuffled_idx, new_partners_f_sorted, new_partners_f_non_matchable, new_partners_m, new_partners_m_sorted, partner_dummylist, planned_breakups, n_planned_breakups, size_planned_breakups, susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership);

		
		/************************************************************************/
		/* HIV introduction (at time param->start_time_hiv) */
		/************************************************************************/

		
		/* This loop seeds HIV once in the simulation at t=param->start_time_hiv. */
		//// At the moment initial cases are drawn uniformly accross ages. This needs to be changed.
		//if(has_HIV_started==0 && t>=param->start_time_hiv)
		if((t>=param->start_time_hiv) && (t<(param->start_time_hiv+TIME_STEP)))
		{
			//has_HIV_started = 1;
			for (aa=0; aa<MAX_AGE-AGE_ADULT; aa++){ /* for all but the age group 80+ (which is in a separate part of the age_list struct). */
				for (k=0; k<age_list->number_per_age_group[aa] ; k++){ /* for each individual in that annual age group */
					/* Draw whether each person is initially HIV infected or not according to a Bernoulli 
					 * trial with probability depending on gender and risk group.
					 * Note - we could draw individuals from appropriate groups but we don't have the exact grouping we would want
					 * at present. It is not clear that it would be quicker to generate these lists and draw from them than just to do
					 * Bernoulli trials (and this method is more easy to change what probability of prevalence depends on). */
					draw_initial_infection(age_list->age_group[aa][k], param, susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership, n_infected, n_newly_infected, age_list, hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression);
					//DEBUGA:
					//draw_initial_infection(age_list->age_group[aa][k], param, susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership, n_infected, n_newly_infected);
				}
			}

			/* For the last age group: 
			 * Note - we may decide to switch this off. */
			for (k=0; k<age_list->number_oldest_age_group ; k++){ /* for each individual in that age group */
				/* draw whether initially HIV infected or not according to a Bernoulli trial with probability depending on gender and risk group */
				draw_initial_infection(age_list->oldest_age_group[k], param, susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership, n_infected, n_newly_infected, age_list, hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression);
			}

			//printf("Prevalence at time of HIV introduction\n");
			//print_prevalence(n_population, n_infected_wide_age_group, n_infected);
			//printf("-------------------------------------\n");
			//printf("-------------------------------------DEBUGGING\n");
			//print_prevalence_incidence(individual_population, n_infected, n_newly_infected, age_list,0);
		}
		
		/************************************************************************/
		/* HIV transmission within partnerships */
		/************************************************************************/
		// TO BE COMPLETED
		
		/* Loop over all susceptibles who are in at least one serodiscordant couple, where transmission can happen: */
		for(k=0 ; k<n_susceptible_in_serodiscordant_partnership[0] ; k++) 
		{

			/* FOR DEBUGGING */
			//printf("Drawing HIV acquisition for %ld in %ld candidates\n", k+1, n_susceptible_in_serodiscordant_partnership[0]);
			//fflush(stdout);

			/* Draw transmission of susceptible in serodiscordant partnership according to infectivity of positive partner(s): */
			//// IS IT A PROBLEM THAT WE"RE CALLING susceptible_in_serodiscordant_partnership TWICE? DO WE NEED TO MAKE A LOCAL COPY OF THE SUSCEPTIBLE?
			//// Adding this IF check because at the moment we can select individuals who are dead: THIS NEEDS TO BE REMOVED IN THE FUTURE
			if(susceptible_in_serodiscordant_partnership[k]->cd4 > DEAD){
				hiv_acquisition(t, susceptible_in_serodiscordant_partnership[k], param, susceptible_in_serodiscordant_partnership, 
						n_susceptible_in_serodiscordant_partnership, n_infected, n_newly_infected, age_list, hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression);
			}
			else{
				printf("Here problem: trying to make a dead person acquire HIV. ID = %li\n",susceptible_in_serodiscordant_partnership[k]->id);
				fflush(stdout);
			}
			//The list of serodiscordant partnerships is updated accordingly automatically within hiv_acquisition.
		}

		/************************************************************************/
		/* Progressing (HIV) or dying from HIV */
		/************************************************************************/
		//if(has_HIV_started==1)
		if(t>=param->start_time_hiv)
		{
			carry_out_HIV_events_per_timestep(t, hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression, 
					param, age_list, n_population,  n_infected, n_population_stratified, susceptible_in_serodiscordant_partnership, 
					n_susceptible_in_serodiscordant_partnership, pop_available_partners, n_pop_available_partners, cascade_events, n_cascade_events, size_cascade_events, cumulative_outputs);
			/*
			printf("Incident cases time step starting at %g:\n", t);
			print_population(n_newly_infected);
			printf("-------------------------------------\n");
			*/
		}
		
		if (t>=param->COUNTRY_HIV_TEST_START){
			carry_out_cascade_events_per_timestep(t, cascade_events, n_cascade_events, size_cascade_events, 
				param, age_list, n_population,  n_infected, n_population_stratified, susceptible_in_serodiscordant_partnership, 
				n_susceptible_in_serodiscordant_partnership, pop_available_partners, n_pop_available_partners,
				hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression, cumulative_outputs,
				vmmc_events, n_vmmc_events, size_vmmc_events);
		}
		
		/* Carry out popart if needed */
		if ((t>=param->POPART_START) && (t<param->POPART_END) && (TRIAL_ARM==ARM_A||TRIAL_ARM==ARM_B)){
			carry_out_chips_visits_per_timestep(chips_sample,t,individual_population,cumulative_outputs, 
					cascade_events,n_cascade_events,size_cascade_events, 
					hiv_pos_progression,n_hiv_pos_progression,size_hiv_pos_progression,param,
					vmmc_events, n_vmmc_events, size_vmmc_events);
		}
		
		/* Carry out VMMC if needed */
		if (t>=param->COUNTRY_VMMC_START)
			carry_out_VMMC_events_per_timestep(param,vmmc_events,n_vmmc_events,size_vmmc_events,t);
	}
}
