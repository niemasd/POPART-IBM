/*  This file is part of the PopART IBM.

    The PopART IBM is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The PopART IBM is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the PopART IBM.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef PARTNERSHIP_H_
#define PARTNERSHIP_H_

#include "structures.h"

void new_partnership(partnership *, individual* , individual*, int, 
		partnership***, long *, long *, 
		individual** , long *, 
		parameters *);

int time_to_partnership_dissolution(parameters *, int r_m, int r_f);

void breakup(double, partnership*, population_partners*, population_size *, individual**, long *);

void update_list_available_partners_breakup(double , partnership* , population_partners* , population_size *);

void add_susceptible_to_list_serodiscordant_partnership(individual* , individual** , long *);

void remove_susceptible_from_list_serodiscordant_partnership(individual* , individual** , long *);

void update_list_susceptibles_in_serodiscordant_partnerships_breakup(partnership* , individual** , long *);

void draw_nb_new_partnerships(population_size *, stratified_population_size *, parameters *);

void draw_n_new_partnerships(int, long, int , int , int , int , int *, individual *, 
		population_partners* , population_size *, 
		population_size *, stratified_population_size *, 
		partnership* , long *, 
		parameters *, long *, long*, 
		long* , long* , long *,  long *, 
		partnership***, long *, long *, 
		individual** , long *);

void draw_new_partnerships(int, individual *, population_partners*, population_size *, population_size *, stratified_population_size *, partnership* , long *, parameters *, long *, long *, long *, long *, long *, long*, partnership***, long *, long *, individual**, long *);


#endif /* PARTNERSHIP_H_ */
