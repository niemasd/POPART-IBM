/*  This file is part of the PopART IBM.

    The PopART IBM is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The PopART IBM is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the PopART IBM.  If not, see <http://www.gnu.org/licenses/>.
 */

/************************************************************************/
/******************************* Includes  ******************************/
/************************************************************************/

#include "constants.h"
#include "structures.h"
#include "input.h"
#include "init.h"
#include "utilities.h"
#include "partnership.h"
#include "checks.h"
#include "demographics.h"
#include "output.h"
#include "memory.h"
#include "simul.h"


/************************************************************************/
/******************************* main function **************************/
/************************************************************************/

int main(int argc,char *argv[]){
	/***** arguments (*at present this is the directory containing the parameters we use*):
	 * argc: the number of arguments fed in the command line (integer)
	 * argv: a pointer to an array containing the arguments fed in the command line
	 */

	/*********************************************************/
	/*** Declaration of dummy variables                    ***/
	/*********************************************************/

	int year;
	int i;

	/*********************************************************/
	/*** SETTING UP DIRECTORY                              ***/
	/*********************************************************/

	/* checking number of arguments */
	if(argc<2)
	{
		printf("ERROR. Execution syntax: ./popart-simul.exe run_directory\nExiting.\n");
		fflush(stdout);
		exit(1);
	}

	/* reading arguments */
	char *file_directory = argv[1];



	//printf("-------------------------------------\n");

	/*********************************************************/
	/*** Declaration of variables                          ***/
	/*********************************************************/

	/* These are indices for the run number (ie we use parameter set 'i_run') currently used, the total number of 
	 * parameter sets used (n_runs), and the first parameter set we use (i_startrun). i_startrun allows us to
	 * pick a single run so if we find a good fit in the ith parameter set we set i_startrun=i.
	 * Note that we offset (so i_run runs from 0..n_runs-1) so i_run is the index in allrunparameters[]
	 * referring to the current parameter set. */ 
	int i_run,n_runs,i_startrun;
	
	/* parameters */
	/* We allow the input files to have multiple parameter sets. The array allrunparameters will contain
	 * all these parameter sets. Every time we want a new parameter set we take out the relevant array element
	 * from allrunparameters and copy it into param (actually we set the pointer for param to point 
	 * at allrunparameters ie param = allrunparameters+i_run. */
	parameters *param = NULL; /* This will contain parameter values for a single run */
	parameters *allrunparameters = NULL; 
	
	/* population */
	individual *individual_population = NULL; /* This will contain all individuals in a cluster age AGE_ADULT or above. */
	population *pop = NULL; /* This will contain pointers to all individuals in a cluster age AGE_ADULT or above, classified by gender, age and risk group */
	population_size *n_population = NULL; /* This will contain the number of individuals in each group. */
	stratified_population_size *n_population_stratified = NULL; /* This will contain the number of individuals overall. */
	age_list_struct *age_list = NULL; /* This will contain pointers to all individuals in a cluster age AGE_ADULT or above, classified by one year age groups. */
	child_population_struct *child_population = NULL; /* This will contain  the number of children at each age(in weeks)-timestep, split into HIV- and HIV+. */

	/* HIV+ population */
	population_size_one_year_age *n_infected = NULL; /* This will contain the number of HIV+ individuals in each group. */
	population_size *n_infected_wide_age_group = NULL; /* This will contain the number of HIV+ individuals in each group. */
	population_size_one_year_age *n_newly_infected = NULL; /* This will contain the number of individuals in each group infected with HIV within the last time step. */
	population_size *n_newly_infected_wide_age_group = NULL; /* This will contain the number of HIV+ individuals in each group. */

	/* scheduled HIV progression events: CD4 progression, AIDS death */
	individual ***hiv_pos_progression = NULL; /* This will store arrays of individuals who are HIV positive, sorted by time step of the next HIV progression event scheduled to happen to them */
	long *n_hiv_pos_progression = NULL;      /* This will store the number of individuals in the array above */
	long *size_hiv_pos_progression = NULL;   /* This stores the size of each sub-array in hiv_pos_progression (so we know if we have to resize them). */

	individual ***cascade_events = NULL; /* This will store arrays of all individuals, sorted by time step of the next cascade event scheduled to happen to them (HIV test, start ART,  */
	long *n_cascade_events = NULL;      /* This will store the number of individuals in the array above */
	long *size_cascade_events = NULL;   /* This stores the size of each sub-array in hiv_pos_progression (so we know if we have to resize them). */

	individual ***vmmc_events = NULL; /* This will store arrays of men getting VMMC, sorted by time step of the next VMMC event scheduled to happen to them (circumcision, and possibly - but not currently coded - end of healing period).  */
	long *n_vmmc_events = NULL;      /* This will store the number of individuals in the array above */
	long *size_vmmc_events = NULL;   /* This stores the size of each sub-array in hiv_pos_progression (so we know if we have to resize them). */

	chips_sample_struct *chips_sample = NULL; /* This will store the list of individuals who will get visited by CHiPs teams that year (divided by gender etc). */ 

	/* HIV- population (only those in serodiscordant partnerships) */
	individual **susceptible_in_serodiscordant_partnership = NULL;   /* This will contain pointer to all the HIV- individuals who are in at least one serodiscordant partnership */
	long *n_susceptible_in_serodiscordant_partnership = NULL; /* This will contain the number of HIV- individuals who are in at least one serodiscordant partnership */

	/* partnerships and lists of available partnerships */
	partnership *partner_pairs = NULL;  /* This will contain all the partnerships ever formed */
	long *n_partnerships = NULL; /* This will contain the total number of partnerships ever formed */
	population_partners *pop_available_partners = NULL; /* This will contain pointers to a all people who are currently available to have more partnerships (stratified by gender, age and risk) ; individuals can appear multiple times if they have several free partnerships */
	population_size *n_pop_available_partners = NULL; /* This will contain  the number of free partnerships in each group and overall. */ //// HERE WE DON'T NEED THE OVERALL NUMBRES ONLY THE PER GROUP SO MAYBE USE A SIMPLIFIED STRUCTURE

	/* scheduled partnership breakups */
	partnership ***planned_breakups = NULL;  /* This will contain the partnerships scheduled to break up at a certain time */
	long *n_planned_breakups = NULL; /* This will store the number of individuals in the array above */
	long *size_planned_breakups = NULL; /* This will store the size of each subarray of planned_breakups for memory reallocation */
	//// HERE SHALL WE HAVE 2 LISTS, ONE FOR SHORT TERMS PARTNERSHIPS AND ONE FOR LONGER TERM ONES?

	/* these are very large arrays to store IDs of new deaths at each time step */
	long *new_deaths = NULL;
	long *death_dummylist = NULL; /* This is just a dummy list of 0..MAX_N_PER_AGE_GROUP from which we pick the indices of people who will die in deaths_natural_causes() in demographics.c. This list of indices is stored in new_death[]. */

	/* these are very large arrays to store IDs of new partners at each time step */
	long *new_partners_f_sorted = NULL;
	long *shuffled_idx = NULL;
	long *new_partners_f_non_matchable = NULL;
	long *new_partners_m = NULL;
	long *new_partners_m_sorted = NULL;
	long *partner_dummylist = NULL; /* This is a dummy list of 0..MAX_N_PER_AGE_GROUP*MAX_PARTNERSHIPS_PER_INDIVIDUAL from which we pick the indices of people who will make partnerships in draw_new_partnerships() in partnership.c. */

	/* store outputs here: */
	cumulative_outputs_struct *cumulative_outputs = NULL;


	/*****************************************************************************************/
	/*** Set up GSL variables for random numbers, and the values for n_runs and i_startrun ***/
	/*****************************************************************************************/

	gsl_rng_env_setup();

	
	int rng_seed;
	/* Third argument is optional, but can specify seed for RNG: */
	if (argc==3){
		rng_seed = strtol(argv[2],NULL,10);
		i_startrun = 1;
		n_runs = 1;
		printf("Using given random number seed rng_seed=%i, and doing 1 run.\n",rng_seed);
	}
	else if (argc==4){
		rng_seed = strtol(argv[2],NULL,10);
		i_startrun = strtol(argv[3],NULL,10);
		n_runs = i_startrun;
		printf("Using given random number seed rng_seed=%i, and doing run %i only\n",rng_seed,i_startrun);
	}
	else if (argc==5){	
		rng_seed = strtol(argv[2],NULL,10);
		i_startrun = strtol(argv[3],NULL,10);
		n_runs = i_startrun + strtol(argv[4],NULL,10) - 1;
		printf("Using default random number seed rng_seed=%i, with %i runs starting at %i\n",rng_seed,n_runs,i_startrun);
	}
	else{	
		rng_seed = 125; // seed set to a given value for now for debugging
		i_startrun = 1;
		n_runs = 1;
		printf("Using default random number seed rng_seed=%i, with %i runs starting at %i\n",rng_seed,n_runs,i_startrun);
	}
	TYPE_RNG = gsl_rng_default;
	rng = gsl_rng_alloc (TYPE_RNG);
	gsl_rng_set(rng, rng_seed);

	/* To ensure we know what the seed is: */
	printf("Random seed = %i\n",rng_seed);

	/*********************************************************/
	/*** Allocation of memory                              ***/
	/*********************************************************/
	alloc_all_memory(&allrunparameters, n_runs, &individual_population, &pop, &n_population, &n_population_stratified, &age_list, &child_population,
			&partner_pairs, &n_partnerships, &susceptible_in_serodiscordant_partnership, &n_susceptible_in_serodiscordant_partnership, &pop_available_partners, &n_pop_available_partners,
			&hiv_pos_progression, &n_hiv_pos_progression, &size_hiv_pos_progression, &cascade_events, &n_cascade_events, &size_cascade_events, &vmmc_events, &n_vmmc_events, &size_vmmc_events, 
			&planned_breakups, &n_planned_breakups, &size_planned_breakups,
			&new_deaths, &death_dummylist, &new_partners_f_sorted, &shuffled_idx, &new_partners_f_non_matchable, &new_partners_m,  &new_partners_m_sorted, &partner_dummylist,
			&n_infected, &n_newly_infected, &n_infected_wide_age_group, &n_newly_infected_wide_age_group, &chips_sample, &cumulative_outputs);

	
	/*****************************************************/
	/*** READING PARAMETERS                            ***/
	/*****************************************************/
	char systemcall[100];
	sprintf(systemcall,"python %s/make_input_files.py",file_directory);
	
	/* Carry out a system call to run the python script above (ie run the command as specified in systemcall)
	 * systemcallran is a check that this ran OK - otherwise print out a warning message. */
	int systemcallran = system(systemcall);
	
	if (systemcallran!=0)
		fprintf(stderr,"Cannot call python to generate input files. Using existing files.\n");
	
	
	read_param(file_directory,allrunparameters,n_runs);

	/* This specifies whether we are in Zambia (=1) or South Africa (=2). The constants are defined in constants.h 
	 * This variable can be modified to be the cluster id (for example) if needed. 
	 * Note we assume that the country setting does not vary across all the parameter sets.
	 * If this is not the case then we need to move this into the "for i_run" loop. */
	int country_setting = get_setting(allrunparameters);

	//char *label;
	int label_length = 100;
	char * label = (char *)calloc(label_length, sizeof(char)); 
	//strncpy(label,"",100); // Trying to make sure that label is initialized with null characters.
	
	long DEBUGNPARTNERSHIPS;
	long DEBUGNSERODISCORDANTPARTNERSHIPS;
	long DEBUGHIVNEGWITHHIVPOSPARTNERS;
	long NACUTE;
	long NCHRONIC;


	/* Note I have put CHECKMODE outside the parameter for loop. */
	if(CHECKMODE==0)
	{
		for (i_run = (i_startrun-1); i_run<n_runs; i_run++){
			//gsl_rng_set(rng, rng_seed);
			
			
			/* This copies the address of the i_run th parameter set in allrunparameters into param.
			 * param now points to the same thing as allrunparameters[i_run] (rather than making param a copy of allrunparameters[i_run]).
			 * Note that the way this is done, if we modify param->something it also modifies the element in 
			 * allrunparameters[i_run] at the same time. */

			param = allrunparameters+i_run; /* Use pointer arithmetic. */
			
			//print_param_struct(param);      /* For debugging. */

			/* Set relevant counters to zero: */
			reinitialize_arrays_to_default(death_dummylist, partner_dummylist, n_partnerships, 
					n_susceptible_in_serodiscordant_partnership, n_hiv_pos_progression, 
					size_hiv_pos_progression, n_cascade_events, size_cascade_events, 
					n_vmmc_events, size_vmmc_events, n_planned_breakups, size_planned_breakups);

			
			get_trial_arm(param->cluster_number); /* Set the global variable TRIAL_ARM using the cluster number: */

			/* For Pangea we force in the counterfactual for now: */
			if (param->prop_visited_by_chips[MALE]==0 && param->prop_visited_by_chips[FEMALE]==0){
			  TRIAL_ARM = ARM_C;
			  printf("Running counterfactual\n");
			}

			fprintf(stderr,"Run number = %i, trial arm = %i\n",i_run,TRIAL_ARM);
			
			/* Makes the file label of the appropriate form: */
			make_output_filename_labels(label, label_length, param, country_setting, rng_seed, i_run);
	
			year=0;
			
			/*********************************************************/
			/*** Initializing population characteristics ***/
			/*********************************************************/
			
			/* Initializing the population demographics (no partnerships) */
			set_up_population(param,individual_population,pop, n_population,n_population_stratified, child_population,age_list, n_infected, n_newly_infected, country_setting);
	
			/* Initializing free partnerships based on how many free partnerships individuals have */
			init_available_partnerships(pop_available_partners, n_pop_available_partners,pop, n_population);
	
			/* Draw initial partnerships */

			draw_new_partnerships(param->start_time_simul, individual_population,pop_available_partners, n_pop_available_partners, n_population, n_population_stratified, partner_pairs, n_partnerships, param, shuffled_idx, new_partners_f_sorted, new_partners_f_non_matchable, new_partners_m, new_partners_m_sorted, partner_dummylist, planned_breakups, n_planned_breakups, size_planned_breakups, susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership);
	
			//// repeat for debugging so there are opportunities for transmission ////
			for(i=0 ; i<1; i++)//00 ; i++)
			{
				draw_new_partnerships(param->start_time_simul, individual_population,pop_available_partners, n_pop_available_partners, n_population, n_population_stratified, partner_pairs, n_partnerships, param, shuffled_idx, new_partners_f_sorted, new_partners_f_non_matchable, new_partners_m, new_partners_m_sorted, partner_dummylist, planned_breakups, n_planned_breakups, size_planned_breakups, susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership);
			}
	
	
			/* Set cumulative counters to zero: */
			init_cumulative_counters(cumulative_outputs);
	
	
			/* These are not called at present as not sure I update everything related to the dissolved partnership properly. */
			//remove_dead_persons_partners(&individual_population[0],pop_available_partners, n_pop_available_partners, param->start_time_simul);
			//remove_dead_persons_partners(&individual_population[1],pop_available_partners, n_pop_available_partners, param->start_time_simul);
			//remove_dead_persons_partners(&individual_population[2],pop_available_partners, n_pop_available_partners, param->start_time_simul);
	
			/*********************************************************/
			/*** Doing stuff ***/
			/*********************************************************/
	
			//print_individual(&individual_population[10013]);
	
	
	
	
			/* Run everything for multiple years: */
			for (year=param->start_time_simul; year<param->end_time_simul; year++){
				/* These count the number of infections and the number of acute infections during the year.
				 * We can use this to calculate the annual fraction of infections due to acute infectors. */
				PANGEA_N_ANNUALACUTEINFECTIONS = 0;
				PANGEA_N_ANNUALINFECTIONS = 0;
				DEBUG_NHIVPOSLASTYR = DEBUG_NHIVPOS;
				//printf("Year %d\n",year);
				fflush(stdout);
				/* Carry out all weekly processes for a year */
				carry_out_processes(age_list, individual_population, n_population, n_population_stratified, child_population, year, param, new_deaths, death_dummylist, partner_pairs, n_partnerships, pop_available_partners, n_pop_available_partners, new_partners_f_sorted, shuffled_idx, new_partners_f_non_matchable, new_partners_m, new_partners_m_sorted, partner_dummylist, planned_breakups, n_planned_breakups, size_planned_breakups, susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership, n_infected, n_newly_infected, n_infected_wide_age_group, n_newly_infected_wide_age_group, country_setting, hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression, cascade_events, n_cascade_events, size_cascade_events, vmmc_events, n_vmmc_events, size_vmmc_events, chips_sample, cumulative_outputs);
				
				/****** Ageing population by 1 year (update n_population, age_list, available partnerships): *****/
	
				/* Note: Update n_population first (as this uses age_list): */
				update_n_population_ageing_by_one_year(age_list, n_population);
	
				/* Now update available partnerships (also uses age_list, so needs to be updated before we update age_list): */
				update_pop_available_partners_ageing_by_one_year(age_list, pop_available_partners, n_pop_available_partners,(float) year+1);
	
				/* Now update age_list: */
				age_population_by_one_year(age_list);
	
				/* Ageing by 1 year HIV positive people (update n_infected) */
				age_population_size_one_year_age_by_one_year(n_infected);
	
				DEBUGNPARTNERSHIPS = 0;
				DEBUGNSERODISCORDANTPARTNERSHIPS = 0;
				DEBUGHIVNEGWITHHIVPOSPARTNERS = 0;
				NACUTE = 0;
				NCHRONIC = 0;
	
			
				for (i=0;i<id_counter;i++){
					if (individual_population[i].cd4!=DEAD){
						DEBUGNPARTNERSHIPS += individual_population[i].n_partners;
						if (individual_population[i].HIV_status==UNINFECTED){
							DEBUGNSERODISCORDANTPARTNERSHIPS += individual_population[i].n_HIVpos_partners;
							if (individual_population[i].n_HIVpos_partners>0)
								DEBUGHIVNEGWITHHIVPOSPARTNERS++;
						}
						else if (individual_population[i].HIV_status==ACUTE)
							NACUTE++;
						else if (individual_population[i].HIV_status==CHRONIC)
							NCHRONIC++;
					}
				}
	
	
				/* store_annual_outputs is called at the end of the year, so the time at this point is year+1. */
				store_annual_outputs(param, individual_population, n_infected, n_newly_infected, age_list, DEBUG_NHIVPOS-DEBUG_NHIVPOSLASTYR,cumulative_outputs,year+1);
				//printf("Time=end of %d Number HIV+ alive = %li Annual new cases = %li Number HIV+ dead=%li Number partnerships= %li Number s-d partnerships = %li NACUTE=%li NCHR=%li PropAcute=%lf\n",year,DEBUG_NHIVPOS-DEBUG_NHIVDEAD,DEBUG_NHIVPOS-DEBUG_NHIVPOSLASTYR,DEBUG_NHIVDEAD,DEBUGNPARTNERSHIPS/2,DEBUGNSERODISCORDANTPARTNERSHIPS,NACUTE,NCHRONIC,NACUTE/(1.0*(NACUTE+NCHRONIC)));
				//printf("No. partnerships= %li No. s-d pships = %li PropAcute=%lf %li %li \n",DEBUGNPARTNERSHIPS/2,DEBUGNSERODISCORDANTPARTNERSHIPS,NACUTE/(1.0*(NACUTE+NCHRONIC)),DEBUGHIVNEGWITHHIVPOSPARTNERS,NHIVTESTED);
				//fflush(stdout);
				//printf("Prevalent cases:\n");
				//print_population_from_one_year_data(n_infected_wide_age_group, n_infected);
	
				//printf("Incident cases:\n");
				//print_population_from_one_year_data(n_newly_infected_wide_age_group, n_newly_infected);
			}
	
			/* Now try to update pop to seed HIV: */
			//////// To be useful this probably also needs to return the number of people in each element of pop.
			///////// make_pop_from_age_list(pop, age_list, individual_population);		
			//// FOR DEBUGGING make_pop_from_age_list() : check if some random people in pop have the correct details for their position in the pop array: */
			//// printf("pop: %i %f %i %li\n",pop->pop_per_age_risk_per_gender[1][1][2][3]->gender,year-pop->pop_per_age_risk_per_gender[1][1][2][3]->DoB,pop->pop_per_age_risk_per_gender[1][1][2][3]->sex_risk,pop->pop_per_age_risk_per_gender[1][1][2][3]->id);
			//// printf("pop: %i %f %i %li\n",pop->pop_per_age_risk_per_gender[0][5][1][10]->gender,year-pop->pop_per_age_risk_per_gender[0][5][1][10]->DoB,pop->pop_per_age_risk_per_gender[0][5][1][10]->sex_risk,pop->pop_per_age_risk_per_gender[0][5][1][10]->id);
			//// printf("pop: %i %f %i %li\n",pop->pop_per_age_risk_per_gender[0][3][0][25]->gender,year-pop->pop_per_age_risk_per_gender[0][3][0][25]->DoB,pop->pop_per_age_risk_per_gender[0][3][0][25]->sex_risk,pop->pop_per_age_risk_per_gender[0][3][0][25]->id);
			//// printf("pop: %i %f %i %li\n",pop->pop_per_age_risk_per_gender[1][0][1][2]->gender,year-pop->pop_per_age_risk_per_gender[1][0][1][2]->DoB,pop->pop_per_age_risk_per_gender[1][0][1][2]->sex_risk,pop->pop_per_age_risk_per_gender[1][0][1][2]->id);
	
			/*********************************************************/
			/*** Printing stuff ***/
			/*********************************************************/
	
			//print_number_by_age_grouped(age_list,n_population);
	
			if(PRINT_PHYLOGENETICS_OUTPUT>=1)
			{
				/* call files to write individual data and transmission data to csv files: */
				write_phylo_transmission_data(label);
				write_phylo_individual_data(individual_population,label);
	
			}
	
			/* This writes the annual data stored in annual_outputs_string to a file Annual_outputs.csv. */
			write_annual_outputs(label);
	
			//printf("-------------------------------------\n");
			//printf("Prevalent cases:\n");
			//print_population_from_one_year_data(n_infected_wide_age_group, n_infected);
			//printf("Incident cases:\n");
			//print_population_from_one_year_data(n_newly_infected_wide_age_group, n_newly_infected);
			//printf("-------------------------------------\n");
			
			

			/*****************************************************/
			/*** SOME MEMORY CHECKS                            ***/
			/*****************************************************/

			printf("-------------------------------------\n");
			printf("Simulated a total of: %ld individuals\n",id_counter);
			if(id_counter>MAX_POP_SIZE)
			{
				printf("THIS IS MORE THAN PLANNED. NEED TO INCREASE MAX_POP_SIZE NOT TO RUN INTO MEMORY ISSUES\n");
			}
			fflush(stdout);

			printf("-------------------------------------\n");
			printf("Simulated a total of: %ld partnerships\n",n_partnerships[0]);
			if(n_partnerships[0]>MAX_POP_SIZE*MAX_PARTNERSHIPS_PER_INDIVIDUAL)
			{
				printf("THIS IS MORE THAN PLANNED. NEED TO ALLOCATE MEMORY FOR MORE THAN MAX_POP_SIZE*MAX_PARTNERSHIPS_PER_INDIVIDUAL PARTNERHSIPS NOT TO RUN INTO MEMORY ISSUES\n");
			}
			fflush(stdout);

			//FILE *DEBUGHIVDURFILE;
			//DEBUGHIVDURFILE = fopen("DEBUGHIVDURATION.csv","w");
			/*for (i=0;i<id_counter;i++)
				if ((individual_population[i].cd4==DEAD) && (individual_population[i].HIV_status>UNINFECTED)){
					fflush(stdout);
					//fprintf(DEBUGHIVDURFILE,"%f\n",individual_population[i].DEBUGTOTALTIMEHIVPOS);
					printf("%f %i\n",individual_population[i].DEBUGTOTALTIMEHIVPOS,individual_population[i].SPVL);
				}*/
			//fclose(DEBUGHIVDURFILE);

		}
	}else
	{

		/*********************************************************/
		/*** CHECKS AND DEBUGGING PARTNERSHIPS ***/
		/*********************************************************/

		/* The following functions or groups or functions are to be used ONE AT A TIME and without the main simulation working, otherwise individuals with same indexes will be created several times! */

		/***** Check 1 *****/
		/* This standalone function creates 2 women and 2 men, forms partnerships between them and prints output. Memory for these is allocated and freed inside the function. */
		//check_partnership_formation(partner_pairs, n_partnerships, planned_breakups, n_planned_breakups, size_planned_breakups, susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership, param);

		/***** Check 2 *****/
		/* Same as check_partnership_formation but with possible HIV transmission within partnerships */
		//check_partnership_formation_and_HIV_acquisition(partner_pairs, n_partnerships,planned_breakups, n_planned_breakups, size_planned_breakups, susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership, param, n_infected, n_newly_infected);

		/* This standalone function creates 2 women and 2 men, forms partnerships, then dissolves some of them (at a time NOT given by the duration of the partnerships, so e.g. this is what would happen if one of the partners die). */
		//check_partnership_dissolution(partner_pairs, n_partnerships, pop_available_partners, n_pop_available_partners,  planned_breakups, n_planned_breakups, size_planned_breakups, susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership, param);

		/* The combination of the two functions below (to be executed together in this order)
		 * first create an arbitrary population_size object with a certain distribution of the population
		 * and then calculates and prints the number of partnerships to be drawn between each gender/age/risk groups in one time step given this current population distribution
		 * (This allows checking that partnerships are drawn preferentially with similar age/risk groups) */
		//makeFakePop(n_population, n_population_stratified);
		//check_draw_number_partnership(param);

		/*********************************************************/
		/*** CHECKS AND DEBUGGING DEMOGRAPHICS ***/
		/*********************************************************/

		//print_demographics(individual_population, n_population, param->start_time_simul);
		//make_new_adults(cluster_hivneg_child_population,cluster_hivpos_child_population, individual_population, n_population, age_list, param->start_time_simul, param);
		//check_males_females(n_population,individual_population);
		//print_dob(n_population,individual_population);
		//print_population(n_population);
		//validate_ages_based_on_age_group(age_list, 14, param->start_time_simul+year+1);

		/* Print the details of this individual (12 is a random choice - can make anything from 0 to 9999 with the current population size (10000) */
		//	print_individual(&individual_population[12]);

	}


	/*****************************************************/
	/*** FREEING MEMORY                                ***/
	/*****************************************************/

	free_all_memory(allrunparameters, individual_population, pop, n_population, n_population_stratified, age_list, child_population,
			partner_pairs, n_partnerships, susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership, pop_available_partners, n_pop_available_partners,
			hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression,  cascade_events, n_cascade_events, size_cascade_events, vmmc_events, n_vmmc_events, size_vmmc_events, 
			planned_breakups, n_planned_breakups, size_planned_breakups,
			new_deaths, death_dummylist, new_partners_f_sorted, shuffled_idx, new_partners_f_non_matchable, new_partners_m, new_partners_m_sorted, partner_dummylist,
			n_infected, n_newly_infected, n_infected_wide_age_group, n_newly_infected_wide_age_group, chips_sample, cumulative_outputs);

	
	free(label);
	/***** Free GSL rng memory *****/
	gsl_rng_free (rng);
	


	/*****************************************************/
	/*** Finishing program execution                   ***/
	/*****************************************************/


	printf("-------------------------------------\n");
	printf("Simulation successfully finished running.\n");
	fflush(stdout);
	return 0;

}


