/*  This file is part of the PopART IBM.

    The PopART IBM is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The PopART IBM is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the PopART IBM.  If not, see <http://www.gnu.org/licenses/>.
 */


/* Demographic processes for the PopART model:
 * per_woman_fertility_rate(): Rate at which a given woman gets pregnant (or rate at which children born per capita).
 * natural_death_rate():       Natural death rate (as a function of age and calendar time at present). 
 * draw_sex_risk():            Decides an individual's sexual risk group when they become adults (ie enter population at AGE_ADULT).
 * create_new_individual():    Sets up a new individual structure when someone is born, initializing all parameters.
 * initialize_first_cascade_event_for_new_individual(): Schedules first cascade event for a new adult if HIV testting has started (otherwise no need as everyone gets a cascase event assigned when HIV testing begins.) 
 * update_population_size_new_adult(): Updates the population size variable when new adult enters adult population.
 * update_population_size_death(): Updates population size variable when someone dies.
 * update_age_list_new_adult(): Update age list structure when new adult enters adult population.
 * update_age_list_death(): Update age list structure when someone dies.
 * get_age_index():            Given DoB gives the index in the array age_list
 * get_age_group():            Given time and DoB gives the age group index a person belongs to (age groups 13-17,18-22, etc).
 *** The following functions are related to the annual ageing of the whole population by 1 year (ie many lists divide the population into yearly age groups. At the end of each year these lists are "moved" by 1 to represent ageing).
 * update_n_population_ageing_by_one_year(): Update the n_population structure as people age by 1 year.
 * update_pop_available_partners_ageing_by_one_year: Updates list of available partners as people age by 1 year. 
 * age_population_by_one_year: Update the age_list structure as people age by 1 year.
 * age_population_size_one_year_age_by_one_year: Update the population

 *** The following functions remove people from the lists of scheduled events/available people.
 * remove_dead_person_from_susceptible_in_serodiscordant_partnership()
 * remove_dead_person_from_list_available_partners()
 * remove_dead_persons_partners()
 * remove_from_hiv_pos_progression() - note this removes a person from HIV+ progression when on effective ART as well as death.
 * remove_from_cascade_events() - removes someone from cascade_events either due to death, or  we need to schedule an earlier event because of popart 
 
 * deaths_natural_causes(): For each age group calculate the probability of dying p_x per timestep, draws people to die assuming a binomial process with prob p_x, then for each of them calls all the remove_() functions above to delete that individual from any lists of events/available people.
 * make_new_adults(): Looks up how many kids reach adulthood at each timestep, and then makes them.
 * add_new_kids(): This is a DUMMY function to add newly born babies to the child_population structures so that there are always new individuals to reach adulthood as time goes on
 * make_pop_from_age_list(): Update the struct pop (counts of people by age/gender etc) based on the (always up-to-date) struct age_list.
 * individual_death_AIDS(): For an indiv who dies of age this function calls all the processes to remove them from all appropriate lists.
 * ??? Births ???: Function add_new_kids() does this, but automatically makes 10% of kids HIV+

 * ??? Ageing ???
 */


/************************************************************************/
/******************************* Includes  ******************************/
/************************************************************************/

#include "structures.h"
#include "constants.h"
#include "utilities.h"
#include "demographics.h"
#include "init.h"
#include "hiv.h"




/************************************************************************/
/******************************** functions *****************************/
/************************************************************************/

/* Function does: calculates per woman fertility rate based on age. 
 * function arguments: age and pointer to params structure.
 * Function returns: per-year probability that a woman this age gets pregnant if they are in a partnership. 
 * Potential changes: fertility may depend on HIV status and time. Should also be country-specific. */
//// total_fertility_rate should be able to vary over time and country. ////
double per_woman_fertility_rate(int age, parameters *param, double t, int country_setting){
	/* this is the rate at which any one woman of age a gets pregnant and has an offspring that will survive until AGE_ADULT */
	/* note that in the simulation we make sure the women who get pregnant have at least one partner at that time */
	double result = 0;
	if(age>=AGE_ADULT)
		result = param->total_fertility_rate*gsl_ran_gamma_pdf(age, param->shape_fertility_param, param->scale_fertility_param)/gsl_cdf_gamma_Q(AGE_ADULT, param->shape_fertility_param, param->scale_fertility_param);
	return result;
} 


/* Function arguments: age, current time (as natural death rate can depend on time, pointer to param structure.
 * Function does: calculates the natural death rate (ie non-HIV related) of someone aged a at  time t.
 * Function returns: probability of dying in the next YEAR (so need to multiply by timestep). */
double natural_death_rate(int age, double time, parameters *param){
	/* parameters are a bit made up but curve looks plausible */
	double temp = pow(age - AGE_ADULT,1.7);
	//double result = 0.001*temp + hill_down(time-param->start_time_simul,(0.002)*temp,1.0,2020.0-param->start_time_simul) - 4.9;
	double result = 0.001*temp + hill_down(time-param->start_time_simul,(0.002)*temp,1.0,2020.0-param->start_time_simul) - 4.9;
	result = exp(result);
	return result;
}

/* Function does: Assign new individuals to a specific risk group. As it stands the number of new individuals in a given risk class is fixed over time.
 * Function arguments: gender and pointer to param structure.
 * Function returns: the index of the risk group (currently 0,1,2). */
int draw_sex_risk(int gender, parameters *param){
	double x;
	x = gsl_rng_uniform (rng);
	if (x<=(param->initial_prop_gender_risk[gender][LOW]))
		return LOW;
	else if (x<=(param->initial_prop_gender_risk[gender][LOW]+param->initial_prop_gender_risk[gender][MEDIUM]))
		return MEDIUM;
	else 
		return HIGH;
}

/* Function does: creates entries for everything related to that new_person.
 * Function arguments: pointer to new person to be created, current time (for generating a DoB) and a pointer to the param structure (to get probabilities such as gender, MMC, etc).
 * Function returns: nothing. */
void create_new_individual(individual *new_adult, double t, parameters *param, int hivstatus, population_partners *pop_available_partners, population_size *n_pop_available_partners, population_size_one_year_age *n_infected){
	int i;

	new_adult->id = id_counter;        /* Set the id to be the value of id_counter. */

	// For debugging:
	if(new_adult->id==FOLLOW_INDIVIDUAL){
		printf("Creation of adult %ld with hivstatus %i\n",new_adult->id,hivstatus);
		fflush(stdout);
	}

	/* Determine gender based on sex ratio parameter (which is kept fixed for all time): */
	if (gsl_ran_bernoulli(rng,(param->sex_ratio))==1)   /* Assume that the M/F sex ratio is unchanged over time. */
		new_adult->gender = MALE;
	else
		new_adult->gender = FEMALE;
	
	/* Assign a date of birth. Note: we currently assume that people do not enter the adult population aged 13.0, but instead 13.99, otherwise there are problems when ageing. 
	 * As it is we ensure this way that someone who enters the population at the last timestep is aged 14.0 when they are aged to the next year-group one timestep later. */
	new_adult->DoB = t - AGE_ADULT - (N_TIME_STEP_PER_YEAR-1)/(1.0*N_TIME_STEP_PER_YEAR);      
	new_adult->DoD = -1;
	new_adult->DEBUGTOTALTIMEHIVPOS = 0;
	/* Assign a sex risk group: */
	new_adult->sex_risk = draw_sex_risk(new_adult->gender,param);  
	new_adult->n_lifetime_partners = 0;
	new_adult->n_lifetimeminusoneyear_partners = 0;
	// For debugging:
	if (PRINT_DEBUG_DEMOGRAPHICS)
		printf("New adult DoB = %f %li\n",new_adult->DoB,new_adult->id); 

	new_adult->time_to_delivery = -1;  /* Not pregnant when enters population. */
	
	/* Assign HIV status, allowing for the fact that some children may have had perinatal transmission (children are divided into HIV+/- at birth). 
	 * Note that CHRONIC is 2 so need an if statement here. */
	if (hivstatus==0){
		new_adult->HIV_status = UNINFECTED;
		new_adult->ART_status = ARTNEG;
		new_adult->next_HIV_event = NOEVENT; /* Initialize at dummy value. */
		new_adult->next_cascade_event = NOEVENT; /* Initialize at dummy value. */
		new_adult->viral_load = 0;                       //// May not use?
		new_adult->cd4 = CD4_UNINFECTED;                 /* Initialize at dummy value, here -1 */
		new_adult->SPVL = -1;                            /* Initialize at dummy value. */
		new_adult->time_last_hiv_test = NEVERHIVTESTED;  /* Assume never previously tested. */
		new_adult->t_sc = -1;                            /* Initialize at dummy value. */
		new_adult->idx_hiv_pos_progression[0] = -1;     /* Initialize at dummy value. */
		new_adult->idx_hiv_pos_progression[1] = -1;     /* Initialize at dummy value. */
		/* Note these two are also set/overwritten in initialize_first_cascade_event_for_new_individual().
		 * However that function is only called if HIV testing has started, and we need to set them to dummy values (if doing several runs this is part of resetting the memory). */
		new_adult->idx_cascade_event[0] = -1;           /* Initialize at dummy value. */
		new_adult->idx_cascade_event[1] = -1;           /* Initialize at dummy value. */
		new_adult->idx_vmmc_event[0] = NOEVENT;         /* Initialize at dummy value. */
		new_adult->idx_vmmc_event[1] = -1;		

		/* PANGEA stuff: */
		new_adult->PANGEA_t_prev_cd4stage = -1.0;
		new_adult->PANGEA_t_next_cd4stage = -1.0;
		new_adult->PANGEA_cd4atdiagnosis = -1.0;
		new_adult->PANGEA_cd4atfirstART = -1.0;
		new_adult->PANGEA_t_diag = -1.0;
		new_adult->PANGEA_date_firstARTstart = -1.0;
		new_adult->PANGEA_date_startfirstVLsuppression = -1.0;
		new_adult->PANGEA_date_endfirstVLsuppression = -1.0;
	}
	else{
		(n_infected->pop_size_per_gender_age1_risk[new_adult->gender][n_infected->youngest_age_group_index][new_adult->sex_risk]) += 1;
		printf("+++ One new HIV+ (new adult) \n");
		fflush(stdout);

		new_adult->HIV_status = CHRONIC;
		new_adult->ART_status = LTART_VS;                // Assume any new adult who has made it this far is successfully on ART 
		new_adult->viral_load = 0;                       //// May not use?
		new_adult->cd4 = CD4_UNINFECTED;                 /// WRONG!!!
		new_adult->SPVL = -1;                            /// WRONG!!!
		new_adult->time_last_hiv_test = t - AGE_ADULT;  ///  Assume that someone who survived this long was tested at birth. Not important anyway as we would be interested in ADULT testing in last year or less. 
		new_adult->t_sc = t - AGE_ADULT;                /* Seroconverted at birth. */
		new_adult->idx_vmmc_event[0] = NOEVENT;         /* Initialize at dummy value. */
		new_adult->idx_vmmc_event[1] = -1;

		new_adult->PANGEA_t_prev_cd4stage = -1.0;
		new_adult->PANGEA_t_next_cd4stage = -1.0;
		new_adult->PANGEA_cd4atdiagnosis = -1.0;
		new_adult->PANGEA_cd4atfirstART = -1.0;
		new_adult->PANGEA_t_diag = new_adult->time_last_hiv_test;
		new_adult->PANGEA_date_firstARTstart = -1.0;
		new_adult->PANGEA_date_startfirstVLsuppression = -1.0;
		new_adult->PANGEA_date_endfirstVLsuppression = -1.0;

		printf("Need to work out what is happening with new adults turning 13 who are HIV+\n"); 
		printf("Also need to schedule HIV and ART events for them. \n");
	}
	

	/* Set up partnerships later on, so initialize to zero here:. */
	new_adult->n_partners = 0;         
	new_adult->n_HIVpos_partners = 0;


	
	// At present set_max_n_partners() does not actually use age group or gender.
	/* set_max_n_partners() depends on gender, age group and risk group. This is a new adult so age group is 0. */
	new_adult->max_n_partners = set_max_n_partners(new_adult->gender, 0, new_adult->sex_risk, param);  

	/* Number of sexual partners outside cluster: */
	new_adult->n_partners_outside = 0;

	/* If male, decide if circumcised (as a child, not by trial) here: */
	if (new_adult->gender==MALE){
		if (gsl_ran_bernoulli(rng,(param->p_child_circ))==1)
			new_adult->circ = TRADITIONAL_MC;
		else
			new_adult->circ = UNCIRC;
	}
	else
		new_adult->circ = 0;   /* Women - set to zero. */	

	
	new_adult->idx_serodiscordant = -1;  /* Not in a serodiscordant partnership */

	
	/* Add all the available partnerships (max_n_partners as they do not have any yet) to the list of available partnerships
	 * and create references to these in the new_adult individual structure. */
	for(i=new_adult->n_partners ; i<new_adult->max_n_partners ; i++){
		/* Add to end of pop_available_partners array element: */ 
		new_adult->idx_available_partner[i] = n_pop_available_partners->pop_size_per_gender_age_risk[new_adult->gender][0][new_adult->sex_risk]; /* Not yet in the list of available partners */
		/* Note that age group = 0 as new adults. */
		pop_available_partners->pop_per_gender_age_risk[new_adult->gender][0][new_adult->sex_risk][n_pop_available_partners->pop_size_per_gender_age_risk[new_adult->gender][0][new_adult->sex_risk]] = new_adult; 
		n_pop_available_partners->pop_size_per_gender_age_risk[new_adult->gender][0][new_adult->sex_risk]++;
	}
	
	/* Above max_n_partners set the rest of the entries to -1 - this is a checking mechanism to ensure we never give them more than max_n_partners. */
	for(i=new_adult->max_n_partners ; i<MAX_PARTNERSHIPS_PER_INDIVIDUAL ; i++){
		new_adult->idx_available_partner[i] = -1; /* Not in the list of available partners */
	}
}

void initialize_first_cascade_event_for_new_individual(individual *new_adult, double t, parameters *param, individual ***cascade_events, long *n_cascade_events, long *size_cascade_events){
	if (new_adult->HIV_status==UNINFECTED){
		schedule_new_hiv_test(new_adult, param, t, cascade_events, n_cascade_events, size_cascade_events);
	}
	else{
		printf("What is the next cascade event if born HIV+?\n");
		// ASSUMPTION!!! - change when we work out what happens to people who have been HIV+ since birth. 
		new_adult->next_cascade_event = NOEVENT;
		new_adult->idx_cascade_event[0] = -1;
		new_adult->idx_cascade_event[1] = -1;
	}
}



/* Function arguments: pointer to an individual new_adult, pointer to a population_size n_population
 * Function does: updates the population_size according to the new_adult after his/her birth
 * Function returns: nothing. */
void update_population_size_new_adult(individual *new_adult, population_size *n_population, 
		stratified_population_size *n_population_stratified){
	/* Add to first age group ag=0. */
	(n_population->pop_size_per_gender_age_risk[new_adult->gender][0][new_adult->sex_risk])++;
	(n_population_stratified->pop_size_per_gender_age[new_adult->gender][0])++;
	(n_population_stratified->pop_size_per_gender_risk[new_adult->gender][new_adult->sex_risk])++;
	(n_population_stratified->total_pop_size_per_gender[new_adult->gender])++;

	/* Now overall population: */
	//(n_population_stratified->pop_size_per_age_risk[0][new_adult->sex_risk])++;
	//(n_population_stratified->pop_size_per_age[0])++;
	//(n_population_stratified->pop_size_per_risk[new_adult->sex_risk])++;
	(n_population_stratified->total_pop_size)++;

	int r, g; //// arguably we will do this many times so maybe write as a separate inline function?
	for (g=0; g<N_GENDER; g++){
		for (r=0; r<N_RISK; r++){
			n_population_stratified->prop_pop_per_gender_risk[g][r] = n_population_stratified->pop_size_per_gender_risk[g][r]/n_population_stratified->total_pop_size_per_gender[g];
		}
	}
}

/* Function does: Updates population size structure n_population when an individual dies.  
 * Function arguments: pointer to the specific individual who dies, pointer to population_size structure, age group index (age groups 13-18, 19-22, 23-30, etc). 
 * Function returns: Nothing. */
void update_population_size_death(individual *individual, population_size *n_population, 
		population_size_one_year_age *n_infected, stratified_population_size *n_population_stratified, int aa, age_list_struct *age_list){

	int ag = FIND_AGE_GROUPS[aa];
	int ai;
	if (PRINT_DEBUG_DEMOGRAPHICS)
		printf("Dead adult: ID = %li DoB = %f gender = %i risk = %i age gp =%i\n",individual->id,individual->DoB,individual->gender,individual->sex_risk,ag);

	(n_population->pop_size_per_gender_age_risk[individual->gender][ag][individual->sex_risk])--;

	/* Remove from prevalent cases if HIV+. */
	if (individual->HIV_status>UNINFECTED){
		if (aa<MAX_AGE-AGE_ADULT){
			ai = n_infected->youngest_age_group_index + aa; /* ai is the index of the two arrays age_list->number_per_age_group and age_list->age_group */
			if (ai>(MAX_AGE-AGE_ADULT-1))
				ai = ai - (MAX_AGE-AGE_ADULT);
			// FOR DEBUGGING ONLY:
			//check_age_group_index(age_list, individual->id,ai); /// could be removed as only checking things ///
			(n_infected->pop_size_per_gender_age1_risk[individual->gender][ai][individual->sex_risk]) -= 1;
			//printf("--- One death of HIV+ (age group %d, gender %d risk group %d)\n",ai, individual->gender, individual->sex_risk);
			//fflush(stdout);
		}
		else{
			(n_infected->pop_size_oldest_age_group_gender_risk[individual->gender][individual->sex_risk]) -= 1;
			//printf("--- One death of HIV+ (old, gender %d risk group %d)\n",individual->gender, individual->sex_risk);
			//fflush(stdout);
		}
	}
	
	
	(n_population_stratified->pop_size_per_gender_age[individual->gender][ag])--;
	(n_population_stratified->pop_size_per_gender_risk[individual->gender][individual->sex_risk])--;
	(n_population_stratified->total_pop_size_per_gender[individual->gender])--;

	/* Now overall population: */
	//(n_population_stratified->pop_size_per_age_risk[ag][individual->sex_risk])--;
	//(n_population_stratified->pop_size_per_age[ag])--;
	//(n_population_stratified->pop_size_per_risk[individual->sex_risk])--;
	(n_population_stratified->total_pop_size)--;

	int r, g; //// arguably we will do this many times so maybe write as a separate inline function?
	for (g=0; g<N_GENDER; g++){
		for (r=0; r<N_RISK; r++){
			n_population_stratified->prop_pop_per_gender_risk[g][r] = n_population_stratified->pop_size_per_gender_risk[g][r]/n_population_stratified->total_pop_size_per_gender[g];
		}
	}

}

/* Function arguments: pointer to age_list, pointer to the new individual who has entered adult population.
 * Function does: Updates age_list when a new adult enters the adult population (from the child population). */
void update_age_list_new_adult(age_list_struct *age_list, individual *individual_ptr){

	int yi = age_list->youngest_age_group_index; /* Temporary store so we don't have to keep referring to this index the long way. */

	/* Add the pointer to the new adult to the youngest age group: */
	age_list->age_group[yi][age_list->number_per_age_group[yi]] = individual_ptr;
	
	/* Adds one to the count of youngest age group. */
	(age_list->number_per_age_group[yi])++;
}


/* Function arguments: pointer to age_list, a=age of individual to die,
 * 						new_death = the index of the person to die within its age group, t=time
 * Function does: Updates age_list when an adult leaves the adult population (dying from natural or HIV-related causes).
 * Function returns: Nothing. */
void update_age_list_death(age_list_struct *age_list, int aa, long new_death, double t){

	/* We have divided up the population in age_list so that individuals aged 13-79 are kept in arrays (by year) within
	 * age_list->age_group. People aged 80+ are kept separately and dealt with in the next part of the if statement. */
	if (aa<(MAX_AGE-AGE_ADULT)){
		if (PRINT_DEBUG_DEMOGRAPHICS)
			printf("Getting rid of: %f %li. ",(age_list->age_group)[aa][new_death]->DoB,(age_list->age_group)[aa][new_death]->id);

		/* We always want to keep the age_list->age_group[aa] arrays ordered so that the first age_list->number_per_age_group[aa]
		 * individuals are still alive (anything after this point can be a dead person or uninitialized as we should
		 * never access beyond that). To do this we just swap the last person in the list (who is still alive) with
		 * the person who just died. If the last person in the list is the dead person it does not matter because we 
		 * also decrease  number_per_age_group by 1 so they are moved outside the list of alive people in any case. */
		(age_list->age_group)[aa][new_death] = (age_list->age_group)[aa][age_list->number_per_age_group[aa]-1];
		(age_list->number_per_age_group[aa])--;
		
		if (PRINT_DEBUG_DEMOGRAPHICS && (new_death<(age_list->number_per_age_group[aa])))
			printf("Swapped to: %f %li\n",(age_list->age_group)[aa][new_death]->DoB,(age_list->age_group)[aa][new_death]->id);
	}
	/* Now deal with individuals who are aged 80+ - these are kept in a separate array (oldest_age_group): */
	else{
		if (PRINT_DEBUG_DEMOGRAPHICS)
			printf("Getting rid of: %f %li. ",(age_list->oldest_age_group)[new_death]->DoB,(age_list->oldest_age_group)[new_death]->id);

		/* This is the same swap as above. */
		(age_list->oldest_age_group)[new_death] = (age_list->oldest_age_group)[age_list->number_oldest_age_group-1];
		(age_list->number_oldest_age_group)--;

		if (PRINT_DEBUG_DEMOGRAPHICS && (new_death<(age_list->number_oldest_age_group)))
			printf("Swapped to: %f %li %i\n",(age_list->oldest_age_group)[new_death]->DoB,(age_list->oldest_age_group)[new_death]->id,(age_list->oldest_age_group)[new_death]->gender);
	}

}



int get_age_index(double DoB, double start_simul){ /// Do we ever use this?
   
   int ai = ( (int) floor(start_simul - DoB)) - AGE_ADULT;
   /* Here we MUST use a while loop instead of an if statement as if someone is born in 2100, then ai is still negative if we just do this once. */
   while (ai<0)
	   ai += (MAX_AGE-AGE_ADULT);
   return ai;
}   
   
/* Function arguments: date of birth and current time t.
 * Function does: works out the index ag of the AGE_GROUPS[] to which someone with a given DoB belongs at 
 * THE BEGINNING OF THE YEAR IN WHICH time t is (note - age groups are 13-17, 18-22, etc).
 * Function returns: the index ag. */
int get_age_group(double DoB, double t){
	double age = floor(t) - DoB;
	int ag=0;
	if (age<AGE_GROUPS[N_AGE-1])
		while (AGE_GROUPS[ag+1]<=age)
			ag++;
	else
		return  (N_AGE-1);
	return ag;
}


/* Function updates n_population as it ages by one year (ageing is by cohort). */
void update_n_population_ageing_by_one_year(age_list_struct *age_list, population_size *n_population){
	/* aa+AGE_ADULT is the age of the person (so aa runs from 0..MAX_AGE-AGE_ADULT).
	 * ai is the corresponding row index for them in age_list->age_group[ai][] and age_list->number_per_age_group[ai];
	 * age_index is the index in the array AGE_GROUPS[] (which runs up to N_AGE). */
	int age_index, aa, ai, n;
	int n_age_ai;  /* Number of people with age index ai. */

	/* Deliberately starting at age_index=1 - we are interested in ageing the population by one year, but those aged 12 turning 13 are dealt with separately as new adults. */
	for (age_index=1; age_index<N_AGE; age_index++){
		/* We are interested in those about to transition to the next age group - so take -1 as this is the age of those about to transition. */ 
		aa = AGE_GROUPS[age_index]-AGE_ADULT-1;
		ai = age_list->youngest_age_group_index + aa; /* ai is the index of the array age_list->number_per_age_group of the age group of people you want to be dead */
		if (ai>(MAX_AGE-AGE_ADULT-1))
			ai = ai - (MAX_AGE-AGE_ADULT);
		n_age_ai = age_list->number_per_age_group[ai];
		/* Modify n_population for the given individuals of age aa+AGE_ADULT; 
		 * Note that these transitions are 17->18, 22->23, 30->31, 40->41, 50->51, 60->61. */
		for (n=0; n<n_age_ai; n++){
			n_population->pop_size_per_gender_age_risk[age_list->age_group[ai][n]->gender][age_index-1][age_list->age_group[ai][n]->sex_risk]--;
			n_population->pop_size_per_gender_age_risk[age_list->age_group[ai][n]->gender][age_index][age_list->age_group[ai][n]->sex_risk]++;
		}
	}
}



/* Function updates pop_available_partners and n_pop_available_partners as population ages by one year (ageing is by cohort). 
 * It does this by going through each individual who is about to age (NOTE: it is important that this is called out before age_list is updated)
 * For each individual we go through each of their available partnerships and move each one to the new age group as needed. 
 * Code can probably be sped up - the issue with making pop_available_partners into 1 years age groups is that the number in each age group
 * will be small so more chance for having two identical partnerships formed (not clear how to prevent this). */
void update_pop_available_partners_ageing_by_one_year(age_list_struct *age_list, population_partners *pop_available_partners, population_size *n_pop_available_partners, double t){
	/* aa+AGE_ADULT is the age of the person (so aa runs from 0..MAX_AGE-AGE_ADULT).
	 * ai is the corresponding row index for them in age_list->age_group[ai][] and age_list->number_per_age_group[ai];
	 * age_index is the index in the array AGE_GROUPS[] (which runs up to N_AGE). */
	int age_index, aa, ai, n, i, i2;
	int g, r;
	int n_age_ai;  /* Number of people with age index ai. */
	individual *this_person;
	individual *personB;

	//// Debug:
	//for 
	//printf("update_pop_available_partners_ageing_by_one_year: %li\n",n_pop_available_partners->pop_size_per_gender_age_risk[0][1][0]);
	//printf("Check this person is here: %li\n",pop_available_partners->pop_per_gender_age_risk[0][1][0][(n_pop_available_partners->pop_size_per_gender_age_risk[0][1][0])-1]->id);
	//fflush(stdout);
	/* Deliberately starting at age_index=1 - we are interested in ageing the population by one year, but those aged 12 turning 13 are dealt with separately as new adults. */
	for (age_index=1; age_index<N_AGE; age_index++){

		/* We are interested in those about to transition to the next age group - so take -1 as this is the age of those about to transition. */ 
		aa = AGE_GROUPS[age_index]-AGE_ADULT-1;

		ai = age_list->youngest_age_group_index + aa; /* ai is the index of the array age_list->number_per_age_group of the age group of people you want to be dead */
		if (ai>(MAX_AGE-AGE_ADULT-1))
			ai = ai - (MAX_AGE-AGE_ADULT);
		n_age_ai = age_list->number_per_age_group[ai];
		if (PRINT_DEBUG_DEMOGRAPHICS){
			if (age_index==1){
				printf("Check age is an 18 year old: %f\n",t-age_list->age_group[ai][0]->DoB);
				printf("Check age is an 18 year old: %f %f\n",t-age_list->age_group[ai][age_list->number_per_age_group[ai]]->DoB,age_list->age_group[ai][age_list->number_per_age_group[ai]]->DoB);
			}
		}
		/* Modify n_population for the given individuals of age aa+AGE_ADULT; 
		 * Note that these transitions are 17->18, 22->23, 30->31, 40->41, 50->51, 60->61. */

		for (n=0; n<n_age_ai; n++){
			/* Use the pointer as an alias for this person - makes code more readable + possibly a bit quicker? */
			this_person = age_list->age_group[ai][n]; 
			/*if (this_person->id==10013)
				printf("10013 moving out of age group: %i with DoB %f\n",age_index-1,this_person->DoB);*/

			if(this_person->id==FOLLOW_INDIVIDUAL)
			{
				printf("Individual %ld is aged: age group %d \n",this_person->id,age_index-1);
				fflush(stdout);
			}

			g = this_person->gender;
			r = this_person->sex_risk;

			//printf("Current g a r = %i %i %i\n",g,age_index,r);
			//printf("XXupdate_pop_available_partners_ageing_by_one_year: %li\n",n_pop_available_partners->pop_size_per_gender_age_risk[0][1][0]);
			//printf("Check this person is here: ID=%li CD4=%i idx=%i\n",pop_available_partners->pop_per_gender_age_risk[0][1][0][(n_pop_available_partners->pop_size_per_gender_age_risk[0][1][0])-1]->id,pop_available_partners->pop_per_gender_age_risk[0][1][0][(n_pop_available_partners->pop_size_per_gender_age_risk[0][1][0])-1]->cd4,pop_available_partners->pop_per_gender_age_risk[0][1][0][(n_pop_available_partners->pop_size_per_gender_age_risk[0][1][0])-1]->idx_available_partner[0]);
			//fflush(stdout);
			/* We go over all available partnerships of this person. */ 
			i = 0;
			//printf("This person: %i %i %f\n",g,r,this_person->DoB);
			while ((this_person->idx_available_partner[i]>-1) && (i<(this_person->max_n_partners-this_person->n_partners)) && (n_pop_available_partners->pop_size_per_gender_age_risk[g][age_index-1][r]>0)){
				/* Swap this person's available index with that of the last person in the array (we'll call them person B): 
				 * Firstly swap the pointer with the pointer of person B: */
				//printf("HEY2x %li %i %i %i\n",n_pop_available_partners->pop_size_per_gender_age_risk[g][age_index-1][r],g,age_index-1,r);
				//printf("Last person: %i %i %f %li\n",pop_available_partners->pop_per_gender_age_risk[g][age_index-1][r][(n_pop_available_partners->pop_size_per_gender_age_risk[g][age_index-1][r])-1]->gender,pop_available_partners->pop_per_gender_age_risk[g][age_index-1][r][n_pop_available_partners->pop_size_per_gender_age_risk[g][age_index-1][r]-1]->sex_risk,pop_available_partners->pop_per_gender_age_risk[g][age_index-1][r][n_pop_available_partners->pop_size_per_gender_age_risk[g][age_index-1][r]-1]->DoB,pop_available_partners->pop_per_gender_age_risk[g][age_index-1][r][(n_pop_available_partners->pop_size_per_gender_age_risk[g][age_index-1][r])-1]->id);
				personB = pop_available_partners->pop_per_gender_age_risk[g][age_index-1][r][n_pop_available_partners->pop_size_per_gender_age_risk[g][age_index-1][r]-1];

				pop_available_partners->pop_per_gender_age_risk[g][age_index-1][r][this_person->idx_available_partner[i]] = personB;

				/* Now adjust the idx_available_partner element of person B to reflect this change in pop_available_partners: 
				 * Unfortunately we have to look through their partnerships to find the right one: */
				i2 = personB->max_n_partners-personB->n_partners-1;
				while ((personB->idx_available_partner[i2]!=n_pop_available_partners->pop_size_per_gender_age_risk[g][age_index-1][r]-1) && (personB->idx_available_partner[i2]>=0) && (i2>=0)){
					//printf("HEY %i %i %li\n",i2,personB->idx_available_partner[i2],n_pop_available_partners->pop_size_per_gender_age_risk[g][age_index-1][r]-1);
					if ((personB->idx_available_partner[i2]==-1)|| (i2<0)){
						printf("Can't find person B's index in update_pop_available_partners_ageing_by_one_year\n");
						exit(1);
					}
					i2--;
				}
				//	if (this_person->id==10013){
				//	printf("Swapping 10013 idx = %i (%li) with %li's idx=%i (%li): \n",i, this_person->idx_available_partner[i],personB->id,i2,personB->idx_available_partner[i2]);
				//	printf("Now 10013's indices are: %li %li %li %li %li %li %li %li %li \n",this_person->idx_available_partner[0],this_person->idx_available_partner[1],this_person->idx_available_partner[2],this_person->idx_available_partner[3],this_person->idx_available_partner[4],this_person->idx_available_partner[5],this_person->idx_available_partner[6],this_person->idx_available_partner[7],this_person->idx_available_partner[8]);
				//}
				////* Note that in general we can swap indices from the same person. The only problem comes if we are trying to swap the same index (which should be because they are the last person). 
				/// * In that case we actually don't need to do anything.*/

				//if (personB->idx_available_partner[i2]==this_person->idx_available_partner[i]){



				/* Now we've got the correct index i2 set this to point to the new place in pop_available_partners (ie where this_person was): */		
				personB->idx_available_partner[i2] = this_person->idx_available_partner[i];

				/* Next decrease the number of available partners in age_index-1: */
				n_pop_available_partners->pop_size_per_gender_age_risk[g][age_index-1][r]--;

				/* Add ageing person into the pop_available_partners for new age group (note that because we are adding to the end, no need for "-1" in the last index: */
				pop_available_partners->pop_per_gender_age_risk[g][age_index][r][n_pop_available_partners->pop_size_per_gender_age_risk[g][age_index][r]] = this_person;
				/* Modify idx_available_partner of this person: */
				this_person->idx_available_partner[i] = n_pop_available_partners->pop_size_per_gender_age_risk[g][age_index][r];

				/* Finally increase the number of available partners in this age group: */
				n_pop_available_partners->pop_size_per_gender_age_risk[g][age_index][r]++;
				/* Now go to next potential available partner: */
				i++;
			}

		}
	}
}


/* Function arguments: pointer to the age_list structure (which essentially contains lists of individuals in each group). 
 * Function does: moves the pointers for each age group by 1, moves MAX_AGE-1 age people into MAX_AGE group.
 * Function returns: nothing. */
void age_population_by_one_year(age_list_struct *age_list){
	int number_age_MAX_AGEminusone;
	int n;

	/* If we have not reached the start of the array, move backwards to the previous element in the array. */
	if ((age_list->youngest_age_group_index) > 0){

		//printf("Oldest age group person:%f\n",age_list->oldest_age_group[(age_list->number_oldest_age_group)-1]->DoB);

		/* Move people aged MAX_AGE-1 into age_list->oldest_age_group[]. */
		////1:/* Note: ((age_list->youngest_number_per_age_group_ptr)-1) should be a pointer to the previous group to the youngest age group (ie the group aged MAX_AGE-1). */
		number_age_MAX_AGEminusone = age_list->number_per_age_group[age_list->youngest_age_group_index-1];

		/* sending individuals aged 79 into 80+ */
		for (n=0; n<number_age_MAX_AGEminusone; n++){
			/* Copy pointers from one array of pointers to another. */
			/* What this does is it copies all the pointers of people turning AGE_MAX into the oldest_age_group array of pointers. */
			////1:age_list->oldest_age_group[(age_list->number_oldest_age_group)+n] = (age_list->youngest_age_group-1)[n];
			age_list->oldest_age_group[(age_list->number_oldest_age_group)+n] = age_list->age_group[age_list->youngest_age_group_index-1][n];


			/* Make the pointer in the individual structure point to this place in the age_list. */
			//// Not necessary?:
			////(age_list->oldest_age_group[(age_list->number_oldest_age_group)+n])->age_list_ptr = age_list->oldest_age_group[(age_list->number_oldest_age_group)+n]; 
			//if (PRINT_DEBUG_DEMOGRAPHICS)
			//	printf("Moving age group DoB = %f\n",(age_list->age_group[age_list->youngest_age_group_index-1][n])->DoB); 
		}

		/* Update count in age_list->oldest_age_group[]. */
		age_list->number_oldest_age_group += number_age_MAX_AGEminusone;

		/* We have just removed everyone from the MAX_AGE-1 age group. This now becomes the counter for the youngest age group, so set to zero. */
		if (PRINT_DEBUG_DEMOGRAPHICS)
			printf("Number in youngest age group was %li, is %li\n",age_list->number_per_age_group[age_list->youngest_age_group_index],age_list->number_per_age_group[age_list->youngest_age_group_index-1]);

		////1:*((age_list->youngest_number_per_age_group_ptr) -1) = 0;
		age_list->number_per_age_group[age_list->youngest_age_group_index-1] = 0;


		/* Move the pointer for the youngest age group to the start of the array. */
		(age_list->youngest_age_group_index)--;
		////1:(age_list->youngest_age_group)--;
		////1:(age_list->youngest_number_per_age_group_ptr)--;
		////1:age_list->youngest_number_per_age_group_index--;
		/* Note: we probably ought to set the pointers in age_list for what used to be the MAX_AGE-1 group to NULL, but it's not essential as the count should tell us that there should be nobody there. */

		if (PRINT_DEBUG_DEMOGRAPHICS)
			printf("First entry in former young person list = %li %i %f\n",age_list->age_group[age_list->youngest_age_group_index][0]->id,age_list->age_group[age_list->youngest_age_group_index][0]->gender,age_list->age_group[age_list->youngest_age_group_index][0]->DoB);
		////1:printf("First entry in former young person list = %i %i %f\n",		(age_list->youngest_age_group)[0]->id,(age_list->youngest_age_group)[0]->gender,(age_list->youngest_age_group)[0]->DoB);
	}
	else{		
		/* Move people aged MAX_AGE-1 into age_list->oldest_age_group[]. */
		number_age_MAX_AGEminusone = age_list->number_per_age_group[MAX_AGE-AGE_ADULT-1];
		if (PRINT_DEBUG_DEMOGRAPHICS)
			printf("number to move to oldest age group = %i\n",number_age_MAX_AGEminusone);
		for (n=0; n<number_age_MAX_AGEminusone; n++){
			/* Copy pointers from one array of pointers to another. */
			if (PRINT_DEBUG_DEMOGRAPHICS)
				printf("Moving age group DoB = %f\n",(age_list->age_group[MAX_AGE-AGE_ADULT-1][n]->DoB));
			age_list->oldest_age_group[(age_list->number_oldest_age_group)+n] = age_list->age_group[MAX_AGE-AGE_ADULT-1][n]; 
			/* Make the pointer in the individual structure point to this place in the age_list. */
			//// Not necessary?:
			////(age_list->oldest_age_group[(age_list->number_oldest_age_group)+n])->age_list_ptr = age_list->oldest_age_group[(age_list->number_oldest_age_group)+n];
		}


		/* Update count in age_list->oldest_age_group[]. */		
		age_list->number_oldest_age_group += age_list->number_per_age_group[MAX_AGE-AGE_ADULT-1];

		/* We have just removed everyone from the MAX_AGE-1 age group. This now becomes the counter for the youngest age group, so set to zero. */
		age_list->number_per_age_group[MAX_AGE-AGE_ADULT-1] = 0;

		/* Move the pointer for the youngest age group to the end of the array. */
		////1:age_list->youngest_age_group = age_list->age_group[MAX_AGE-AGE_ADULT-1];
		age_list->youngest_age_group_index = MAX_AGE-AGE_ADULT-1;
		////1:(age_list->youngest_number_per_age_group_ptr) = &(age_list->number_per_age_group[MAX_AGE-AGE_ADULT-1]);
		/* Note: we probably ought to set the pointers in age_list for what used to be the MAX_AGE-1 group to NULL, but it's not essential as the count should tell us that there should be nobody there. */
		////1:age_list->youngest_number_per_age_group_index = MAX_AGE-AGE_ADULT-1;

	}

}


//////////////////////
/* Function arguments: pointer to the population_size_one_year_age structure
 * Function does: moves the pointers for each age group by 1, moves MAX_AGE-1 age people into MAX_AGE group.
 * Function returns: nothing. */
void age_population_size_one_year_age_by_one_year(population_size_one_year_age *n_local_pop){
	int g,r;

	/* If we have not reached the start of the array, move backwards to the previous element in the array. */
	if ((n_local_pop->youngest_age_group_index) >= 1){
		for (g=0; g<N_GENDER; g++){
			for (r=0; r<N_RISK; r++){
				/* Merge people aged 79 (who are turning 80 now) into the 80+ year-age group: */
				n_local_pop->pop_size_oldest_age_group_gender_risk[g][r] += n_local_pop->pop_size_per_gender_age1_risk[g][n_local_pop->youngest_age_group_index-1][r]; 

				/* As everyone has aged by 1 year there are no people currently HIV+ aged 13: */
				n_local_pop->pop_size_per_gender_age1_risk[g][n_local_pop->youngest_age_group_index-1][r] = 0;
			}
		}
		/* Move the index for the youngest age group one back. */
		(n_local_pop->youngest_age_group_index)--;
	}
	else if ((n_local_pop->youngest_age_group_index)==0){

		for (g=0; g<N_GENDER; g++){
			for (r=0; r<N_RISK; r++){		
				/* Merge people aged 80+ into the 79 year-age group (so that the 79 group becomes the new 80+ group): */
				n_local_pop->pop_size_oldest_age_group_gender_risk[g][r] += n_local_pop->pop_size_per_gender_age1_risk[g][MAX_AGE-AGE_ADULT-1][r];

				/* As everyone has aged by 1 year there are no people currently HIV+ aged 13: */
				n_local_pop->pop_size_per_gender_age1_risk[g][MAX_AGE-AGE_ADULT-1][r] = 0;
			}
		}
		/* Move the index for the youngest age group to the right-hand end of the array: */
		(n_local_pop->youngest_age_group_index) = MAX_AGE-AGE_ADULT-1;
	}
	else{
		printf("Error: n_local_pop ageing process is not working!\n");
		exit(1);
	}
}



/* Function arguments: pointer to the person who died. 
 * Function does: removes a dead person from the list of susceptible_in_serodiscordant_partnership 
 * and n_susceptible_in_serodiscordant_partnership structs.
 * Only call this function if dead_person->idx_serodiscordant is >=0.
 * Function returns: nothing. */ 		
void remove_dead_person_from_susceptible_in_serodiscordant_partnership(individual *dead_person, 
		individual **susceptible_in_serodiscordant_partnership, long *n_susceptible_in_serodiscordant_partnership){
	int n,i;
	individual *a_partner;

	
	/* We only need to update serodiscordant partnerships when the dead individual is seropositive. */ 
	if ((dead_person->HIV_status)>UNINFECTED){
		if(dead_person->id==FOLLOW_INDIVIDUAL)
			{
				printf("Individual %ld is dying - removing from susceptible in serodiscordant partnerships\n",dead_person->id);
				fflush(stdout);
			}		
		for (n=0; n<dead_person->n_partners; n++){
			a_partner = dead_person->partner_pairs[n]->ptr[1-dead_person->gender];
			
			/* Only need to deal with the partner if the partner is HIV-. */
			if (a_partner->HIV_status==UNINFECTED){
				/* If they only have 1 seropositive partner (which should be the dead person), then remove them from the list susceptible_in_serodiscordant_partnership. */
				if (a_partner->n_HIVpos_partners==1){
					/* Provided there is more than one HIV- in any serodiscordant partnership, do the following:
					 *  - swap out that person for the last person in the list.
					 *  - reduce the number of people in the list by 1.
					 *  - for the last person in the list, change their idx_serodiscordant index.
					 *  - for the partner, set their idx_serodiscordant index to -1 (as this was their only HIV+ partner). */
					if ((*n_susceptible_in_serodiscordant_partnership)>1){
						susceptible_in_serodiscordant_partnership[a_partner->idx_serodiscordant] = susceptible_in_serodiscordant_partnership[n_susceptible_in_serodiscordant_partnership[0] - 1];
						(*n_susceptible_in_serodiscordant_partnership)--;
						susceptible_in_serodiscordant_partnership[a_partner->idx_serodiscordant]->idx_serodiscordant = a_partner->idx_serodiscordant;
						a_partner->idx_serodiscordant = -1;
					}
					/* If only one person, do the above apart from swapping (in this case set the pointer to NULL). */
					else if ((*n_susceptible_in_serodiscordant_partnership)==1){
						susceptible_in_serodiscordant_partnership[a_partner->idx_serodiscordant] = NULL;
						(*n_susceptible_in_serodiscordant_partnership)--;			
						a_partner->idx_serodiscordant = -1;
					}
					/* In either case their only seropositive partner has just died: */
					a_partner->n_HIVpos_partners = 0;
				}
				/* Otherwise the partner is still in at least one serodiscordant partnership, so just need to reduce the number of seropositive partners by 1: */
				else{
					/* Firstly we need to find where in that list is the dead person. */

					////////////////////////////////////////////////////////////
					////// I AM COMMENTING THIS OUT AS I THINK THIS IS WRONG ////
					//					i=0;
					//					do{
					//						i++;
					//					} while ((a_partner->partner_pairs_HIVpos[i]->ptr[dead_person->gender])!=dead_person);
					////////////////////////////////////////////////////////////////
					///// SHOULD BE INSTEAD (I THINK) ////
					i=0;
					while ((a_partner->partner_pairs_HIVpos[i]->ptr[dead_person->gender])!=dead_person){
						i++;
					}
					////////////////////////////////////////////////////////////////

					if(PRINT_DEBUG_DEMOGRAPHICS==1) printf("CHECKME: %li %li\n", a_partner->partner_pairs_HIVpos[i]->ptr[dead_person->gender]->id,dead_person->id);
					/* Now swap out that partner (as they are dead) */
					a_partner->partner_pairs_HIVpos[i] = a_partner->partner_pairs_HIVpos[a_partner->n_HIVpos_partners-1];
					/* Finally reduce number of seropositive partners by 1: */
					(a_partner->n_HIVpos_partners)--;
				}
			}
		}
	}
	/* If dead person is seronegative and in serodiscordant partnership and there is at least one other person in the same situation, swap the last person with the dead person in this list: */
	/* Provided there is more than one HIV- in any serodiscordant partnership, do the following:
	 *  - swap out that person for the last person in the list.
	 *  - reduce the number of people in the list by 1.
	 *  - for the last person in the list, change their idx_serodiscordant index. */

	/* Otherwise the dead person is seronegative. In this case we only have to worry if the dead person 
	 * has seropositive partners, in which case they are in susceptible_in_serodiscordant_partnership[] 
	 * which needs updating. */ 
	else if (dead_person->idx_serodiscordant!=-1){
		if(dead_person->id==FOLLOW_INDIVIDUAL)
			{
				printf("Individual %ld is dying- removing their serodiscordant neg partners\n",dead_person->id);
				fflush(stdout);
			}
		if ((*n_susceptible_in_serodiscordant_partnership)>1){
			susceptible_in_serodiscordant_partnership[dead_person->idx_serodiscordant] = susceptible_in_serodiscordant_partnership[n_susceptible_in_serodiscordant_partnership[0] - 1];
			(*n_susceptible_in_serodiscordant_partnership)--;
			susceptible_in_serodiscordant_partnership[dead_person->idx_serodiscordant]->idx_serodiscordant = dead_person->idx_serodiscordant;
		}
		/* If only one person, do the above apart from swapping (in this case set the pointer to NULL). */
		else if ((*n_susceptible_in_serodiscordant_partnership)==1){
			susceptible_in_serodiscordant_partnership[dead_person->idx_serodiscordant] = NULL;
			(*n_susceptible_in_serodiscordant_partnership)--;
		}
	}
}

/* Function arguments: pointer to the person who died.
 * Function does: removes a dead person from the list of pop_available_partners
 * and n_pop_available_partners structs.
 * Function returns: nothing. */
void remove_dead_person_from_list_available_partners(double time_death, individual *dead_person, population_partners *pop_available_partners, population_size *n_pop_available_partners){
	int n, g, ag, r, j;

	ag = get_age_group(dead_person->DoB,time_death);
	r = dead_person->sex_risk;
	g = dead_person->gender;

	if(dead_person->id==FOLLOW_INDIVIDUAL)
	{
		printf("Individual %ld is dying at time %lg - removing available partners\n",dead_person->id,time_death);
		fflush(stdout);
	}


	///// Debugging:
	//printf("Details to debug: %i %i %i, %li \n",g,ag,r,n_pop_available_partners->pop_size_per_gender_age_risk[g][ag][r] - 1);
	//printf("remove_dead_person_from_list_available_partners: %li\n",n_pop_available_partners->pop_size_per_gender_age_risk[0][6][2]);
	///fflush(stdout);
	//printf("People: %li",n_pop_available_partners->pop_size_per_gender_age_risk[0][1][0]);
	//for (n=0; n<n_pop_available_partners->pop_size_per_gender_age_risk[0][6][2];n++){
	//	printf("%8li ",pop_available_partners->pop_per_gender_age_risk[0][6][2][n]->id);
	//}
	//printf("\n");
	//fflush(stdout);

	//printf(" %li\n",pop_available_partners->pop_per_gender_age_risk[g][ag][r][n_pop_available_partners->pop_size_per_gender_age_risk[g][ag][r] - 1]->id);
	////	

	for (n=dead_person->n_partners; n<dead_person->max_n_partners; n++)
	{
		//printf("Hey %i %li\n",dead_person->idx_available_partner[n-dead_person->n_partners],n_pop_available_partners->pop_size_per_gender_age_risk[g][ag][r] - 1);
		if(dead_person->idx_available_partner[n-dead_person->n_partners]<n_pop_available_partners->pop_size_per_gender_age_risk[g][ag][r] - 1)
		{
			pop_available_partners->pop_per_gender_age_risk[g][ag][r][dead_person->idx_available_partner[n-dead_person->n_partners]] = pop_available_partners->pop_per_gender_age_risk[g][ag][r][n_pop_available_partners->pop_size_per_gender_age_risk[g][ag][r] - 1]; /* pointing to the last person instead of the current one */
			j = pop_available_partners->pop_per_gender_age_risk[g][ag][r][dead_person->idx_available_partner[n-dead_person->n_partners]]->max_n_partners - pop_available_partners->pop_per_gender_age_risk[g][ag][r][dead_person->idx_available_partner[n-dead_person->n_partners]]->n_partners - 1;
			while(pop_available_partners->pop_per_gender_age_risk[g][ag][r][dead_person->idx_available_partner[n-dead_person->n_partners]]->idx_available_partner[j] != n_pop_available_partners->pop_size_per_gender_age_risk[g][ag][r] - 1)
			{
				j--;
			}
			pop_available_partners->pop_per_gender_age_risk[g][ag][r][dead_person->idx_available_partner[n-dead_person->n_partners]]->idx_available_partner[j] = dead_person->idx_available_partner[n-dead_person->n_partners]; /* telling the person that has moved that they have. */
			/* switch idx_available partners of dead_person to -1 */
			//// This can probably be ignored but probably easier to identify issues etc. if it is done.
			dead_person->idx_available_partner[n-dead_person->n_partners] = -1;
		}
		n_pop_available_partners->pop_size_per_gender_age_risk[g][ag][r]--; /* decreasing the number of available females in that group by 1 */
	}
}

/* Function arguments: pointer to the person who died, the list of available partners (and the numbers of available partners) plus current time t.
 * Function does: removes the partnerships of people who have died (including serodiscordant partnerships), 
 * and add their partners back to "list of available partners".
 * NOTE: This function can be used for either death from natural causes or HIV-related death 
 * (or indeed anything that removes an individual from all partnerships such as permanent migration if this is ever implemented).
 * Function returns: nothing. */ 		
void remove_dead_persons_partners(individual *dead_person, population_partners *pop_available_partners, 
		population_size *n_pop_available_partners, double t){

	int i,j,ag;
	/* All of these pointers will point to existing memory so no calls to malloc needed - they are there to make code readable. */
	long *n_ptr;
	individual *a_partner;
	partnership *a_partnership_ptr;
	
	if ( (PRINT_DEBUG_DEMOGRAPHICS==1) || (dead_person->id==FOLLOW_INDIVIDUAL) ){
		if (dead_person->HIV_status>UNINFECTED)
			printf("Person %li is HIV+ with%i partnerships\n",dead_person->id,dead_person->n_partners);
		else
			printf("Person %li is HIV- with %i serodiscordant partnerships and %i partnerships\n",dead_person->id,dead_person->n_HIVpos_partners,dead_person->n_partners);
		if (dead_person->n_HIVpos_partners>dead_person->n_partners)
			printf("AAG\n");
		fflush(stdout);
	}

	/* For this we have to loop through all partnerships and serodiscordant partnerships. 
	 * It is probably quicker to loop through them separately than to go through partnerships and then check if it is serodiscordant. */ 

	/**********************************/
	/* Loop through all partnerships: */
	/**********************************/
	for (i=0;i<dead_person->n_partners;i++){
		/* Pointer to the partnership: */
		a_partnership_ptr = dead_person->partner_pairs[i];
		/* This is a pointer to the partner: */
		a_partner = a_partnership_ptr->ptr[1-dead_person->gender];
		//printf("Removing partner %li of dead person %li HIV %i %i\n",a_partner->id,dead_person->id,dead_person->HIV_status,a_partner->HIV_status);
		if (PRINT_DEBUG_DEMOGRAPHICS)
			printf("Removing partner %li of dead person %li\n",a_partner->id,dead_person->id);
		j=0;

		// For debugging:
		if (a_partner->n_partners <=0 ){
			printf("Error - partner has no partnerships!?\n");
			exit(1);
		}

		while ((j<a_partner->n_partners) && ((a_partner->partner_pairs[j])!=a_partnership_ptr))
			j++;
		// For debugging:
		if (j>=a_partner->n_partners){
			printf("Error - partnership not found\n");
			exit(1);
		}

		/* Move the last (ie n_partners-1) partnership to the jth partnership - note if j=n_partners-1 this does nothing but that's OK. */
		a_partner->partner_pairs[j] = a_partner->partner_pairs[a_partner->n_partners-1];
		/* Now reduce partnerships by 1. */
		a_partner->n_partners--;	
		/* Get the age group of this partner: */
		ag = get_age_group(a_partner->DoB,t);


		/* This is just a shorthand way to write. I create a pointer to the correct place (ie this is a reference so no need to malloc)
		 *  - so that we can change the contents of the original place in the n_pop_available_partners struct. */ 
		n_ptr = &n_pop_available_partners->pop_size_per_gender_age_risk[a_partner->gender][ag][a_partner->sex_risk];
		/* Add this partner to the correct place in the pool of available partners. */
		pop_available_partners->pop_per_gender_age_risk[a_partner->gender][ag][a_partner->sex_risk][*n_ptr] = a_partner;
		a_partner->idx_available_partner[a_partner->max_n_partners - a_partner->n_partners - 1] = *n_ptr;
		(*n_ptr)++;

	}

}

/* Removes someone from the hiv_pos_progression arrays. Note that normally this only happens for dead people.
 * However the same code is used when someone successfully starts ART, so have renamed to remove "dead_person". */
void remove_from_hiv_pos_progression(individual *indiv, individual ***hiv_pos_progression, long *n_hiv_pos_progression, long *size_hiv_pos_progression, double t, parameters *param){
	if(indiv->id==FOLLOW_INDIVIDUAL){
		printf("Removing individual %ld from HIV pos progression (probably due to death) at time %lg\n",indiv->id,t);
		fflush(stdout);
	}
	int array_index_for_hiv_event = (int) round((t-param->start_time_hiv)*N_TIME_STEP_PER_YEAR); /* index for current time in this array: hiv_pos_progression, only used for debugging */
	
	long i = indiv->idx_hiv_pos_progression[0]; /* index for hiv_pos_progression where the next hiv event for this individual is planned for */
	
	/* If no current event scheduled then stop: */
	if (i==NOEVENT){
		if(indiv->id==FOLLOW_INDIVIDUAL){
			printf("Apparently nothing to remove for %li from hiv_pos_progression %li %li \n",indiv->id,indiv->idx_hiv_pos_progression[0],indiv->idx_hiv_pos_progression[1]);
			fflush(stdout);
		}	

		return;
	}
	
	/* Within simul.c deaths_natural_causes() is called before we carry out HIV events at each timestep, so remove all people who are in the current timestep or later. Note that we need to check if anyone has an HIV event scheduled which occurred BEFORE the current time. */
	if (i>=array_index_for_hiv_event){
		/* We want to swap out the last person in the array hiv_pos_progression[i] for the indiv. */
		individual *person_to_move;
		person_to_move = hiv_pos_progression[i][n_hiv_pos_progression[i]-1];
		if(indiv->id==FOLLOW_INDIVIDUAL){
			printf("Swapping %li out from HIV pos progression with %li n_hiv_pos_progression[%li]=%li\n",indiv->id,person_to_move->id,i,n_hiv_pos_progression[i]);
			fflush(stdout);
		}	

		/* Now replace the indiv with the person_to_move in hiv_pos_progression: */ 
		hiv_pos_progression[i][indiv->idx_hiv_pos_progression[1]] = person_to_move;
		/* Update the details of person_to_move (note idx_hiv_pos_progression[0] remains the same): */
		person_to_move->idx_hiv_pos_progression[1] = indiv->idx_hiv_pos_progression[1];
		/* We have removed one person: */
		n_hiv_pos_progression[i]--;

	}
	/* for DEBUGGING: */
	else{
		printf("ERROR: ****Person %ld died, trying unsuccessfully to remove HIV event from past %ld %i\n",indiv->id,i,array_index_for_hiv_event);
		fflush(stdout);
	}
}



void remove_from_cascade_events(individual *indiv, individual ***cascade_events, long *n_cascade_events, long *size_cascade_events, double t, parameters *param){
	
	/* Don't need to do anything before start of HIV testing. Use this format so never have problems with index. */
	if (t<param->COUNTRY_HIV_TEST_START)
		return;
	if(indiv->id==FOLLOW_INDIVIDUAL){
		printf("Individual %ld at time %lg - removing from cascade events\n",indiv->id,t);
		fflush(stdout);
	}
	//printf("Individual %ld at time %lg - removing from cascade events\n",indiv->id,t);
	
	//printf("Removing %li remove_from_cascade_events\n",indiv->id);
	int array_index_for_cascade_event =  (int) (round((t - param->COUNTRY_HIV_TEST_START) * N_TIME_STEP_PER_YEAR));
	long i = indiv->idx_cascade_event[0];
	
	/* If no current event scheduled then stop: */
	if (i==NOEVENT){
		return;
	}
	
	
	
	/* Within simul.c deaths_natural_causes() is called before we carry out cascade events at each timestep, so 
	 * remove all people who are in the current timestep or later. Note that we need to check if anyone has 
	 * a cascade event scheduled which occurred BEFORE the current time. */
	if (i>=array_index_for_cascade_event){
		/* We want to swap out the last person in the array cascade_events[i] for the indiv. */
		individual *person_to_move;
 
		person_to_move = cascade_events[i][n_cascade_events[i]-1];
		
		/* Now replace the indiv with the person_to_move in cascade_events: */ 
	
		cascade_events[i][indiv->idx_cascade_event[1]] = person_to_move;
		/* Update the details of person_to_move (note idx_cascade_event[0] remains the same): */
		person_to_move->idx_cascade_event[1] = indiv->idx_cascade_event[1];
		/* We have removed one person: */
		n_cascade_events[i]--;
		
	}
	/* for DEBUGGING: */
	else{
		printf("ERROR: ****Person %ld at t=%f cd4=%i, trying unsuccessfully to remove cascade event from past %ld %i\n",indiv->id,t,indiv->cd4,i,array_index_for_cascade_event);
		fflush(stdout);
	}
}


/* Function checks if we need to remove indiv from the list of scheduled VMMC events vmmc_events[] and 
 * removes them if necessary. */
void remove_from_vmmc_events(individual *indiv, individual ***vmmc_events, long *n_vmmc_events, long *size_vmmc_events, double t, parameters *param){
	
	/* Don't need to do anything if before start of VMMC.  */
	if (t<param->COUNTRY_VMMC_START)
		return;

	if (indiv->id==FOLLOW_INDIVIDUAL){
		printf("Individual %li is in remove_from_vmmc_events\n",indiv->id);
	}

	long i = indiv->idx_vmmc_event[0]; 
	
	/* If not currently scheduled for any VMMC events then return. */
	if (i==NOEVENT)
		return;

	
	if(indiv->id==FOLLOW_INDIVIDUAL){
		printf("Individual %ld at time %lg - removing from VMMC events\n",indiv->id,t);
		fflush(stdout);
	}
		
	/* We want to swap out the last person in the array vmmc_events[i] for the indiv. */
	individual *person_to_move;
	person_to_move = vmmc_events[i][n_vmmc_events[i]-1];
		
	if (person_to_move->id==FOLLOW_INDIVIDUAL){
		printf("Individual %li is person_to_move in remove_from_vmmc_events\n",person_to_move->id);
	}
	
	/* Now replace the indiv with the person_to_move in vmmc_events[]: */ 
	vmmc_events[i][indiv->idx_vmmc_event[1]] = person_to_move;
	
	/* Update the details of person_to_move (note idx_vmmc_event[0] remains the same): */
	person_to_move->idx_vmmc_event[1] = indiv->idx_vmmc_event[1];
	
	/* We have removed one person: */
	n_vmmc_events[i]--;	
	
}








/* 
 * Routine where people die in each age group from natural causes from natural_death_rate(), then picks the 
 * individuals in each age group, and calls a subfunction to delete each individual (including sorting out 
 * partnerships and lists which the individual belonged to). */  
void deaths_natural_causes(age_list_struct *age_list, individual *individual_population, 
		population_size *n_population,  population_size_one_year_age *n_infected, 
		stratified_population_size *n_population_stratified, double t, parameters *param, long *new_deaths, 
		long *death_dummylist, individual **susceptible_in_serodiscordant_partnership, 
		long *n_susceptible_in_serodiscordant_partnership, population_partners *pop_available_partners, 
		population_size *n_pop_available_partners, individual ***hiv_pos_progression, long *n_hiv_pos_progression, long *size_hiv_pos_progression,
		individual ***cascade_events, long *n_cascade_events, long *size_cascade_events, 
		individual ***vmmc_events, long *n_vmmc_events, long *size_vmmc_events){
	int aa, ai, n_death_per_timestep;
	double p_death_per_timestep;
	int i;
	int achecktemp;
	
	/* Note that we deal with deaths aged MAX_AGE separately - it is a separate array in age_list */
	for (aa=0; aa<(MAX_AGE-AGE_ADULT); aa++){
		//// FOR DEBUGGING ////
		//printf("aa = %d ; n_susceptible_in_serodiscordant_partnership = %ld\n",aa,n_susceptible_in_serodiscordant_partnership[0]);
		//fflush(stdout);
		ai = age_list->youngest_age_group_index + aa; /* ai is the index of the array age_list->number_per_age_group of the age group of people you want to be dead */
		if (ai>(MAX_AGE-AGE_ADULT-1))
			ai = ai - (MAX_AGE-AGE_ADULT);
		
		if (PRINT_DEBUG_DEMOGRAPHICS){
			if (age_list->number_per_age_group[ai]>0)
				printf("Number of people[%i] age %i = %li. DoB of first person is = %f\n",ai,aa+AGE_ADULT,age_list->number_per_age_group[ai],age_list->age_group[ai][0]->DoB);
			else
				printf("Number of people[%i] age %i = %li.\n",ai,aa+AGE_ADULT,age_list->number_per_age_group[ai]);
		}

		
		p_death_per_timestep = natural_death_rate(aa+AGE_ADULT, t, param) * TIME_STEP;

		///// This was checked against calculations from Excel file (and validated):
		////printf("For age %i at time %f death rate per timestep = %f %f\n",age+AGE_ADULT,t,p_death_per_timestep,natural_death_rate(age+AGE_ADULT, t, param));
		/* This is the number of people in age group a who die per timestep. */
		n_death_per_timestep =  gsl_ran_binomial (rng, p_death_per_timestep, age_list->number_per_age_group[ai]);
		
		if (PRINT_DEBUG_DEMOGRAPHICS)
			printf("1:Number of people age %i = %li. Number dying = %i\n",aa+AGE_ADULT,age_list->number_per_age_group[ai],n_death_per_timestep);
		if (n_death_per_timestep>0){
			gsl_ran_choose (rng, new_deaths, n_death_per_timestep, death_dummylist, age_list->number_per_age_group[ai], sizeof (long));

			/* If ageing is switched off then we can accumulate too many individuals in youngest age groups (as they don't die, they just accumulate). */
			//// For DEBUGGING:
			if (n_death_per_timestep>age_list->number_per_age_group[ai]){
				printf("Too many people in age group aa = %i: Number = %li\n",ai,age_list->number_per_age_group[ai]);
				printf("Is ageing switched off");
				exit(1);
			}
			
			for (i=n_death_per_timestep-1; i>=0; i--){
				//// TO ADD:
				//// Remove this individual from individual_population?? - note this isn't easy.
				//printf("HERE a %li %i %i %i %i\n",new_deaths[i],age+AGE_ADULT,a,FIND_AGE_GROUPS[age],age_list->number_per_age_group[a]);
				//printf("HERE b %li %i %i %i %f %i\n",new_deaths[i],age,a,FIND_AGE_GROUPS[age],age_list->age_group[a][1]->DoB,age_list->age_group[a][1]->gender);
				
				
				/* Now call a function to remove people who have died and to update their partnerships. */
				achecktemp = get_age_index(age_list->age_group[ai][(int) new_deaths[i]]->DoB, param-> start_time_simul);
				if (ai!=achecktemp){
					printf("AAG %i %i t=%6.4f DoB=%6.4f age = %6.4f id=%li\n",ai,achecktemp,t,age_list->age_group[ai][(int) new_deaths[i]]->DoB,t-age_list->age_group[ai][(int) new_deaths[i]]->DoB,age_list->age_group[ai][(int) new_deaths[i]]->id);
					exit(1);
				}
				
				//if (age_list->age_group[ai][(int) new_deaths[i]]->id==FOLLOW_INDIVIDUAL)
				//	printf("Killing %i from natural causes at time %f\n\n",FOLLOW_INDIVIDUAL,t);
				remove_dead_person_from_susceptible_in_serodiscordant_partnership(age_list->age_group[ai][(int) new_deaths[i]], susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership);
				
				remove_dead_person_from_list_available_partners(t, age_list->age_group[ai][(int) new_deaths[i]], pop_available_partners,n_pop_available_partners);
				
				remove_dead_persons_partners(age_list->age_group[ai][(int) new_deaths[i]], pop_available_partners, n_pop_available_partners, t);
				
				if (age_list->age_group[ai][(int) new_deaths[i]]->HIV_status>UNINFECTED){
					remove_from_hiv_pos_progression(age_list->age_group[ai][(int) new_deaths[i]], hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression,t, param);
					DEBUG_NHIVDEAD++;
					
				}
				if (PRINT_DEBUG_DEMOGRAPHICS==1)
					printf("Calling deaths_natural_causes() with %i partners\n",age_list->age_group[ai][(int) new_deaths[i]]->n_partners);

				
				remove_from_cascade_events(age_list->age_group[ai][(int) new_deaths[i]], cascade_events, n_cascade_events, size_cascade_events,t, param);				

				if ((age_list->age_group[ai][(int) new_deaths[i]])->gender==MALE)
					remove_from_vmmc_events(age_list->age_group[ai][(int) new_deaths[i]], vmmc_events, n_vmmc_events, size_vmmc_events, t, param);

				
				/* Now update the n_population, n_infected and n_population_stratified counts. */
				update_population_size_death(age_list->age_group[ai][(int) new_deaths[i]], n_population, n_infected, n_population_stratified, aa, age_list); /* Updates population counts. */
				
				//////// For DEBUGGING:
				(age_list->age_group[ai][(int) new_deaths[i]])->cd4 = DEAD;
				(age_list->age_group[ai][(int) new_deaths[i]])->DoD = t;
				//(age_list->age_group[a][new_deaths[i]])->DoB = -1;
				
				update_age_list_death(age_list, ai, (int) new_deaths[i], t);

			}
			
		}
	}

	/******************** Now deal with oldest people: ********************/
	
	p_death_per_timestep = natural_death_rate(MAX_AGE, t, param) * TIME_STEP;
	/* This is the number of people age >=MAX_AGE who die per timestep. */
	n_death_per_timestep =  gsl_ran_binomial (rng, p_death_per_timestep, age_list->number_oldest_age_group);

	if (PRINT_DEBUG_DEMOGRAPHICS)
		printf("2:Number of people age %i = %i. Number dying = %i\n",MAX_AGE,age_list->number_oldest_age_group,n_death_per_timestep);
	if (n_death_per_timestep>0){

		gsl_ran_choose (rng, new_deaths, n_death_per_timestep, death_dummylist, age_list->number_oldest_age_group, sizeof (long));
		//?gsl_ran_choose (rng, new_deaths, n_death_per_timestep, death_dummylist, age_list->number_oldest_age_group, sizeof (double));

		///// FOR DEBUGGING: To check we are pointing at the correct thing.
		if (PRINT_DEBUG_DEMOGRAPHICS)
			printf("DoB of first adult age %i adults to be killed = %f\n",MAX_AGE,(age_list->oldest_age_group[(int) new_deaths[0]])->DoB);
	}


	/* Do we bother to update their partnerships? YES!!! */

	for (i=n_death_per_timestep-1; i>=0; i--){

		//printf("ID = %li Gender = %i %i %i %f\n",(age_list->oldest_age_group[(int) new_deaths[i]])->id,(age_list->oldest_age_group[(int) new_deaths[i]])->gender,MAX_AGE,N_AGE-1,t-(age_list->oldest_age_group[(int) new_deaths[i]])->DoB);
		if (PRINT_DEBUG_DEMOGRAPHICS)
			printf("ID = %li Gender = %i %i %i %f\n",(age_list->oldest_age_group[new_deaths[i]])->id,(age_list->oldest_age_group[new_deaths[i]])->gender,MAX_AGE,N_AGE-1,t-(age_list->oldest_age_group[new_deaths[i]])->DoB);

		/* Now call a function to remove people who have died and to update their partnerships. */
		//if (age_list->oldest_age_group[(int) new_deaths[i]]->id==FOLLOW_INDIVIDUAL)
		//	printf("Killing %i from natural causes old at time %f\n. \n",FOLLOW_INDIVIDUAL,t);
		remove_dead_person_from_susceptible_in_serodiscordant_partnership(age_list->oldest_age_group[(int) new_deaths[i]], susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership);
		remove_dead_person_from_list_available_partners(t, age_list->oldest_age_group[(int) new_deaths[i]], pop_available_partners,n_pop_available_partners);
		remove_dead_persons_partners(age_list->oldest_age_group[(int) new_deaths[i]], pop_available_partners, n_pop_available_partners, t);

		if (age_list->oldest_age_group[(int) new_deaths[i]]->HIV_status>UNINFECTED){
			remove_from_hiv_pos_progression(age_list->oldest_age_group[(int) new_deaths[i]], hiv_pos_progression, n_hiv_pos_progression, size_hiv_pos_progression, t, param);
			DEBUG_NHIVDEAD++;
		}

		remove_from_cascade_events(age_list->oldest_age_group[(int) new_deaths[i]], cascade_events, n_cascade_events, size_cascade_events,t, param);
		
		if ((age_list->oldest_age_group[(int) new_deaths[i]])->gender==MALE)
			remove_from_vmmc_events(age_list->oldest_age_group[(int) new_deaths[i]], vmmc_events, n_vmmc_events, size_vmmc_events, t, param);
		
		update_population_size_death(age_list->oldest_age_group[(int) new_deaths[i]], n_population, n_infected, n_population_stratified, MAX_AGE-AGE_ADULT, age_list); /* Updates population counts. */

		(age_list->oldest_age_group[(int) new_deaths[i]])->cd4 = DEAD;
		(age_list->oldest_age_group[(int) new_deaths[i]])->DoD = t;
		update_age_list_death(age_list, MAX_AGE-AGE_ADULT, (int) new_deaths[i], t);


	}

}



/* Function does: Deals with transition to adulthood of children from child_population at each timestep. 
 * Children are assigned by hivstatus, but other characteristics (gender, risk, etc) assigned by create_new_individual() function.
 * Function arguments: pointers to child_population, the individual population, size of the population, age_list, params. Current time t.
 * Function returns: nothing. */
void make_new_adults(child_population_struct *child_population, individual *individual_population, 
		population_size *n_population, stratified_population_size *n_population_stratified, 
		age_list_struct *age_list, double t, parameters *param, 
		population_partners *pop_available_partners, population_size *n_pop_available_partners, 
		population_size_one_year_age *n_infected, individual ***cascade_events, long *n_cascade_events, long *size_cascade_events){
	int hivstatus;
	if (PRINT_DEBUG_DEMOGRAPHICS)
		printf("Number of new HIV- (and HIV+) kids = %i %i\n",*(child_population[0].transition_to_adult_index_n_child),*(child_population[1].transition_to_adult_index_n_child));

	////// Add HIV+ kids:
	/* Add all the kids for this  timestep: */
	for (hivstatus=0;hivstatus<=1;hivstatus++){
		while (*(child_population[hivstatus].transition_to_adult_index_n_child)>0){
			/* This adds an individual (HIV-) to individual_population: */
			////// DEBUG ERROR - this 
			// WRONG version: create_new_individual((individual_population+(n_population->total_pop_size)), t, param);
			/// Right version:

			create_new_individual((individual_population+id_counter), t, param, hivstatus, pop_available_partners, n_pop_available_partners, n_infected);
			if (t>=param->COUNTRY_HIV_TEST_START)
				initialize_first_cascade_event_for_new_individual((individual_population+id_counter), t, param, cascade_events, n_cascade_events, size_cascade_events);
			id_counter++;


			/* This updates the n_population variable which counts number of people: */
			update_population_size_new_adult((individual_population+id_counter-1), n_population, n_population_stratified);

			update_age_list_new_adult(age_list,(individual_population+id_counter-1));

			if (PRINT_DEBUG_DEMOGRAPHICS)
				printf("NEWID = %li Number of new kids left = %i, total pop = %li GENDER = %i\n",id_counter,*(child_population[hivstatus].transition_to_adult_index_n_child),n_population_stratified->total_pop_size,(individual_population+id_counter-1)->gender);
			/* Have added a kid, so reduce the number we need to add by 1: */
			(*(child_population[hivstatus].transition_to_adult_index_n_child))--;
		}
		/* Note that the while loop set the number of kids in this slot to zero - this slot will now be used to store newborn kids. */

		/* Now we have added all the kids from this timestep, move the pointer to the place in the array for kids to add at the next time step. */
		if ((child_population[hivstatus].transition_to_adult_index_n_child)>&(child_population[hivstatus].n_child[0]))
			(child_population[hivstatus].transition_to_adult_index_n_child)--;
		else{
			child_population[hivstatus].transition_to_adult_index_n_child = &(child_population[hivstatus].n_child[AGE_ADULT*N_TIME_STEP_PER_YEAR-1]);

		}
	}
}


/* Function does: This is a DUMMY function to add newly born babies to the child_population structures so 
 * that there are always new individuals to reach adulthood as time goes on. The function has stochasticity 
 * so slight variation in number of births per timestep.  
 * NOTE: THIS FUNCTION CURRENTLY FORCES 10% OF CHILDREN TO BE HIV+.
 * Function arguments: pointers to child_population, the size of the population (to calculate the number 
 * of children to be born), params. 
 * Function returns: nothing. */
void add_new_kids(child_population_struct *child_population, population_size *n_population, 
		stratified_population_size *n_population_stratified, parameters *param, double t, int country_setting){
	int ag;     /* index for age groups. */
	int n_births;
	double total_population_fertility_rate = 0.0;
	/* Here we calculate the average per-woman fertility rate per timestep. Note that we ignore fertility in 65+ year olds! */

	for (ag=0; ag< (N_AGE-2); ag++)
		total_population_fertility_rate += per_woman_fertility_rate((AGE_GROUPS[ag]+AGE_GROUPS[ag+1])/2.0, param, t, country_setting) * n_population_stratified->pop_size_per_gender_age[FEMALE][ag];

	/* Now normalize to per-capita female population rate per timestep. */ 
	total_population_fertility_rate *= (TIME_STEP /n_population_stratified->total_pop_size_per_gender[FEMALE]);



	n_births = gsl_ran_binomial (rng, total_population_fertility_rate, n_population_stratified->total_pop_size_per_gender[FEMALE]);



	if (PRINT_DEBUG_DEMOGRAPHICS){
		if ((child_population[0].transition_to_adult_index_n_child)<&(child_population[0].n_child[AGE_ADULT*N_TIME_STEP_PER_YEAR-1]))
			printf("BIRTHSx were: %i %i are: %i %i\n",*((child_population[0].transition_to_adult_index_n_child)+1),*(child_population[1].transition_to_adult_index_n_child+1),(int) floor(n_births*1.0),(int) floor(n_births*0.0));
		else
			printf("BIRTHSy were: %i %i are: %i %i\n",child_population[0].n_child[0],child_population[1].n_child[0],(int) floor(n_births*1.0),(int) floor(n_births*0.0));
	}

	// This is a debugging routine - assume that 10% of children are HIV+ at this point. 
	if ((child_population[0].transition_to_adult_index_n_child)<(&(child_population[0].n_child[AGE_ADULT*N_TIME_STEP_PER_YEAR-1])))
		*(child_population[0].transition_to_adult_index_n_child+1) = (int) floor(n_births*1.0);
	else
		(child_population[0].n_child[0]) = (int) floor(n_births*1.0);


	if ((child_population[1].transition_to_adult_index_n_child)<(&(child_population[1].n_child[AGE_ADULT*N_TIME_STEP_PER_YEAR-1])))
		*(child_population[1].transition_to_adult_index_n_child+1) = (int) floor(n_births*0.0);
	else
		(child_population[1].n_child[0]) = (int) floor(n_births*0.0);


}


/* Function arguments: pointers to pop, age_list, individual_population structure. 
 * Function does: goes through all the lists in age_list (by year) to get all currently alive individuals 
 * aged AGE_ADULT+ and sort them into the correct component of the pop structure.
 * This function can be used to get pop to seed HIV. 
 * Function returns: nothing. */
void make_pop_from_age_list(population *pop, age_list_struct *age_list, individual *individual_population){
	int aa, ai;
	int g, ag, r;
	long i;

	/* This is a (temporary) store for the index of the array pop for each gender x ag x risk group. 
	 * It is only locally defined - this is fine as long as we only call this routine a few times. 
	 * It is automatically defined - calloc() is not necessary as this is (always) a small array (independent of the 
	 * size of the population) unless we stratify by hundreds of extra things. */
	long n_pop_temp[N_GENDER][N_AGE][N_RISK];
	/* Set array to zero: */
	for (g=0; g<N_GENDER; g++)
		for (ag=0; ag<N_AGE; ag++)
			for (r=0; r<N_RISK; r++)
				n_pop_temp[g][ag][r] = 0;

	/* First loop over all age groups by year: */
	for (aa=0; aa<(MAX_AGE-AGE_ADULT); aa++){ 
		ai = age_list->youngest_age_group_index + aa; /* a is the index of the two arrays age_list->number_per_age_group and age_list->age_group */
		if (ai>(MAX_AGE-AGE_ADULT-1))
			ai = ai - (MAX_AGE-AGE_ADULT);

		/* Now loop over individuals in each year age group: */
		for (i=0; i<age_list->number_per_age_group[ai]; i++){
			g = age_list->age_group[ai][i]->gender;
			ag = FIND_AGE_GROUPS[aa];
			r = age_list->age_group[ai][i]->sex_risk;
			pop->pop_per_gender_age_risk[g][ag][r][n_pop_temp[g][ag][r]] = age_list->age_group[ai][i];
			n_pop_temp[g][ag][r]++;
		}                                                                                                                               
	}

	/* Now for oldest individuals: */
	for (i=0; i<age_list->number_oldest_age_group; i++){
		g = age_list->oldest_age_group[i]->gender;
		ag = N_AGE-1;   /* Oldest age group. */
		r = age_list->oldest_age_group[i]->sex_risk;
		pop->pop_per_gender_age_risk[g][ag][r][n_pop_temp[g][ag][r]] = age_list->oldest_age_group[i];
		n_pop_temp[g][ag][r]++;
	}                            
}




/* 
 * Routine which calls a subfunction to delete an individual dying of AIDS (including sorting out 
 * partnerships and lists which the individual belonged to). 
 * Note they are already dying of AIDS so we don't need to fix hiv_pos_progression.
 * Also note this function does not remove the individual from the cascade_events, this needs to be done separately by calling remove_from_cascade_events */
void individual_death_AIDS(age_list_struct *age_list, individual *dead_person, 
		population_size *n_population,  population_size_one_year_age *n_infected, 
		stratified_population_size *n_population_stratified, double t, parameters *param, 
		individual **susceptible_in_serodiscordant_partnership, 
		long *n_susceptible_in_serodiscordant_partnership, population_partners *pop_available_partners, 
		population_size *n_pop_available_partners, individual ***cascade_events, long *n_cascade_events, long *size_cascade_events){
	int aa, ai, age_list_index;

	if (dead_person->id==FOLLOW_INDIVIDUAL)
		printf("Killing %i by HIV at time %f\n",FOLLOW_INDIVIDUAL,t);
	DEBUG_NHIVDEAD++;
	
	/* Note that we deal with deaths aged MAX_AGE separately - it is a separate array in age_list */
	aa = (int) floor(floor(t) - dead_person->DoB) - AGE_ADULT;
	if (aa<(MAX_AGE-AGE_ADULT)){
		ai = age_list->youngest_age_group_index + aa; /* ai is the index of the array age_list->number_per_age_group of the age group of people you want to be dead */
		if (ai>(MAX_AGE-AGE_ADULT-1))
			ai = ai - (MAX_AGE-AGE_ADULT);
	
		if (PRINT_DEBUG_DEMOGRAPHICS){
			if (age_list->number_per_age_group[ai]>0)
				printf("Number of people[%i] age %i = %li. DoB of dead person is = %f\n",ai,aa+AGE_ADULT,age_list->number_per_age_group[ai],dead_person->DoB);
			else
				printf("Number of people[%i] age %i = %li.\n",ai,aa+AGE_ADULT,age_list->number_per_age_group[ai]);
		}
	
		//// Remove this individual from individual_population?? - note this isn't easy.
		//printf("HERE a %i %i %i %i\n",age+AGE_ADULT,a,FIND_AGE_GROUPS[age],age_list->number_per_age_group[a]);
		//printf("HERE b %i %li %f %i\n",aa,dead_person->id,dead_person->DoB,dead_person->gender);
		
		/* Now call a function to remove people who have died and to update their partnerships. */
		//if (dead_person->id==14127)
		//	printf("***************************************************Killing 14127 from AIDS. \n");
		remove_dead_person_from_susceptible_in_serodiscordant_partnership(dead_person, susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership);
		remove_dead_person_from_list_available_partners(t, dead_person, pop_available_partners,n_pop_available_partners);
		remove_dead_persons_partners(dead_person, pop_available_partners, n_pop_available_partners, t);
		if (PRINT_DEBUG_DEMOGRAPHICS==1)
			printf("Calling deaths_natural_causes() with %i partners\n",dead_person->n_partners);
		
		/* Now update the n_population, n_infected and n_population_stratified counts. */
		update_population_size_death(dead_person, n_population, n_infected, n_population_stratified, aa, age_list); /* Updates population counts. */
	
		//////// For DEBUGGING:
		dead_person->cd4 = DEAD;
		dead_person->DoD = t;
		//dead_person->DoB = -1;
	
		
		age_list_index = 0;
		while ((age_list_index<age_list->number_per_age_group[ai]) && (age_list->age_group[ai][age_list_index]->id!=dead_person->id)){ 
			age_list_index++;
		}
		update_age_list_death(age_list, ai, age_list_index, t);
	}
	/******************** Now deal with oldest people: ********************/
	else{
		/* Do we bother to update their partnerships? YES!!! */
	
		//printf("ID = %li Gender = %i %i %i %f\n",dead_person->id,dead_person->gender,MAX_AGE,N_AGE-1,t-dead_person->DoB);
		if (PRINT_DEBUG_DEMOGRAPHICS)
			printf("ID = %li Gender = %i %i %i %f\n",dead_person->id,dead_person->gender,MAX_AGE,N_AGE-1,t-dead_person->DoB);
	
		/* Now call a function to remove people who have died and to update their partnerships. */
		remove_dead_person_from_susceptible_in_serodiscordant_partnership(dead_person, susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership);
		remove_dead_person_from_list_available_partners(t, dead_person, pop_available_partners,n_pop_available_partners);
		remove_dead_persons_partners(dead_person, pop_available_partners, n_pop_available_partners, t);
		
		// WRONG CODE: the following line is a call which shouldn't be here as we call this function outside individual_death_AIDS, so this is a repeat call.
		// Have had problems with trying to remove the same dead person twice.
		//remove_from_cascade_events(dead_person, cascade_events, n_cascade_events, size_cascade_events,t, param);
		
		update_population_size_death(dead_person, n_population, n_infected, n_population_stratified, MAX_AGE-AGE_ADULT, age_list); /* Updates population counts. */
	
		dead_person->cd4 = DEAD;
		dead_person->DoD = t;
		
		
		age_list_index = 0;
		while ((age_list_index<age_list->number_oldest_age_group) && (age_list->oldest_age_group[age_list_index]->id!=dead_person->id)){ 
			age_list_index++;
		}
		update_age_list_death(age_list, MAX_AGE-AGE_ADULT, age_list_index, t);
	}


}


