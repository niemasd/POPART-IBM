/*  This file is part of the PopART IBM.

    The PopART IBM is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The PopART IBM is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the PopART IBM.  If not, see <http://www.gnu.org/licenses/>.
 */


/* Contains all functions which initialize the population for the PopART model:
 * get_initial_population_distribution() - calculates the % of individuals in each age x risk group for each gender based 
 * initialize_child_population() - sets up the number of children (by timestep) at the start of the simulation - this will give the number of new adults at each timestep.
 * make_DoB() - gives an individual a DoB at the start of the simulation based on assuming that age is uniformly distributed in each age group and drawing a random number.
 * set_max_n_partners() - gives an individual a maximum number of partners at any given time.
 * set_population_count_zero() - initializes all the population counts in the "population" structure to be zero.
 * set_population_count_one_year_zero() - initializes all elements of a population_size_one_year_age struct to be zero. These are counts of prevalent and incident cases.
 * set_population_count_stratified_zero() - initializes n_population_stratified struct to be zero.
 * set_population_count_stratified() - based on the maximally stratified (ie gender/age/risk) population counts, generates other (less stratified e.g. by gender only) population counts needed by certain functions.
 * set_up_population() - sets up the "individual_population" - this is an array of param->initial_population_size "individual" structures - at the start of the simulation
 * init_available_partnerships() - sets up the available partnership lists.
 * init_cumulative_counters() - sets the cumulative counter variables in the struct cumulative_outputs to zero. This is called at the start of the simulation. 
 */


/************************************************************************/
/******************************* Includes  ******************************/
/************************************************************************/

#include "constants.h"
#include "init.h"
#include "demographics.h"


/************************************************************************/
/******************************** functions *****************************/
/************************************************************************/

/* Function does: calculates the proportion of population in each risk group (gender x age x risk) at the start of 
 * the simulation from the initial values in the params_init.txt file and stores it in n_population[][][]. */
void get_initial_population_distribution(population_size *n_population, parameters *param){
	int r, ag;   /* Counters over risk group, age. */
	for (ag = 0; ag < N_AGE; ag++)
		for (r = 0; r < N_RISK; r++){
			n_population->pop_size_per_gender_age_risk[MALE][ag][r] = (long) floor(param->initial_population_size * param->sex_ratio * param->initial_prop_age[ag] * param->initial_prop_gender_risk[MALE][r]);
			n_population->pop_size_per_gender_age_risk[FEMALE][ag][r] = (long) floor(param->initial_population_size * (1.0 - param->sex_ratio) * param->initial_prop_age[ag] * param->initial_prop_gender_risk[FEMALE][r]);
		}
}

/* Function does: Initializes the child_population structure given fertility rate and number of women by age group.
 * Note: child_population is the number of children who are in each per-timestep age group. Thus at each timestep this
 * specifies the number of children reaching adulthood. */
void initialize_child_population(parameters *param, child_population_struct *child_population, 
		stratified_population_size *n_population_stratified, int country_setting){

	int age_dt; /* This is the per-timestep age group of children, with range [0,AGE_ADULT) divided into units of 1 timestep. */
	int ag;     /* index for age groups. */
	int n_births_per_timestep;
	double total_population_fertility_rate = 0.0;

	/* Here we calculate the the per-capita average population-level fertility rate per timestep. 
	 * Note that we ignore fertility in 65+ year olds, so the upper bound is N_AGE-2. 
	 * The first step is to calculate  the annual cumulative population-level fertility rate
	 * (ie per-woman fertility rate per year summed over all women by age group): */
	for (ag=0; ag< (N_AGE-2); ag++)
		total_population_fertility_rate += per_woman_fertility_rate((AGE_GROUPS[ag]+AGE_GROUPS[ag+1])/2.0, param, param->start_time_simul, country_setting) * n_population_stratified->pop_size_per_gender_age[FEMALE][ag];

	/* Now normalize to per-capita female population rate per timestep - so multiply by timestep and divide by number of women: 
	 * NB: add 0.0 to ensure always float (rather than integer) division. */ 
	total_population_fertility_rate *= (TIME_STEP/(n_population_stratified->total_pop_size_per_gender[FEMALE]+0.0));

	/* Draw number of children in each age_dt group using this fertility rate: */
	for (age_dt=0;age_dt<AGE_ADULT*N_TIME_STEP_PER_YEAR;age_dt++){ /* for each unit of age */
		
		n_births_per_timestep = gsl_ran_binomial (rng, total_population_fertility_rate, n_population_stratified->total_pop_size_per_gender[FEMALE]);
		// Here could draw by age group and then choose the mothers at random so that MTCT can be modelled

		/* All children are assumed HIV- at this point as HIV epidemic has not started. */
		child_population[0].n_child[age_dt] = n_births_per_timestep;
		child_population[1].n_child[age_dt] = 0;
	}
	/* These indices points to the oldest age group in each child_population[i] group: */
	child_population[0].transition_to_adult_index_n_child = ((child_population[0].n_child)+AGE_ADULT*N_TIME_STEP_PER_YEAR-1);
	child_population[1].transition_to_adult_index_n_child = ((child_population[1].n_child)+AGE_ADULT*N_TIME_STEP_PER_YEAR-1);
}

///////////// FIX THIS:
///////////// This is a placeholder - set max_n_partners correctly later
/* Function arguments: risk group of individual
 * Function does: This is a placeholder - should return a number of partners based on some data.
 * Function returns: The maximum number of partners that an individual can have in that risk group 
 * (may also depend on age/gender?). */
int set_max_n_partners(int g, int ag, int r, parameters *param){
	return param->max_n_part_noage[r];
}


/* Function arguments: age group of an individual, pointer to "parameter" structure, current time t, 
 * a pointer to age_year which is the age_group that the individual belongs to (we pass as a pointer so 
 * we can change it).
 * Function does: assumes that ages are uniformly distributed between the lower and upper limits of that 
 * age group, assigns an age randomly and then calculates the DoB. The variable age_group is also modified. 
 * Function returns: The DoB of that person. The variable age_group is also modified. */
double make_DoB(int ag, double t, int *aa_ptr){
	double age;
	/* AGE_GROUP[] gives the lower bound of each age group, so need to adapt if in last age group. 
	 * Note that we initialise the population to be 14+ and then add in 13 year-olds over the course of the first year. 
	 * Use function gsl_rng_uniform_pos as this samples on (0,1) and ensures we never have a DoB which is exactly
	 * at the start of any year. */ 
	
	if (ag==0)
		age = (AGE_GROUPS[0]+1) + (AGE_GROUPS[1]-(AGE_GROUPS[0]+1))*gsl_rng_uniform_pos (rng);
	else if (ag<N_AGE-1)
		age = AGE_GROUPS[ag] + (AGE_GROUPS[ag+1]-AGE_GROUPS[ag])*gsl_rng_uniform_pos (rng);
	else
		age = AGE_GROUPS[ag] + (MAX_AGE-AGE_GROUPS[ag])*gsl_rng_uniform_pos (rng);	

	*aa_ptr = (int) (age-AGE_ADULT);

	/* This gives the DoB: */
	return t - age;
}


/* Function arguments: pointer to the "population" structure which contains information about the 
 * number of people in each risk, age and gender group and overall.
 * Function does: Initializes all of these as zero. 
 * Function is used to set n_pop_available_partners to zero. */
void set_population_count_zero(population_size *n_pop){
	int g,ag,r;
	for (ag=0; ag<N_AGE; ag++){
		for (r=0; r<N_RISK; r++){
			for(g=0 ; g<N_GENDER ; g++){
				n_pop->pop_size_per_gender_age_risk[g][ag][r] = 0;
			}
		}
	}
}

/* Function does: Initializes n_population structure (which is number of people by gender x one-year age groups x risk group
 *  to zero and sets youngest_age_group_index as 0. */
void set_population_count_one_year_zero(population_size_one_year_age *n_population){
	int g,aa,r;
	n_population->youngest_age_group_index = 0;

	
	for (r=0; r<N_RISK; r++){
		for(g=0 ; g<N_GENDER ; g++){
			for (aa=0; aa<(MAX_AGE-AGE_ADULT); aa++){
				n_population->pop_size_per_gender_age1_risk[g][aa][r] = 0;
			}
			n_population->pop_size_oldest_age_group_gender_risk[g][r] = 0;
		}
	}
}


void set_population_count_stratified_zero(stratified_population_size *n_population_stratified){
	int g,ag,r;
	for (ag=0; ag<N_AGE; ag++){
		//n_population_stratified->pop_size_per_age[ag] = 0;
		for(g=0 ; g<N_GENDER ; g++){
			n_population_stratified->pop_size_per_gender_age[g][ag] = 0;
		}
		/*for (r=0; r<N_RISK; r++){
			n_population_stratified->pop_size_per_age_risk[ag][r] = 0;
		}*/
	}

	for (r=0; r<N_RISK; r++){
		//n_population_stratified->pop_size_per_risk[r] = 0;
		for(g=0 ; g<N_GENDER ; g++){
			n_population_stratified->pop_size_per_gender_risk[g][r] = 0;
			n_population_stratified->prop_pop_per_gender_risk[g][r] = 0.0;
		}
	}

	n_population_stratified->total_pop_size = 0;
	for(g=0 ; g<N_GENDER ; g++){
		n_population_stratified->total_pop_size_per_gender[g] = 0;
	}
}

void set_population_count_stratified(stratified_population_size *n_population_stratified, 
		population_size *pop){
	int g,ag,r;

	set_population_count_stratified_zero(n_population_stratified);           /* Sets to zero each element in this structure, which stores number of people in the population. */

	for (r=0; r<N_RISK; r++){
		for (ag=0; ag<N_AGE; ag++){
			for(g=0 ; g<N_GENDER ; g++)
			{
				n_population_stratified->pop_size_per_gender_age[g][ag] += pop->pop_size_per_gender_age_risk[g][ag][r];
				n_population_stratified->pop_size_per_gender_risk[g][r] += pop->pop_size_per_gender_age_risk[g][ag][r];
				n_population_stratified->total_pop_size_per_gender[g] += pop->pop_size_per_gender_age_risk[g][ag][r];
				//n_population_stratified->pop_size_per_age[ag] += pop->pop_size_per_gender_age_risk[g][ag][r];
				//n_population_stratified->pop_size_per_age_risk[ag][r] += pop->pop_size_per_gender_age_risk[g][ag][r];
				//n_population_stratified->pop_size_per_risk[r] += pop->pop_size_per_gender_age_risk[g][ag][r];
				n_population_stratified->total_pop_size += pop->pop_size_per_gender_age_risk[g][ag][r];
			}
		}
	}

	for (r=0; r<N_RISK; r++){
		for(g=0 ; g<N_GENDER ; g++)
		{
			/* Multiply denominator by 1.0 to make it a float (C will do integer division if both numerator and denominator are int). */
			n_population_stratified->prop_pop_per_gender_risk[g][r] = n_population_stratified->pop_size_per_gender_risk[g][r]/(1.0*n_population_stratified->total_pop_size_per_gender[g]);

		}
	}
}



/* Function arguments: pointer to the "population" structure which contains information about the number of 
 * people in each risk, age and gender group and overall; pointer to the "individual_population" array of 
 * individuals, pointer to the age-list structure; pointer to the "parameter" structure.
 * Function does: Assigns values to each "individual" structure within the "cluster population" - ie gives 
 * them gender, DoB, riskiness, etc.
 * NOTE: It assigns "-1" to variables such as SPVL and CD4 which will be initialized if the individual 
 * gets HIV, and it sets the numbers of current partners to zero as we initialize partnerships later on. */
void set_up_population(parameters *param,individual *individual_population, population *pop, 
		population_size *n_population, stratified_population_size *n_population_stratified, 
		child_population_struct *child_population,age_list_struct *age_list, 
		population_size_one_year_age *n_infected, population_size_one_year_age *n_newly_infected, int country_setting){

	int i;
	int g, r, ag;
	int aa;
	long i_x;
	
	/* For debugging number of HIV+ people: */
	DEBUG_NHIVPOS = 0;
	DEBUG_NHIVPOSLASTYR = 0;
	DEBUG_NHIVDEAD = 0;

	
	/* For each group we create a template person which has all characteristics in common with everyone in that group.
	 * Specific individual characteristics are then assigned to each person after the template is used first to speed things up. */
	individual person_template;    

	int n_men_circumcised_as_children; /* For each group this is the number of men who are circumcised as children: */

	//// Not currently used as in core model children are created without specific mothers. However this may be needed for MTCT.
	double prop_pregnant_women;        /* For each group this is the proportion of women who are pregnant at the start of the simulation: */
	int n_pregnant_women;              /* For each group this is the number of women who are pregnant at the start of the simulation: */

	/* Work out how many people in each sub-population (age x risk x gender). */
	get_initial_population_distribution(n_population,param);

	set_population_count_stratified(n_population_stratified, n_population);

	set_population_count_one_year_zero(n_infected);
	set_population_count_one_year_zero(n_newly_infected);

	initialize_child_population(param,child_population,n_population_stratified, country_setting);

	id_counter = 0;     /* Initialize this global external variable. */

	/* This is a local counter over gender x age group x risk: */
	int id_counter_per_gender_age_risk[N_GENDER][N_AGE][N_RISK];
	for(g=0 ; g<N_GENDER ; g++){
		for(ag=0 ; ag<N_AGE ; ag++){
			for(r=0 ; r<N_RISK ; r++){
				id_counter_per_gender_age_risk[g][ag][r] = 0;
			}
		}
	}
	
	/* Create a template individual structure to copy. These are the parts which are always in common: */
	person_template.HIV_status = UNINFECTED;
	person_template.ART_status = ARTNEG;
	person_template.t_sc = -1;                   /* Initialize at dummy value. */
	person_template.viral_load = 0;
	person_template.cd4 = CD4_UNINFECTED;        /* Initialize at dummy value. */
	person_template.SPVL = -1;                   /* Initialize at dummy value. */
	person_template.DEBUGTOTALTIMEHIVPOS = 0;
	person_template.next_HIV_event = NOEVENT;         /* Initialize at dummy value. */
	person_template.next_cascade_event = NOEVENT;        /* Initialize at dummy value. */
	person_template.time_last_hiv_test = NEVERHIVTESTED; /* No HIV testing at start of simulation as no HIV. */
	person_template.idx_hiv_pos_progression[0] = -1;     /* Initialize at dummy value. */
	person_template.idx_hiv_pos_progression[1] = -1;     /* Initialize at dummy value. */
	person_template.idx_cascade_event[0] = -1;           /* Initialize at dummy value. */
	person_template.idx_cascade_event[1] = -1;           /* Initialize at dummy value. */
	person_template.time_to_delivery = -1;                /* Not pregnant - allow a % of women to be pregnant later. */
	/* Set up partnerships later on. */
	person_template.n_partners = 0;
	person_template.n_HIVpos_partners = 0;
	person_template.n_partners_outside = 0;
	person_template.n_lifetime_partners = 0;
	person_template.n_lifetimeminusoneyear_partners = 0;
	person_template.idx_serodiscordant = -1;              /* Not in a serodiscordant partnership */
	
	person_template.circ = UNCIRC;                       /* Not circumcised - allow a % of men to be circumcised later. */
	person_template.idx_vmmc_event[0] = NOEVENT;         /* Initialize at dummy value. */
	person_template.idx_vmmc_event[1] = -1;
	for(i=person_template.n_partners ; i<MAX_PARTNERSHIPS_PER_INDIVIDUAL ; i++){
		person_template.idx_available_partner[i] = -1; /* Not yet in the list of available partners */
	}

	person_template.PANGEA_t_prev_cd4stage = -1.0;
	person_template.PANGEA_t_next_cd4stage = -1.0;
	person_template.PANGEA_cd4atdiagnosis = -1.0;
	person_template.PANGEA_cd4atfirstART = -1.0;
	person_template.PANGEA_t_diag = -1.0;
	person_template.PANGEA_date_firstARTstart = -1.0;
	person_template.PANGEA_date_startfirstVLsuppression = -1.0;
	person_template.PANGEA_date_endfirstVLsuppression = -1.0;
	
	
	/* Set this to zero here as we will sum over risk groups r later. */
	for (aa = 0; aa < (MAX_AGE-AGE_ADULT); aa++)
		age_list->number_per_age_group[aa] = 0;
	age_list->number_oldest_age_group = 0;

	/* Now loop over gender x age x risk: */
	for (ag = 0; ag < N_AGE; ag++){
		/* For speed we draw the number of women in each age group who are pregnant. 
		 * First term is to correct the annual rate of pregnancy for the fact that it only lasts 9 months 
		 * - so only 3/4 of the annual fraction are pregnant at the start of the simulation. */
		if (ag<N_AGE-1)
			prop_pregnant_women = (NSTEPS_GESTATION_TIME*TIME_STEP) * per_woman_fertility_rate((AGE_GROUPS[ag]+AGE_GROUPS[ag+1])/2.0, param, param->start_time_simul, country_setting);
		else
			prop_pregnant_women = (NSTEPS_GESTATION_TIME*TIME_STEP) * per_woman_fertility_rate((AGE_GROUPS[ag]+MAX_AGE)/2.0, param, param->start_time_simul, country_setting);


		for (r = 0; r < N_RISK; r++){
			/* Calculate number of men circumcised: (we do it here so we don't need to calculate twice for M/F). */
			n_men_circumcised_as_children = (int) floor((param->p_child_circ)*n_population->pop_size_per_gender_age_risk[MALE][ag][r]);
			n_pregnant_women = prop_pregnant_women * n_population->pop_size_per_gender_age_risk[FEMALE][ag][r];
			for (g = 0; g < N_GENDER; g++){

				/* Set up parts of template which are specific to this age/sex/risk group: */
				person_template.gender = g;
				person_template.sex_risk = r;  /* 0, 1, 2 for LOW, MEDIUM, HIGH risk */
				
				for (i_x = 0; i_x < n_population->pop_size_per_gender_age_risk[g][ag][r]; i_x++){

					/* Copy the template onto the person. Note that "id_counter" is a global variable which is 
					 * initialized at zero. Here we use it as both a counter and as the id number of the people 
					 * we are initializing - later on it is just used for the id number of new people. */
					individual_population[id_counter] = person_template;

					/* Now update the unique parts of this individual (ie the bits which aren't in common): */
					individual_population[id_counter].id = id_counter;

					if (g==MALE){
						/* Circumcise the first n_men_circumcised_as_children men in the group: */
						if (n_men_circumcised_as_children>0){
							individual_population[id_counter].circ = TRADITIONAL_MC;
							n_men_circumcised_as_children--;
						}
					}
					else{
						/* First n_pregnant_women are pregnant in the group. */
						if (n_pregnant_women>0){
							// Again, in core model not using time_to_delivery although keep code to allow MTCT in extended versions of model.
							individual_population[id_counter].time_to_delivery = gsl_rng_uniform_int (rng, NSTEPS_GESTATION_TIME);
							n_pregnant_women--;
						}
					}

					/* We can't assign ages increasing in the group because we already assign circumcision to the first k people in 
					 * the group. So use make_DoB() to assign uniform DoB consistent with age group ag: */					
					
					individual_population[id_counter].DoB = make_DoB(ag, param->start_time_simul, &aa);
					individual_population[id_counter].DoD = -1;
					if (id_counter==FOLLOW_INDIVIDUAL)
						printf("Making individual %li at start of simulation with age group ag=%i aa=%i\n",id_counter,ag,aa);
					
					/* Now add this person to the correct age list, and then increment the number of people in that list by 1: */
					if (aa<MAX_AGE-AGE_ADULT){
						age_list->age_group[aa][age_list->number_per_age_group[aa]] = &individual_population[id_counter];
						age_list->number_per_age_group[aa] += 1;
					}
					else{
						age_list->oldest_age_group[age_list->number_oldest_age_group] = &individual_population[id_counter];
						age_list->number_oldest_age_group += 1;
					}

					/* Draw max number of sexual partners based on gender, age, risk group: */
					// Note: set_max_n_partners() is currently a placeholder function.
					individual_population[id_counter].max_n_partners = set_max_n_partners(g,ag,r,param);

					/* This is a list of pointers to all individuals of a given g, ag, r: */
					(pop->pop_per_gender_age_risk[g][ag][r])[id_counter_per_gender_age_risk[g][ag][r]] = &individual_population[id_counter];

					id_counter++;
					id_counter_per_gender_age_risk[g][ag][r]++;
				}
			}
		}
	}
	/* age_list->youngest_age_group_index is the index of the youngest age group array in age_list->age_groups[]. 
	 * As the population ages this index moves (so we don't have to move all the arrays). By default we start it at zero. */
	age_list->youngest_age_group_index = 0;
}


/* This function fills in (*pop_available_partners) and (*n_pop_available_partners) using (*pop) and (*n_population) 
 * it counts all the "free partnerships" and points to them in pop_available_partners, with associated numbers of 
 * free partnerships stored in n_pop_available_partners */
void init_available_partnerships(population_partners *pop_available_partners, population_size *n_pop_available_partners, 
		population *pop, population_size *n_population){
	int g,ag,r;   /* Indices over gender, age group and risk group. */
	long i;       /* Index to loop over number of people. */
	int j;        /* Index to loop over partnerships. */

	set_population_count_zero(n_pop_available_partners);

	for (g=0 ; g<N_GENDER ; g++){
		for (ag=0 ; ag<N_AGE ; ag++){
			for(r=0 ; r<N_RISK ; r++){
				/* Loop over each individual in this gender/age/risk category: */
				for(i=0 ; i<n_population->pop_size_per_gender_age_risk[g][ag][r] ; i++){
					/* for each free partnership of this individual */
					for(j=pop->pop_per_gender_age_risk[g][ag][r][i]->n_partners ; j<pop->pop_per_gender_age_risk[g][ag][r][i]->max_n_partners ; j++){
						/* Adding this person as an available partner in the list of available partners */
						pop_available_partners->pop_per_gender_age_risk[g][ag][r][n_pop_available_partners->pop_size_per_gender_age_risk[g][ag][r]] = pop->pop_per_gender_age_risk[g][ag][r][i];
						/* Keeping track of where this person is in that list */
						pop->pop_per_gender_age_risk[g][ag][r][i]->idx_available_partner[j] = n_pop_available_partners->pop_size_per_gender_age_risk[g][ag][r];
						n_pop_available_partners->pop_size_per_gender_age_risk[g][ag][r]++;
					}
				}
			}
		}
	}
}

/* Set all cumulative counters to zero (number of HIV tests, CD4 tests etc. ) : */
void init_cumulative_counters(cumulative_outputs_struct *cumulative_outputs){
	cumulative_outputs->N_total_CD4_tests_nonpopart = 0;
	cumulative_outputs->N_total_HIV_tests_nonpopart = 0;
	cumulative_outputs->N_total_CD4_tests_popart = 0;
	cumulative_outputs->N_total_HIV_tests_popart = 0;
	cumulative_outputs->N_total_ever_started_ART_nonpopart = 0;
	cumulative_outputs->N_total_ever_started_ART_popart = 0;
}
