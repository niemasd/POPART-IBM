/*  This file is part of the PopART IBM.

    The PopART IBM is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The PopART IBM is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the PopART IBM.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef HIV_H_
#define HIV_H_


#include "constants.h"
#include "structures.h"
#include "utilities.h"
#include "output.h"


double mtct_transmission(individual*, double, parameters *);
double intervention_effectiveness(double ,double , double , double);
double hiv_transmission_probability(individual *, double , parameters *);
void hiv_acquisition(double, individual*, parameters *, individual** , long *, population_size_one_year_age *, population_size_one_year_age *, age_list_struct *, individual ***, long *, long *);
int find_who_infected(int, double);
void inform_partners_of_seroconversion_and_update_list_serodiscordant_partnerships(individual *, individual **, long *);
void new_infection(double, int, individual *, population_size_one_year_age *, population_size_one_year_age *, age_list_struct *,  parameters *, individual ***, long *, long *);
void draw_initial_infection(individual* , parameters*, individual** , long *, population_size_one_year_age *, population_size_one_year_age *, age_list_struct *, individual ***, long *, long *);
void next_hiv_event(individual *, individual ***, long *, long *, parameters *, double , cumulative_outputs_struct *);
void carry_out_HIV_events_per_timestep(double ,individual ***, long *, long *, parameters *param,age_list_struct *, population_size *,  population_size_one_year_age *, stratified_population_size *, individual **, long *, population_partners *, population_size *, individual ***, long *, long *, cumulative_outputs_struct *);
int get_window_result(double ,double , parameters *);
int joins_preart_care(individual* , parameters *, double , cumulative_outputs_struct *);
int remains_in_cascade(individual* , parameters *, double );
int measured_cd4_cat(parameters *, int );
int art_cd4_eligbility_group(parameters *, double );
int is_eligible_for_art(individual* , parameters *, double );
double get_time_emergency_start_ART(individual *, parameters *, double );
void start_ART_process(individual* , parameters *, double , individual ***, long *, long *, individual ***, long *, long *, int );
void draw_initial_hiv_tests(parameters *, age_list_struct *, double, individual ***, long *, long *);
void schedule_generic_cascade_event(individual* , parameters *, double , individual ***, long *, long *);
void schedule_new_hiv_test(individual *, parameters *, double, individual ***, long *, long *); 
void hiv_test_process(individual* , parameters *, double, individual ***, long *, long *, individual ***, long *, long *, cumulative_outputs_struct *, individual ***, long *, long *);
void schedule_start_of_art(individual* , parameters *, double , individual ***, long *, long *);
void cd4_test_process(individual* , parameters *, double , individual ***, long *, long *, individual ***, long *, long *, cumulative_outputs_struct *);
void virally_suppressed_process(individual* , parameters *, double , individual ***, long *, long *, individual ***, long *, long *);
void virally_unsuppressed_process(individual* , parameters *, double , individual ***, long *, long *, individual ***, long *, long *, cumulative_outputs_struct *);
void dropout_process(individual* , parameters *, double , individual ***, long *, long *, individual ***, long *, long *, cumulative_outputs_struct *);
void carry_out_cascade_events_per_timestep(double ,individual ***, long *, long *, parameters *,age_list_struct *, population_size *,  population_size_one_year_age *, stratified_population_size *, individual **, long *, population_partners *, population_size *, individual ***, long *, long *, cumulative_outputs_struct *, individual ***, long *, long *);
double PANGEA_get_cd4(individual* , double );
#endif /* HIV_H_ */
